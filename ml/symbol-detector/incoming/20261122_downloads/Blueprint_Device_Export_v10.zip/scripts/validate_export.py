#!/usr/bin/env python3
"""Verify inventory JSON contents and core conventions, no source-PDF reassessment."""
from __future__ import annotations
import argparse,zipfile,json,collections
p=argparse.ArgumentParser();p.add_argument('archive');a=p.parse_args()
with zipfile.ZipFile(a.archive) as z:
    names=z.namelist();assert not any(n.lower().endswith(('.png','.jpeg','.jpg')) for n in names)
    jnames=[n for n in names if n.endswith('_DEVICES.json')]
    assert len(jnames)==35, len(jnames)
    naming=json.loads(z.read('device_naming_conventions_v7.json'))
    tax=naming['taxonomy'];all_ids=[];new_counts=collections.Counter()
    for fname in jnames:
        d=json.loads(z.read(fname))
        for rec in d['devices']:
            assert rec['device_type'] in tax and rec['subtype'] in tax[rec['device_type']],(fname,rec['id'])
            bb=rec['symbol_bbox'];assert len(bb)==4 and bb[0]<=bb[2] and bb[1]<=bb[3]
            if rec['device_type']=='light_fixture' and rec['subtype']=='exit_sign':
                ex=rec.get('attributes',{}).get('exit_sign',{})
                assert ex['face_count'] in ('single','double','unknown')
                assert ex['arrow_direction'] in ('left','right','both','none','unknown')
            all_ids.append(rec['id'])
            if rec['id'].startswith('CornishLibrary_') or rec['id'].startswith('F2402_'):new_counts[rec['device_type'],rec['subtype']]+=1
    assert len(all_ids)==len(set(all_ids)) and len(all_ids)==966
    assert sum(new_counts.values())==93
    print('PASS',len(jnames),'inventories',len(all_ids),'device records',new_counts)
