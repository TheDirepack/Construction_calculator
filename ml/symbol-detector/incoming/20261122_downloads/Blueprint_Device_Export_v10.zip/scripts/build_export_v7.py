#!/usr/bin/env python3
"""Build standardized device JSON export v7 from v6 plus conservative new-vector matchers.

Usage:
 python build_export_v7.py --pdf-root /path/to/pdfs \
     --prior-zip /path/to/Blueprint_Device_JSONs_Standardized_v6.zip \
     --out /path/to/Blueprint_Device_Export_v7.zip

Requires: PyMuPDF. Source PDFs are not bundled. No images generated or included.
The new matchers do NOT make an exhaustive device takeoff.
"""
from __future__ import annotations
import argparse,collections,hashlib,json,os,re,shutil,zipfile
from pathlib import Path
import fitz
from extract_new_sources import CORNISH,MISSOURI,cornish_exit_symbols,mo_lighting_circles,cornish_fire_alarm_symbols

NEW_FILES=[
 'G0.03.pdf','G0.01.pdf','Farmhouse_Drawing_Set_V-001.pdf','FA-05.pdf','FA-02.pdf','E2.1.pdf','C5.01.pdf','C2.02.pdf','C2.01.pdf','C1.01.pdf','A2.11.pdf',
 '202610_supportingdocs_PE-64810-NONST-2027-000000054-2026-10-09_14_03_70-bab85116-1c08-4782-811e-0108069c2f0e.pdf',
 '202609_supportingdocs_PE-77075-NONST-2027-000000018-2026-09-16_11_10_95-3df44279-122e-4fa5-9cb2-9a77e11874e1.pdf',
 '2405-Maximum-Pulling-Tension-WEB.pdf',CORNISH,MISSOURI,'S7.2.pdf','S2.2.pdf','P0.1.pdf','su-081523-2-drawingspdf.pdf'
]

TAX={
 'receptacle':['unspecified','single','duplex','quad','gfci_single','gfci_duplex','gfci_quad','switched_single','switched_duplex','switched_quad','gfci_switched_duplex','gfci_switched_quad','special_purpose'],
 'switch':['unspecified','single_pole','double_pole','three_way','four_way','dimmer','three_way_dimmer','four_way_dimmer','key_operated','occupancy_sensor_switch','vacancy_sensor_switch','sensor_switch','timer','pilot_light','low_voltage_control','momentary','scene_control','motor_starter_switch'],
 'fire_alarm':['smoke_detector','duct_smoke_detector','heat_detector','smoke_co_detector','beam_smoke_detector','pull_station','horn','strobe','horn_strobe','speaker','speaker_strobe','control_panel','annunciator','module','relay_module','sprinkler_bell','remote_test_station'],
 'light_fixture':['2x2','2x4','downlight','linear','strip','wall_light','exit_sign','other'],
 'data_outlet':['data','data_telephone','telephone'],
 'junction_box':['junction_box'],
 'boiler':['boiler'], 'pump':['circulator_pump','hot_water_pump'],
 'temperature_sensor':['temperature_sensor'], 'thermostat':['thermostat'],
 'occupancy_sensor':['occupancy_sensor','vacancy_sensor'], 'speaker':['speaker'],
 'exhaust_fan':['exhaust_fan'], 'ceiling_fan':['ceiling_fan'],
 'security_device':['access_card_reader','magnetic_door_contact','request_to_exit','panic_button','door_controller','access_control_panel','security_camera','door_lock','network_switch'],
 'hvac_device':['air_handling_unit','vav','damper','diffuser','grille','exhaust_fan','heat_pump','equipment_other'],
 'plumbing_fixture':['sink','water_closet','floor_drain','floor_cleanout','valve','fixture_other']
}
EXIT_ENUM={
 'device_type':'light_fixture','subtype':'exit_sign',
 'attributes.exit_sign.face_count':['single','double','unknown'],
 'attributes.exit_sign.arrow_direction':['left','right','both','none','unknown'],
 'attributes.exit_sign.face_arrows':'list of {face: A|B, arrow_direction: left|right|both|none|unknown}; empty when face-specific arrows cannot be verified',
 'attributes.exit_sign.variant_key':'<single|double|unknown>_face_<left|right|both|none|unknown>_arrow; use unknown rather than guess',
 'example_variant_keys':['single_face_left_arrow','single_face_right_arrow','single_face_both_arrow','single_face_none_arrow','double_face_left_arrow','double_face_right_arrow','double_face_both_arrow','unknown_face_unknown_arrow'],
 'semantics':{
  'left':'left arrow shown on face as viewed by approaching occupant',
  'right':'right arrow shown on face as viewed by approaching occupant',
  'both':'both LEFT and RIGHT arrows printed on the SAME face',
  'none':'confirmed sign without an arrow (not simply missing evidence)',
  'unknown':'arrow direction not legible or not indicated in the source plan',
  'double_face':'two readable sign faces; not the same as both arrows',
  'sign_orientation_vs_arrow':'plan rotation/orientation and the arrows printed on sign faces are separate attributes'
 }
}
CONVENTIONS={
 'version':'7.0','schema_base':'v6; additional exit_sign attributes and extraction provenance',
 'taxonomy':TAX,
 'core_fields':{
  'device_type':'shared broad class; not a schedule/model identifier',
  'subtype':'functional form or meaningful subtype; use a separate attribute for other specifications',
  'device_code':'original drawing code, preserving case and meaning where verified',
  'attributes':'explicit supported modifiers, not additional inferred device records',
  'symbol_bbox':'[x0,y0,x1,y1] PDF pts, bottom-left origin; actual vector graphic only',
  'symbol_center':'center of matched device graphic, not label center',
  'device_center':'symbol center for non-wall; null where wall connection unresolved',
  'wall_connection_point':'exact device centerline/wall intersection; null unless derived from verified vectors',
  'vector_path_ids':'zero-based PyMuPDF get_drawings() enumeration on that specific page; fragile if PDF is modified',
  'confidence':'evidence quality, not probability calibration',
  'verification':'provenance of vector/legend match; automated matches are not all manually verified',
  'pdf_page':'1-based PDF page number','sheet':'sheet identifier as printed'
 },
 'exit_sign':EXIT_ENUM,
 'receptacle_rules':{'count_variants':['single','duplex','quad'],
   'modifiers':['gfci','switched','weatherproof','floor_mount','dedicated'],
   'examples':['gfci_duplex','gfci_quad','switched_duplex','switched_quad','gfci_switched_duplex','gfci_switched_quad'],
   'rule':'combine GFCI/switched into subtype only where drawing symbol/legend supports both; weatherproof is an attribute'},
 'switch_rules':{'variants':['single_pole','double_pole','three_way','four_way','dimmer','three_way_dimmer','occupancy_sensor_switch','vacancy_sensor_switch','sensor_switch','timer','key_operated','scene_control'],
   'rule':'keep sensor TECHNOLOGY (PIR, ultrasonic, dual-tech) as attribute, not separate subtype unless needed'},
 'lighting_rules':{'forms':['2x2','2x4','downlight','linear','strip','wall_light','exit_sign','other'],
   'rule':'do not infer LED, recessed, manufacturer, etc. from symbol where user only needs fixture form'},
 'fire_alarm_rules':'distinguish smoke vs heat vs combination detectors, manual pull, horn/strobe/horn-strobe, speakers, modules and panels; do not classify lone S without legend/context',
 'junction_box_rules':'single junction_box type',
 'data_rules':'data_outlet is its own type; a triangle is not by itself sufficient without legend/context',
 'unknown_policy':'unknown/unverified instead of nearest glyph-center or guessed wall contact; never populate an instance solely from a legend occurrence'
}

CORNISH_LEGEND=[
 ('light_fixture','strip','FLUORESCENT STRIP, WRAP, OR LINEAR FIXTURE'),('light_fixture','exit_sign','EXIT SIGN, SELF POWERED'),
 ('switch','single_pole','SINGLE POLE SWITCH'),('switch','three_way','3-WAY SWITCH'),('switch','four_way','4-WAY SWITCH'),
 ('switch','dimmer','DIMMER SWITCH'),('switch','pilot_light','PILOT LIGHT SWITCH'),('occupancy_sensor','occupancy_sensor','CEILING OCCUPANCY SENSOR'),
 ('receptacle','duplex','DUPLEX RECEPTACLE'),('receptacle','quad','DOUBLE DUPLEX RECEPTACLE'),
 ('receptacle','gfci_duplex','GROUND FAULT TYPE DUPLEX RECEPTACLE'),
 ('data_outlet','data','COMPUTER OUTLET'),('data_outlet','telephone','TELEPHONE OUTLET'),
 ('fire_alarm','control_panel','FIRE ALARM CONTROL PANEL'),('fire_alarm','annunciator','FIRE ALARM REMOTE ANNUNCIATOR'),
 ('fire_alarm','smoke_detector','SYSTEM SMOKE DETECTOR'),('fire_alarm','remote_test_station','DUCT SMOKE REMOTE TEST'),('fire_alarm','duct_smoke_detector','DUCT SMOKE DETECTOR'),
 ('fire_alarm','heat_detector','RATE OF RISE/FIXED HEAT DETECTOR'),('fire_alarm','pull_station','MANUAL PULL STATION'),
 ('fire_alarm','horn_strobe','HORN STROBE DEVICE'),('fire_alarm','speaker_strobe','SPEAKER STROBE DEVICE'),('fire_alarm','strobe','STROBE ONLY DEVICE'),('fire_alarm','heat_detector','FIXED HEAT DETECTOR: F IN HEXAGON')]
MO_LEGEND=[
 ('switch','single_pole','S wall-mounted switch'),('switch','three_way','S3 wall-mounted switch'),
 ('switch','four_way','S4 wall-mounted switch'),('switch','occupancy_sensor_switch','OP/OU/OT occupancy sensing wall switch; technology retained in attributes'),
 ('switch','vacancy_sensor_switch','VP/VU/VT vacancy sensing wall switch; technology retained in attributes'),
 ('switch','momentary','M momentary switch'),('switch','scene_control','SS scene switch'),('switch','dimmer','DX dimmer switch'),
 ('light_fixture','exit_sign','EXIT LIGHT on EL101'),('light_fixture','other','C1/C2 lighting plan fixture circles')]
FARM_LEGEND=[('receptacle','unspecified','ELECTRIC OUTLET, count unspecified'),('switch','unspecified','SWITCH, pole unspecified by legend'),
 ('light_fixture','other','CEILING LIGHT'),('light_fixture','downlight','RECESSED LIGHT'),('light_fixture','wall_light','WALL-MOUNTED LIGHT'),
 ('ceiling_fan','ceiling_fan','CEILING FAN')]
SEC_LEGEND=[('security_device','access_card_reader','AC-X card reader'),('security_device','magnetic_door_contact','MC-X magnetic contact / door position'),
 ('security_device','access_control_panel','ACP'),('security_device','network_switch','NWS PoE network switch'),('security_device','door_lock','PoE lockset'),
 ('data_outlet','data','PERM4 four CAT6A data ports (not a four-outlet power receptacle)')]

NEW_SOURCE_SCOPE={
 CORNISH:{'status':'partial_vector_instance_extraction','processed':[52,53,54,55,56,57],'target':'exit signs and selected fire alarm shapes; other symbols pending','legend_page':48},
 MISSOURI:{'status':'partial_vector_instance_extraction','processed':[32],'target':'C1/C2 crossed-circle lighting fixtures; others pending','legend_page':32},
 'Farmhouse_Drawing_Set_V-001.pdf':{'status':'legend_and_sheet_inventory_only','processed':[],'target':'electrical/RCP pages 9 and 10 pending','legend_page':1},
 '202610_supportingdocs_PE-64810-NONST-2027-000000054-2026-10-09_14_03_70-bab85116-1c08-4782-811e-0108069c2f0e.pdf':{'status':'identified_relevant_sheets_no_positioned_extraction','processed':[],'target':'electrical legend 22; power/lighting plans 24-28'},
 '202609_supportingdocs_PE-77075-NONST-2027-000000018-2026-09-16_11_10_95-3df44279-122e-4fa5-9cb2-9a77e11874e1.pdf':{'status':'scanned_raster_no_vector_matching_performed','processed':[],'target':'14-page fire station plans pending image-based extraction'},
 'su-081523-2-drawingspdf.pdf':{'status':'legend_and_sheet_inventory_only','processed':[],'target':'security/access control plans; many distinct devices, no verified positions yet','legend_page':1},
 '2405-Maximum-Pulling-Tension-WEB.pdf':{'status':'technical_reference_not_a_device_plan','processed':[],'target':'no placed device plans'}
}
CANADA='G0.01.pdf G0.03.pdf FA-02.pdf FA-05.pdf E2.1.pdf C1.01.pdf C2.01.pdf C2.02.pdf C5.01.pdf A2.11.pdf S2.2.pdf S7.2.pdf P0.1.pdf'.split(' ')
for name in CANADA:
 NEW_SOURCE_SCOPE[name]={'status':'raster_single_sheet_not_vector_extracted','processed':[],'target':'single raster sheet; interpret as legend/detail/site/diagram, no symbol-instance mapping yet'}

def exit_normalize(record):
    if record.get('device_type')=='exit_sign':record['device_type']='light_fixture';record['subtype']='exit_sign'
    if (record.get('device_type'),record.get('subtype'))!=('light_fixture','exit_sign'):return False
    exit_attrs=record.setdefault('attributes',{}).setdefault('exit_sign',{})
    exit_attrs.setdefault('face_count','unknown')
    exit_attrs.setdefault('arrow_direction','unknown')
    exit_attrs.setdefault('face_arrows',[])
    exit_attrs.setdefault('arrow_reference','viewed_from_each_sign_face')
    exit_attrs.setdefault('variant_key',f"{exit_attrs['face_count']}_face_{exit_attrs['arrow_direction']}_arrow")
    exit_attrs.setdefault('classification_evidence','previous_vector_exit_sign_type; no verified face/arrow direction in prior JSON')
    record.setdefault('orientation_review_status','face_and_arrow_pending_source_visual_verification')
    return True

def pdf_info(path):
    d=fitz.open(path);n=len(d)
    text_pages=0
    for p in d:
        if len(p.get_text().strip())>30:text_pages+=1
    r={'page_count':n,'pages_with_extractable_text':text_pages,'raster_or_unreadable_text':text_pages==0}
    d.close();return r

def record_stats(doc):
    counts=collections.Counter((x['device_type'],x['subtype']) for x in doc['devices'])
    return {'geometry_matched_devices':len(doc['devices']),
            'by_type':dict(sorted(collections.Counter(x['device_type'] for x in doc['devices']).items())),
            'by_type_and_subtype':{f'{k[0]}/{k[1]}':v for k,v in sorted(counts.items())}}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--pdf-root',type=Path,default=Path('/mnt/data'))
    ap.add_argument('--prior-zip',type=Path,default=Path('/mnt/data/Blueprint_Device_JSONs_Standardized_v6.zip'))
    ap.add_argument('--out',type=Path,default=Path('/mnt/data/Blueprint_Device_Export_v7.zip'))
    args=ap.parse_args();root=args.pdf_root
    out_dir=args.out.with_suffix('');out_dir.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(args.prior_zip) as z:
        old={n:json.loads(z.read(n)) for n in z.namelist() if n.endswith('_DEVICES.json')}
        prior_backlog=json.loads(z.read('unreviewed_device_backlog.json'))
    assert len(old)==15 and sum(len(v['devices']) for v in old.values())==873
    updated_exit=0
    for doc in old.values():
        for item in doc['devices']:
            if exit_normalize(item):updated_exit+=1
        doc['taxonomy']=TAX
        doc['schema_version']='3.1.0'
        doc['extraction_revision']='v7: exit-sign face/arrow fields added; original vector evidence retained'
        doc['summary'].update(record_stats(doc))
        doc['exit_sign_schema_ref']='device_naming_conventions_v7.json'
    assert updated_exit==10,updated_exit
    new={}
    for fn in NEW_FILES:
        path=root/fn
        if not path.exists():raise FileNotFoundError(path)
        info=pdf_info(path);scope=NEW_SOURCE_SCOPE[fn]
        if fn==CORNISH:legend=CORNISH_LEGEND
        elif fn==MISSOURI:legend=MO_LEGEND
        elif fn=='Farmhouse_Drawing_Set_V-001.pdf':legend=FARM_LEGEND
        elif fn=='su-081523-2-drawingspdf.pdf':legend=SEC_LEGEND
        else:legend=[]
        stem=re.sub(r'[^A-Za-z0-9._-]+','_',path.stem).strip('_')
        name=f'{stem}_DEVICES.json'
        doc={'schema_version':'3.1.0','source_file':fn,'source_pages_total':info['page_count'],
             'coordinate_system':{'units':'PDF points','origin':'bottom-left','page_indexing':'1-based',
             'point_convention':'center of visible vector artwork; wall contact null unless graphically verified'},
             'taxonomy':TAX,
             'legend_types':[{'pdf_page':scope.get('legend_page'), 'device_type':dt,'subtype':st,'description':desc,
                              'instance_status':'legend only, not an instance'} for dt,st,desc in legend],
             'plan_pages_processed':scope['processed'],'page_results':[],
             'devices':[],'unresolved_candidates':[],
             'extraction_status':scope['status'],'coverage_limit':scope['target'],
             'source_profile':info,'review_backlog':{'not_all_symbols_or_sheets_extracted':True},
             'exit_sign_schema_ref':'device_naming_conventions_v7.json','summary':{},
             'extraction_revision':'v7 conservative initial new-PDF pass'}
        new[name]=doc
    cornish,audit_cornish=cornish_exit_symbols(root/CORNISH)
    fire_alarm,fire_audit=cornish_fire_alarm_symbols(root/CORNISH)
    missouri,audit_mo=mo_lighting_circles(root/MISSOURI)
    for fn,records,pg_audit in [(CORNISH,cornish+fire_alarm,audit_cornish+fire_audit),(MISSOURI,missouri,audit_mo)]:
        doc=next(d for d in new.values() if d['source_file']==fn)
        doc['devices']=records
        doc['page_results']=pg_audit if isinstance(pg_audit,list) else [pg_audit]
    assert len(cornish)==12 and len(fire_alarm)==20 and len(missouri)==61,(len(cornish),len(fire_alarm),len(missouri))
    docs={**old,**new}
    total=sum(len(d['devices']) for d in docs.values());assert total==966,total
    ids=[x['id'] for d in docs.values() for x in d['devices']];assert len(ids)==len(set(ids))
    errors=[]
    for filename,doc in docs.items():
        doc['summary'].update(record_stats(doc))
        for r in doc['devices']:
            if r['device_type'] not in TAX or r['subtype'] not in TAX[r['device_type']]:
                errors.append((filename,r['id'],'unknown_type',r['device_type'],r['subtype']))
            a,b,c,e=r['symbol_bbox']
            if not a<=c or not b<=e:errors.append((filename,r['id'],'invalid_bbox'))
            if r['device_type']=='light_fixture' and r['subtype']=='exit_sign':
                ex=r['attributes'].get('exit_sign',{})
                if ex.get('face_count') not in ['single','double','unknown'] or ex.get('arrow_direction') not in ['left','right','both','none','unknown']:
                    errors.append((filename,r['id'],'bad_exit_enum'))
    assert not errors,errors[:20]
    naming=CONVENTIONS
    manifest={'export_version':'v7','schema_version':'3.1.0','files_inventoried':len(docs),
              'prior_pdf_sets':15,'new_pdf_sets':20,'prior_positioned_device_records':873,
              'added_geometry_matched_device_records':len(cornish)+len(missouri)+len(fire_alarm),
              'total_positioned_device_records':total,'exit_signs_normalized_from_v6':updated_exit,
              'exit_signs_added_cornish':len(cornish),'fire_alarm_devices_added_cornish':len(fire_alarm),
              'exit_sign_face_counts_new':dict(collections.Counter(x['attributes']['exit_sign']['face_count'] for x in cornish)),
              'limitations':["No exit-arrow directions confirmed in this pass; fields intentionally set to unknown.",
                  "Only selected Cornish Library E-5 to E-10 exit and fire alarm symbols, plus Missouri Director's House EL101 C1/C2 crossed-circle fixtures, were newly vector-matched.",
                  "All other new PDFs are triaged but not exhaustively extracted. Zero-record inventory is NOT evidence of zero actual devices.",
                  "The 873 preexisting records were carried forward; their original automated detections were not exhaustively re-reviewed.",
                  "A source symbol center is not necessarily an exact wall connection or physical installation location."],
              'per_source':[
                {'source_file':d['source_file'],'json_file':fn,'status':d.get('extraction_status','v6_carried_forward'),
                 'records':len(d['devices']),'pages_processed':d.get('plan_pages_processed',[])}
                for fn,d in sorted(docs.items())],
              'source_archive':args.prior_zip.name,
              'QA':{'all_json_parse':True,'record_IDs_unique':True,'taxonomy_membership':True,'bbox_order_valid':True,
                    'exit_enum_valid':True,'new_correlated_symbols':93}}
    # Keep original per-source backlog but add new work list distinct from verified devices.
    pending={'revision':'v7','source':'new PDFs and v6 backlog','caution':'Incomplete, not an exhaustive count of all unextracted device instances',
      'prior_backlog_reference':'unreviewed_device_backlog_v6.json',
      'new_pdf_work':[{'source_file':d['source_file'],'status':d['extraction_status'],
                       'next_target':d['coverage_limit'],'pages_processed':d['plan_pages_processed'],
                       'records_added':len(d['devices'])} for d in new.values()]}
    export={
      'device_naming_conventions_v7.json':naming,
      '_extraction_manifest_v7.json':manifest,
      '_remaining_work_v7.json':pending,
      'unreviewed_device_backlog_v6.json':prior_backlog,
    }
    for fn,obj in docs.items():export[fn]=obj
    for name,obj in export.items():
        (out_dir/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    script_dir=out_dir/'scripts';script_dir.mkdir(exist_ok=True)
    here=Path(__file__).resolve().parent
    shutil.copy2(here/'extract_new_sources.py',script_dir/'extract_new_sources.py')
    shutil.copy2(here/'build_export_v7.py',script_dir/'build_export_v7.py')
    (script_dir/'requirements.txt').write_text('PyMuPDF>=1.24\n',encoding='utf-8')
    (script_dir/'README.txt').write_text('''VECTOR DEVICE EXTRACTION SCRIPTS — V7\n\nCore v7: extract_new_sources.py, build_export_v7.py\nRequires Python 3.10+ and PyMuPDF.\n\nUsage (from a directory containing the scripts):\n python build_export_v7.py --pdf-root /path/to/20/new/PDFs --prior-zip /path/to/Blueprint_Device_JSONs_Standardized_v6.zip --out /path/to/new_export.zip\n\nThe PDF root must include ALL 20 newly uploaded PDF filenames as in the manifest.\nThis is a targeted conservative matcher, not comprehensive optical detection.\n\nHistorical scripts are supplied separately in scripts/history, for provenance.\nV4-V6 scripts contain session-specific absolute paths and may require adapting\npaths and prior intermediate archives to run. V1-V3 source code was not located\nin the available working directory. Legacy extract_devices.py targets the\nNMNH Baird PDF, not the current 15+20 PDF inventory.\n\nCoordinates are PDF points using displayed-page bottom-left origin.\nFor scanned sheets, no vector-derived device positions have been claimed.\n''',encoding='utf-8')
    hist=script_dir/'history';hist.mkdir(exist_ok=True)
    files=[
      (root/'device_v4/build_v4.py','build_v4.py'),
      (root/'device_v4/add_extra_verified.py','add_extra_verified.py'),
      (root/'device_v4/fix_manifest_and_validate.py','fix_manifest_and_validate.py'),
      (root/'build_device_v5.py','build_device_v5.py'),
      (root/'build_device_v6.py','build_device_v6.py'),
      (root/'device_v5/internal/triangles.py','triangles.py'),
      (root/'extract_devices.py','legacy_extract_devices_NMNH.py'),
    ]
    for src,label in files:
        if src.exists():shutil.copy2(src,hist/label)
    with zipfile.ZipFile(args.out,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
        for p in sorted(out_dir.rglob('*')):
            if p.is_file():
                assert p.suffix.lower() not in ('.jpg','.jpeg','.png')
                z.write(p,p.relative_to(out_dir))
        z.write(args.prior_zip,'input/Blueprint_Device_JSONs_Standardized_v6.zip')
    print(f'OK archive {args.out}: {len(docs)} inventories, total {total}, new {len(cornish)+len(missouri)+len(fire_alarm)}, exits {updated_exit+len(cornish)}')
    print('v7 New', 'Cornish exits',len(cornish),'Cornish alarms',len(fire_alarm),'Missouri',len(missouri),'faces',collections.Counter(x['attributes']['exit_sign']['face_count'] for x in cornish))

if __name__=='__main__':main()
