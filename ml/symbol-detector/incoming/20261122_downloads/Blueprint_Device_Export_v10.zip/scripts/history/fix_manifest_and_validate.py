import json,glob,os,collections,zipfile,fitz,math
from pathlib import Path
base=Path('/mnt/data/device_v4')
manifest=json.load(open(base/'_extraction_manifest.json'))
manifest['revision']='v4'
manifest['source_archive']='Blueprint_Device_JSONs_Standardized_v3.zip'
manifest['new_geometry_matched_records']=31
manifest['changes_v4']=[
 'Vector-matched 3 recessed D4 downlights and 2 EX exit signs on 3873 E10-1.',
 'Vector-matched 3 RL linear fixtures, 1 B wall bracket light, 1 EX exit sign, 2 EF exhaust fans, 2 T thermostats, 2 J junction boxes, and 1 GFCI duplex receptacle on 3670 E103.',
 'Vector-matched 4 boilers (two demolition, two proposed), 6 duplicate-view hot-water pump symbols (P1-3 drawn on each demolition and proposed view), and 4 circulator pumps (CP-1, CP-2, CP-3, CP-DHW) on 3964 M-1.0.',
 'Added complete previously-unresolved label candidate lists, unmatched known legend classes, and prior sheet-coverage gaps in unreviewed_device_backlog.json.',
 'No other pre-existing v3 geometry match was revalidated in this revision.'
]
manifest['extraction_revision']='v4 - 31 additional located vector-symbol drawings, plus explicit unreviewed-types inventory'
manifest['new_devices_added_since_v3']=31
manifest['newly_matched_device_types']={
 'light_fixture / recessed_led_downlight':3, 'exit_sign / illuminated_exit_sign':3,
 'light_fixture / linear_fixture_mounting_unresolved':3, 'light_fixture / wall_bracket_led':1,
 'boiler / hydronic_boiler':4, 'pump / hot_water_pump':6, 'pump / circulator_pump':4,
 'exhaust_fan / exhaust_fan':2, 'thermostat / wall_mounted_thermostat':2,
 'junction_box / junction_box':2, 'receptacle / gfci_duplex':1
}
manifest['verification_method']='New v4 records visually inspected against PDF plan crops, tied to source vector drawing-path indices, and checked for in-page bounds. Earlier v3 matches remain at their existing verification status.'
manifest['quality_checks_v4']=['Each v4 path bounding box reconstructed in rotated display coordinates and compared with serialized bottom-left coordinate bounds.', 'No duplicate per-document IDs.', 'No page-out-of-bounds new device coordinates.', 'Per-set, per-page, and top-level record counts independently reconciled.', 'All delivered archive members are JSON only.']
counts={}
for fp in sorted(base.glob('*DEVICES.json')):
 d=json.load(open(fp));name=fp.name;dp=collections.Counter(x['pdf_page'] for x in d['devices']);
 for result in d['page_results']:
  result['geometry_matched_devices']=dp[result['pdf_page']]
 # Preserve page review notes. Mark revisions explicitly.
 d['summary']['v4_additions']=sum(x.get('verification')=='vector_shape_and_drawing_annotations_manually_crosschecked' for x in d['devices'])
 with open(fp,'w') as f:json.dump(d,f,indent=2,ensure_ascii=False)
 counts[name]=d
for s in manifest['sets']:
 d=counts.get(s['json'])
 if d is None:raise ValueError(s['json'])
 s['geometry_matched_devices']=len(d['devices'])
 s['unresolved_label_candidates']=len(d['unresolved_candidates'])
 s['by_type']=d['summary']['by_type']
 s['by_subtype']=d['summary']['by_subtype']
 s['pages_with_matches']=d['summary']['pages_with_matches']
 s['v4_additions']=d['summary']['v4_additions']
manifest['total_geometry_matched_devices']=sum(len(d['devices']) for d in counts.values())
assert manifest['total_geometry_matched_devices']==825
assert sum(s['geometry_matched_devices'] for s in manifest['sets'])==825
# Verify exact new vector geometry and unique IDs.
seen={}
for fname,d in counts.items():
 pdf=os.path.basename(d['source_file'])
 try:doc=fitz.open('/mnt/data/'+pdf)
 except Exception as e: raise ValueError((fname,pdf,e))
 ids=[x['id'] for x in d['devices']];assert len(ids)==len(set(ids)),fname
 for x in d['devices']:
  if x.get('verification')!='vector_shape_and_drawing_annotations_manually_crosschecked':continue
  page=doc[x['pdf_page']-1]; paths=page.get_drawings();rs=[paths[n]['rect'] for n in x['vector_path_ids']]
  rect=fitz.Rect(rs[0])
  for q in rs[1:]:rect |= q
  R=rect*page.rotation_matrix
  bbox=[R.x0,page.rect.height-R.y1,R.x1,page.rect.height-R.y0]
  if max(abs(a-b) for a,b in zip(bbox,x['symbol_bbox']))>.004: raise ValueError(('vector mismatch',fname,x['id'],bbox,x['symbol_bbox']))
  assert 0<=bbox[0]<=bbox[2]<=page.rect.width and 0<=bbox[1]<=bbox[3]<=page.rect.height,(fname,x['id'])
  assert x['wall_connection_point'] is None
 doc.close()
with open(base/'_extraction_manifest.json','w') as f:json.dump(manifest,f,indent=2,ensure_ascii=False)
out=Path('/mnt/data/Blueprint_Device_JSONs_Standardized_v4.zip')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for fp in sorted(base.glob('*.json')):z.write(fp,fp.name)
with zipfile.ZipFile(out) as z:
 assert len(z.namelist())==17 and all(n.endswith('.json') for n in z.namelist())
 for n in z.namelist():json.loads(z.read(n))
print('validated',out, 'bytes',out.stat().st_size, 'devices',manifest['total_geometry_matched_devices'],'v4',manifest['new_geometry_matched_records'])
