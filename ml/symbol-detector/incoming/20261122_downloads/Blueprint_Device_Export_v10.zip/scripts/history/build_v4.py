import json, os, re, copy, glob, collections, zipfile
from pathlib import Path
import fitz
BASE=Path('/mnt/data/device_v4')
FILES=sorted(BASE.glob('*DEVICES.json'))
index={f.stem[:-8]:f for f in FILES}
D={name:json.load(open(f)) for name,f in index.items()}

# This updates only located, symbol-geometry-backed instances. Never use nearby text-center as device position.
appended=[]
def device_doc(name, pdf, page_no, path_ids, dev_type, subtype, code, phase=None, label=None, on_wall=False,
               center='auto', source='matched_vector_symbol', accuracy='complete_symbol_graphic', extra=None):
    pf=fitz.open('/mnt/data/'+pdf)
    p=pf[page_no-1]
    ds=p.get_drawings()
    bxs=[ds[i]['rect'] for i in path_ids]
    if not bxs:raise AssertionError('must specify vector paths')
    box=fitz.Rect(bxs[0])
    for r in bxs[1:]:box |= r
    # PyMuPDF's drawing paths are given in unrotated page coordinates, even on rotated PDFs.
    dr=fitz.Rect(box)*p.rotation_matrix
    assert dr.x0>=-1 and dr.y0>=-1 and dr.x1<=p.rect.width+1 and dr.y1<=p.rect.height+1, (pdf,page_no,dr,p.rect)
    W,H=p.rect.width,p.rect.height
    bbox=[round(dr.x0,3),round(H-dr.y1,3),round(dr.x1,3),round(H-dr.y0,3)]
    c=[round((bbox[0]+bbox[2])/2,3),round((bbox[1]+bbox[3])/2,3)]
    if label:
        rr=p.search_for(label)
        # choose label closest to selected paths in unrotated PDF coords
        best=min(rr,key=lambda r:abs((r.x0+r.x1)/2-(box.x0+box.x1)/2)+abs((r.y0+r.y1)/2-(box.y0+box.y1)/2)) if rr else None
        if best:
            lr=fitz.Rect(best)*p.rotation_matrix
            label_bbox=[round(lr.x0,3),round(H-lr.y1,3),round(lr.x1,3),round(H-lr.y0,3)]
        else:label_bbox=None
    else:label_bbox=None
    doc=D[name]
    # choose source sheet explicitly if recognized; otherwise use the PDF page identity
    sheet={('3873_Drawings_MJB',23):'E10-1',('3670_Drawings_DAFS',35):'E103',('3964_Drawings_MJB',3):'M-1.0'}.get((name,page_no),f'PDF_PAGE_{page_no}')
    attrs=extra.copy() if extra else {}
    if phase:attrs['drawing_phase']=phase
    if on_wall is None: attrs['mounting_status']='not_resolved_from_drawing'
    rec={
      'pdf_page':page_no, 'sheet':sheet,
      'discipline':'mechanical' if dev_type in ('boiler','pump') else 'electrical',
      'device_code':code, 'device_type':dev_type, 'subtype':subtype,
      'attributes':attrs,'symbol_bbox':bbox,'symbol_center':c,
      'device_center':c if on_wall is False else None,
      'wall_connection_point':None,'on_wall':on_wall,
      'placement_rule':'vector_symbol_center' if on_wall is False else 'mounting_unresolved_wall_contact_not_assumed',
      'geometry_source':source, 'vector_path_ids':path_ids,
      'wall_vector_path_ids':[], 'confidence':'high',
      'verification':'vector_shape_and_drawing_annotations_manually_crosschecked',
      'symbol_bbox_completeness':accuracy,
      'classification_status':'symbol_shape_and_annotated_type_matched',
      'coordinate_precision':'measured_pdf_vector_geometry_not_physical_installation_precision',
      'label_interpretation':'source_sheet_annotation_and_equipment_or_fixture_schedule',
      'exact_wall_connection_verified':False,
      'label_bbox':label_bbox,
    }
    # duplicate prevent by source, page and symbol location (existing may duplicate but check)
    for e in doc['devices']:
        if e.get('pdf_page')==page_no and e.get('device_type')==dev_type:
            center_old=e.get('symbol_center')
            if center_old and sum((a-b)**2 for a,b in zip(center_old,c))<9:
                raise AssertionError(('duplicate position',name,dev_type,c,e['id']))
    rec['id']=f'{name}_D{len(doc["devices"])+1:05d}'
    doc['devices'].append(rec)
    appended.append((name,page_no,dev_type,subtype,code,rec['id']))
    pf.close()
    return rec

# 3873 / E10-1: graphic-matched 4-inch square LED downlights (qu-path) and illuminated exit signs (circle-X).
for ix in [1218,1219,1220]:
    device_doc('3873_Drawings_MJB','3873_Drawings_MJB.pdf',23,[ix],
               'light_fixture','recessed_led_downlight','D4',label='D4',
               source='closed_square_vector_symbol_associated_with_D4_luminaire_schedule')
for ix in [1289,1283]:
    device_doc('3873_Drawings_MJB','3873_Drawings_MJB.pdf',23,[ix],
               'exit_sign','illuminated_exit_sign','EX',label='EX',
               source='vector_circle_cross_exit_symbol_associated_with_EX_schedule')

# 3670 / E103: three labeled RL fixtures and a graphic circle-X exit sign.
for ids in [[820],[824],[849]]:
    device_doc('3670_Drawings_DAFS','3670 Drawings DAFS.pdf',35,ids,
               'light_fixture','linear_fixture_mounting_unresolved','RL',label='RL',on_wall=None,
               source='closed_linear_fixture_outline_correlated_with_RL_label',
               extra={'fixture_identifier_as_printed':'RL','wall_mount_status':'not_verified'})
device_doc('3670_Drawings_DAFS','3670 Drawings DAFS.pdf',35,[816,817,818],
           'exit_sign','illuminated_exit_sign','EX',label='EX',
           source='vector_circle_X_exit_sign_on_lighting_plan')

# 3964 / M-1.0: demolition and new boiler graphics, each a discrete enclosing equipment rectangle.
for ix,code,phase in [(124,'EXISTING_BOILER_1','demolition'),(125,'EXISTING_BOILER_2','demolition'),
                      (371,'BLR-1','proposed'),(372,'BLR-2','proposed')]:
    device_doc('3964_Drawings_MJB','3964_Drawings_MJB.pdf',3,[ix],
               'boiler','hydronic_boiler',code,phase=phase,
               label='BOILER' if phase=='demolition' else code,
               source='equipment_outline_enclosing_boiler_label_mechanical_plan',
               extra={'equipment_id':code})

# Hot-water pumps P1-3 depicted in BOTH demo and proposed details; same physical equipment, two sheet depictions.
for ix,code,phase in [(154,'P3','demolition'),(155,'P1','demolition'),(156,'P2','demolition'),
                      (391,'P3','proposed'),(392,'P1','proposed'),(393,'P2','proposed')]:
    device_doc('3964_Drawings_MJB','3964_Drawings_MJB.pdf',3,[ix],
               'pump','hot_water_pump',code,phase=phase,label=code,
               source='vector_circular_pump_symbol_with_internal_equipment_id',accuracy='pump_circle_core_only',
               extra={'equipment_id':code,'cross_view_same_equipment_id':code})

# Circulator pumps on proposed view; notes explicitly identify CP-1/CP-2/CP-3 and CP-DHW.
for ix,code in [(466,'CP-1'),(464,'CP-2'),(479,'CP-3'),(458,'CP-DHW')]:
    device_doc('3964_Drawings_MJB','3964_Drawings_MJB.pdf',3,[ix],
               'pump','circulator_pump',code,phase='proposed',label=code if code!='CP-DHW' else 'DHW',
               source='vector_circular_circulator_pump_symbol_with_equipment_id_and_plan_notes',
               accuracy='pump_circle_core_only', extra={'equipment_id':code})

assert len(appended)==23, len(appended)

# Explicit review / unfinished inventory. This is a known-work list, not a false assertion of exhaustive discovery.
backlog={
 'report_kind':'known_unreviewed_device_inventory_and_extraction_backlog',
 'source':'15 attached PDF drawing sets and existing v3 inventories',
 'important_limit':'This is NOT a proven enumeration of all physical instances remaining. Categories that were not identified in earlier legend parsing may also be absent. Every entry describes a missing matched legend class, a label-only candidate, or a sheet requiring complete review.',
 'taxonomy_rule':'Use exact variant where printed (single_pole, double_pole, three_way, four_way, dimmer; simplex, duplex, gfci_duplex, quadruplex, etc.). Do not equate a nearby label to a symbol center.',
 'files':[]
}

# Additional notable classes actually visible/readable but not covered by v3 legend extraction.
manual_pending={
 '3964_Drawings_MJB':[
  {'device_type':'thermostat','subtype':'thermostat','source_pages':[2,5], 'reason':'legend/controls device not yet positioned'},
  {'device_type':'valve','subtype':'hydronic_or_fuel_control_valve','source_pages':[3,5], 'reason':'multiple piping and controls symbols, not geometry-matched'},
  {'device_type':'tank','subtype':'lp_gas_storage_tank','source_pages':[4], 'reason':'site equipment graphics not yet isolated'},
  {'device_type':'tank','subtype':'expansion_tank','source_pages':[3], 'reason':'tank symbols and leaders not yet confirmed'},
  {'device_type':'sensor','subtype':'boiler_control_sensor','source_pages':[5,6,7], 'reason':'control/schematic symbol locations not yet interpreted'},
 ],
 '3873_Drawings_MJB':[
  {'device_type':'telecom_outlet','subtype':'data_outlet','source_pages':[24], 'reason':'plan communications symbols not yet resolved'},
  {'device_type':'fire_alarm_control_panel','subtype':'annunciator_or_control_panel','source_pages':[22,24], 'reason':'FANN/F/CP annotations not yet isolated as matched vector symbols'},
 ],
 '3670_Drawings_DAFS':[
  {'device_type':'light_fixture','subtype':'schedule_type_A_or_B','source_pages':[35], 'reason':'lighting symbols not exhaustively matched'},
  {'device_type':'exhaust_fan','subtype':'exhaust_fan','source_pages':[35], 'reason':'EF symbols not matched to complete graphic bounds'},
 ],
 '3818_Drawings_MCCS_1':[
  {'device_type':'controls_device','subtype':'ddc_controller','source_pages':[1,3,4,5,6,7], 'reason':'legend lists DDC controller; no matched plan instances'},
  {'device_type':'occupancy_sensor','subtype':'occupancy_sensor','source_pages':[1,3,4,5,6,7], 'reason':'legend type without matched plan instances'},
  {'device_type':'carbon_monoxide_sensor','subtype':'carbon_monoxide_sensor','source_pages':[1,3,4,5,6,7], 'reason':'legend type without matched plan instances'},
  {'device_type':'smoke_detector','subtype':'duct_smoke_detector','source_pages':[1,3,4,5,6,7], 'reason':'legend type without matched plan instances'},
  {'device_type':'junction_box','subtype':'junction_box','source_pages':[1,3,4,5,6,7], 'reason':'legend type without matched plan instances'},
  {'device_type':'damper','subtype':'control_or_balancing_damper','source_pages':[1,3,4,5,6,7], 'reason':'legend type without matched plan instances'},
 ],
 'H59-6162-CB-MTC_Library_Drawings-a':[
  {'device_type':'telecom_device','subtype':'wireless_access_point','source_pages':[51], 'reason':'11 boxed WAP annotations; symbol graphic positioning not yet verified'},
  {'device_type':'telecom_outlet','subtype':'television_outlet','source_pages':[51], 'reason':'TV callouts and associated symbols not yet matched'},
 ],
 'H59-N336-JR--Drawing_Set':[
  {'device_type':'air_handling_unit','subtype':'air_handling_unit','source_pages':[5,7,8], 'reason':'AHU equipment labeled; exact enclosing vector geometry unresolved'},
  {'device_type':'condensing_unit','subtype':'air_cooled_condensing_unit','source_pages':[5,7,8], 'reason':'CU/ACCU equipment labeled; exact enclosing vector geometry unresolved'},
  {'device_type':'variable_air_volume_box','subtype':'fan_powered_vav','source_pages':[5], 'reason':'multiple FPVAV labels; exact symbol geometry unresolved'},
 ],
 '3920_Drawings_DVEM':[
  {'device_type':'power_equipment','subtype':'pv_array_or_inverter','source_pages':[2,3,4,5,6,7,8,9,10,11,12,13,14,15], 'reason':'solar/microgrid equipment; plan component extraction not attempted'},
  {'device_type':'power_equipment','subtype':'generator_or_switchgear','source_pages':[6,8,10,11,12,13], 'reason':'power/controls equipment not symbol-matched'},
 ],
 'CosCobPS_Drawings_2026_02_23':[
  {'device_type':'light_fixture','subtype':'scheduled_luminaire','source_pages':[102,103,109], 'reason':'multiple labeled luminaire symbols (BM2, EM1, EU1, etc.) not yet symbol-matched'},
  {'device_type':'fire_alarm_control_panel','subtype':'fire_alarm_control_panel','source_pages':[101], 'reason':'FACP label present but exact device vector bbox unresolved'},
 ],
 'H59-N301-SB_-_DrawingSet-A':[
  {'device_type':'exhaust_fan','subtype':'ceiling_or_roof_exhaust_fan','source_pages':[33,35,54], 'reason':'EF labels unresolved as vector symbols'},
  {'device_type':'light_fixture','subtype':'scheduled_luminaire','source_pages':[50,52], 'reason':'fixture extraction incomplete on lighting plans'},
 ],
 '3100_Drawings_DVEM':[
  {'device_type':'light_fixture','subtype':'scheduled_luminaire','source_pages':[89], 'reason':'lighting plan has uncounted fixture symbols'},
  {'device_type':'receptacle','subtype':'weatherproof_duplex','source_pages':[90,91,92,93,94], 'reason':'weatherproof attribute and GFCI variants need exact per-instance verification'},
 ],
}

for name,doc in sorted(D.items()):
 existing={(x.get('device_type'),x.get('subtype')) for x in doc['devices']}
 missing=[]
 for l in doc.get('legend_types',[]):
    pair=(l.get('device_type'),l.get('subtype'))
    if pair not in existing and l not in missing:missing.append(l)
 unresolved=doc.get('unresolved_candidates',[])
 pg_map=collections.Counter(x['pdf_page'] for x in doc['devices'])
 page_results=doc.get('page_results',[])
 reviewed_pages=sorted({p.get('pdf_page') for p in page_results})
 without_matches=sorted(p for p in reviewed_pages if not pg_map[p])
 additions=manual_pending.get(name,[])
 back_entry={
   'source_file':doc.get('source_file'),
   'source_pages_total':doc.get('source_pages_total'),
   'devices_positioned_current':len(doc['devices']),
   'pages_previously_scanned_not_exhaustively_verified':doc.get('plan_pages_processed',[]),
   'previously_scanned_pages_with_zero_located_devices':without_matches,
   'unmatched_legend_types':missing,
   'unresolved_label_only_instances':unresolved,
   'additional_observed_or_expected_unmatched_classes':additions,
   'completion_status':'partial; not exhaustive' if doc['devices'] or doc.get('plan_pages_processed') or doc['legend_types'] else 'not_substantively_reviewed_or_no_MEP_plans_identified',
 }
 backlog['files'].append(back_entry)
 if not isinstance(doc.get('review_backlog'),dict):doc['review_backlog']={}
 doc['review_backlog'].update({
  'unmatched_legend_type_count':len(missing),
  'unresolved_label_only_instance_count':len(unresolved),
  'no_geometry_matches_on_previously_scanned_pages':without_matches,
  'review_backlog_file':'unreviewed_device_backlog.json',
  'no_completeness_claim':True
 })
 doc['extraction_revision']='v4: targeted geometric additions plus explicit known-unreviewed-device inventory'
 summary=doc['summary']
 summary['geometry_matched_devices']=len(doc['devices'])
 summary['pages_with_matches']=len(set(x['pdf_page'] for x in doc['devices']))
 summary['by_type']=dict(sorted(collections.Counter(x['device_type'] for x in doc['devices']).items()))
 summary['by_subtype']=dict(sorted(collections.Counter(x['subtype'] for x in doc['devices']).items()))
 summary['known_unrepresented_legend_types']=len(missing)

manifest=json.load(open(BASE/'_extraction_manifest.json'))
manifest['extraction_revision']='v4 - 23 additional located vector-symbol drawings, plus explicit unreviewed-types inventory'
manifest['total_geometry_matched_devices']=sum(len(d['devices']) for d in D.values())
manifest['new_devices_added_since_v3']=len(appended)
manifest['backlog_file']='unreviewed_device_backlog.json'
manifest['remaining_extraction_is_incomplete']=True
manifest['newly_matched_device_types']=dict(collections.Counter(t[2]+' / '+t[3] for t in appended))
manifest['notes_v4']=[
 'The 3964 M-1.0 sheet depicts P1/P2/P3 in demolition and proposed views. Separate page symbol occurrences share the same equipment_id, not necessarily separate physical pumps.',
 'There are additional schematic and equipment symbols not located; see unreviewed_device_backlog.json.',
 'Known unreviewed items do not equal an exhaustive inventory of all remaining physical devices.',
 'No text-center-derived points were added as verified vector device positions in v4.',
 'No wall connection coordinates were invented; uncertain mounting remains unresolved.',
]

for name,doc in D.items():
 with open(index[name],'w') as f: json.dump(doc,f,indent=2,ensure_ascii=False)
with open(BASE/'unreviewed_device_backlog.json','w') as f:json.dump(backlog,f,indent=2,ensure_ascii=False)
with open(BASE/'_extraction_manifest.json','w') as f:json.dump(manifest,f,indent=2,ensure_ascii=False)

out=Path('/mnt/data/Blueprint_Device_JSONs_Standardized_v4.zip')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for f in sorted(BASE.glob('*.json')):z.write(f,f.name)
print('NEW',len(appended),'TOTAL',sum(len(d['devices']) for d in D.values()),'UNRESOLVED',sum(len(d['unresolved_candidates']) for d in D.values()))
print('ADDITIONS',dict(collections.Counter(t[0]+' '+t[2]+' '+t[3] for t in appended)))
print('BACKLOG known unmatched legend types',sum(len(e['unmatched_legend_types']) for e in backlog['files']))
print('ZIP',out,out.stat().st_size)
