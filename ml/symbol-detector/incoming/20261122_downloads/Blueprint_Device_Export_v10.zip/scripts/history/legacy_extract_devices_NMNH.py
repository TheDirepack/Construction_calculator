#!/usr/bin/env python3
"""
Extract device symbols (receptacle, switch, light fixture, HVAC, fire alarm, etc.)
from the NMNH Baird bid drawing set PDF.

Approach (label + vector geometry):
  * Legend pages are parsed for the device-symbol catalog (text descriptions).
  * On each plan sheet, compact vector clusters (rects + curves) = device symbols.
    Long rects = walls; long thin lines = circuiting (excluded from symbol clusters).
  * Each symbol is associated with the nearest text label and classified by
    discipline + label + symbol position (wall-mounted vs ceiling-mounted).
  * on_wall / wall_connection_point derived from proximity to wall rects.

Coordinates are converted to PDF bottom-left origin (points).
"""
import os, re, json, math
from collections import defaultdict
import pdfplumber

PDF = "2025-0214+NMNH+Baird+Bid+Set+-+Drawings+with+Bookmarks.pdf"
OUT = "NMNH_Baird_DEVICES.json"

# All pages are 2160x3024 (rotated 90). pdfplumber returns upright 3024x2160
# viewing coordinates with top=0.  Page height used for bottom-left conversion.
PAGE_W, PAGE_H = 3024.0, 2160.0

# Drawing-area margin (excludes title block, grid bubbles, sheet border).
MARGIN = 150.0

# ---------------------------------------------------------------------------
# Plan sheets to process: pdf page number -> sheet id
# ---------------------------------------------------------------------------
PLAN_SHEETS = {
    122: "FX-121-FP",     # fire suppression plan
    127: "FA-121-FP",     # fire alarm plan
    130: "MH-400-HP",     # HVAC below floor
    131: "MH-401-HP",     # HVAC plan
    132: "MH-402-HP",     # HVAC above ceiling
    133: "MH-420-HP",     # HVAC below floor BOH
    134: "MH-421-HP",     # HVAC BOH
    135: "MH-422-HP",     # HVAC above ceiling BOH
    136: "MH-423-HP",     # HVAC roof BOH
    137: "MP-401-FP",     # HVAC piping
    138: "MP-420-FP",     # HVAC piping BOH
    140: "M-441-HP",      # enlarged HVAC
    141: "M-442-HP",      # enlarged HVAC mezzanine
    157: "PP-420-FP",     # plumbing
    158: "PP-421-FP",     # plumbing
    161: "EP-110-PP",     # power
    162: "EP-121-PP",     # power
    173: "EL-110-LP",     # lighting
    174: "EL-121-LP",     # lighting
    175: "EL-131-LP",     # lighting
    212: "TA-101-FP",     # AV
    213: "TA-121-FP",     # AV
    214: "TA-201-EL",     # AV
    215: "TN-110-FP",     # telecom
    216: "TN-222-FP",     # telecom
    217: "TN-121-FP",     # telecom
    218: "TN-222-FP",     # telecom
    219: "TN-401-EP",     # telecom
    224: "TY-121-FP",     # security
    225: "TY-131-CP",     # security
}

# ---------------------------------------------------------------------------
# Legend catalog (device symbol types) extracted from legend sheets:
#   A-001 (p9), E-001 (p160), FA-001 (p126), FX-001 (p121), M-001 (p128),
#   M-700 (p148), P-001 (p156), TA-002 (p210), TN-001 (p215), TY-001 (p223),
#   XE-001 (p177), XV-001 (p195)
# ---------------------------------------------------------------------------
LEGEND_SYMBOL_TYPES = [
    {"symbol_type": "receptacle", "description": "Wall/floor mounted electrical receptacle (outlet)", "source_sheet": "E-001"},
    {"symbol_type": "switch", "description": "Wall mounted switch (ON/OFF, dimming, 4-zone low voltage)", "source_sheet": "E-001"},
    {"symbol_type": "occupancy_sensor", "description": "Ceiling or wall mount occupancy sensor (PIR/microphonics)", "source_sheet": "E-001"},
    {"symbol_type": "light_fixture", "description": "Ceiling/wall light fixture", "source_sheet": "E-001 / EL plans"},
    {"symbol_type": "lighting_control_device", "description": "Low voltage lighting control device / faceplate (performance lighting)", "source_sheet": "E-001"},
    {"symbol_type": "junction_box", "description": "Wall mount junction box (lighted mirror, display case, hand dryer, restroom, BAS, VAV)", "source_sheet": "E-001"},
    {"symbol_type": "disconnect_switch", "description": "Disconnect switch (fused / motor)", "source_sheet": "E-001"},
    {"symbol_type": "circuit_breaker", "description": "Circuit breaker in NEMA 1 enclosure", "source_sheet": "E-001"},
    {"symbol_type": "motor_starter", "description": "Combination motor starter with disconnect", "source_sheet": "E-001"},
    {"symbol_type": "vfd", "description": "Variable frequency drive / motor controller", "source_sheet": "E-001"},
    {"symbol_type": "fire_alarm_strobe", "description": "Fire alarm strobe - wall or ceiling mounted", "source_sheet": "FA-001"},
    {"symbol_type": "fire_alarm_pull_station", "description": "Fire alarm manual pull station", "source_sheet": "FA-001"},
    {"symbol_type": "fire_alarm_smoke_detector", "description": "Fire alarm smoke detector", "source_sheet": "FA-001"},
    {"symbol_type": "fire_alarm_horn", "description": "Fire alarm horn / notification appliance", "source_sheet": "FA-001"},
    {"symbol_type": "fire_alarm_control_panel", "description": "Fire alarm control panel", "source_sheet": "FA-001"},
    {"symbol_type": "fire_suppression_sprinkler", "description": "Fire sprinkler head / suppression piping device", "source_sheet": "FX-001"},
    {"symbol_type": "fire_suppression_valve", "description": "Fire suppression control / check / supervisory valve", "source_sheet": "FX-001"},
    {"symbol_type": "backflow_preventer", "description": "Backflow preventer assembly", "source_sheet": "FX-001"},
    {"symbol_type": "fire_pump", "description": "Fire pump", "source_sheet": "FX-001"},
    {"symbol_type": "thermostat", "description": "Room thermostat / sensor (T)", "source_sheet": "M-001"},
    {"symbol_type": "duct_sensor", "description": "Duct mounted thermostat / sensor (T D)", "source_sheet": "M-001"},
    {"symbol_type": "co2_sensor", "description": "Carbon dioxide sensor", "source_sheet": "M-001"},
    {"symbol_type": "isolation_valve", "description": "Isolation valve", "source_sheet": "M-001"},
    {"symbol_type": "throttling_valve", "description": "Throttling valve", "source_sheet": "M-001"},
    {"symbol_type": "balancing_damper", "description": "Manual balancing damper", "source_sheet": "M-001"},
    {"symbol_type": "controls_sensor", "description": "BMS / controls sensing component", "source_sheet": "M-700"},
    {"symbol_type": "plumbing_fixture", "description": "Plumbing fixture / connection", "source_sheet": "P-001"},
    {"symbol_type": "telecom_outlet", "description": "Telecom / data outlet (jack)", "source_sheet": "TN-001"},
    {"symbol_type": "av_device", "description": "Audiovisual device", "source_sheet": "TA-002"},
    {"symbol_type": "security_device", "description": "Security device (camera, contact, motion)", "source_sheet": "TY-001"},
    {"symbol_type": "theatre_equipment", "description": "Theatre equipment / performance device", "source_sheet": "XE-001"},
]


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def bl_y(top, bottom):
    """pdfplumber top-origin -> bottom-left origin y (top edge)."""
    return PAGE_H - bottom


def br_y(top, bottom):
    return PAGE_H - top


def elem_bbox(e):
    return (e['x0'], e['top'], e['x1'], e['bottom'])


def close_enough(a, b, gap=4.0):
    ax0, at0, ax1, ab1 = a
    bx0, bt0, bx1, bb1 = b
    gx = max(0.0, ax0 - bx1, bx0 - ax1)
    gy = max(0.0, at0 - bb1, bt0 - ab1)
    return gx <= gap and gy <= gap


def classify_device(label, sheet, sym_center_x, sym_center_y):
    lbl = (label or "").upper().strip()
    pref = sheet.split("-")[0] if sheet else ""
    # Fire alarm
    if pref == "FA":
        if any(k in lbl for k in ["STROBE", "ST-", "ST "]):
            return "fire_alarm_strobe"
        if any(k in lbl for k in ["PULL", "PS", "MANUAL"]):
            return "fire_alarm_pull_station"
        if any(k in lbl for k in ["SMOKE", "SD", "DETECTOR"]):
            return "fire_alarm_smoke_detector"
        if any(k in lbl for k in ["HORN", "HN", "SPEAKER"]):
            return "fire_alarm_horn"
        if any(k in lbl for k in ["PANEL", "FACP", "CONTROL"]):
            return "fire_alarm_control_panel"
        return "fire_alarm_device"
    # Fire suppression
    if pref == "FX":
        if "SPRINK" in lbl:
            return "fire_suppression_sprinkler"
        if any(k in lbl for k in ["VALVE", "VLV"]):
            return "fire_suppression_valve"
        if "BACKFLOW" in lbl:
            return "backflow_preventer"
        if "PUMP" in lbl:
            return "fire_pump"
        return "fire_suppression_device"
    # Electrical power
    if pref == "EP":
        if any(k in lbl for k in ["L6-", "L5-", "E20", "ROTG", "RECP", "RCPT", "CP-", "RB", "OUTLET"]):
            return "receptacle"
        if any(k in lbl for k in ["SW", "S-"]):
            return "switch"
        if any(k in lbl for k in ["JBOX", "JUNCTION"]):
            return "junction_box"
        return "power_device"
    # Lighting
    if pref == "EL":
        return "light_fixture"
    # HVAC plans & piping
    if pref in ("MH", "MP", "M-"):
        if "CO2" in lbl:
            return "co2_sensor"
        if any(k in lbl for k in [" T ", "THERM", "TSTAT"]):
            return "thermostat"
        if any(k in lbl for k in ["DUCT", "TD "]):
            return "duct_sensor"
        if any(k in lbl for k in ["VALVE", "VLV", "DAMPER", "DMPR"]):
            return "hvac_device"
        if any(k in lbl for k in ["VAV", "BOX", "DIFFUSER", "GRILLE", "REGISTER"]):
            return "hvac_device"
        return "hvac_device"
    # Plumbing
    if pref == "PP":
        return "plumbing_fixture"
    # Telecom
    if pref == "TN":
        if any(k in lbl for k in ["JACK", "DATA", "VOICE", "CAT", "RJ"]):
            return "telecom_outlet"
        return "telecom_device"
    # AV
    if pref == "TA":
        return "av_device"
    # Security
    if pref == "TY":
        if "CAM" in lbl:
            return "security_camera"
        if any(k in lbl for k in ["CONTACT", "MOTION", "SENSOR"]):
            return "security_sensor"
        return "security_device"
    # Controls
    if pref == "M" and "700" in sheet:
        return "controls_sensor"
    return "electrical_device"


def is_grid_noise(word):
    t = word["text"]
    # single char grid letters, grid numbers like 7.0, or pure numbers
    if len(t) == 1 and t.isalnum():
        return True
    if re.fullmatch(r"\d+(\.\d+)?", t):
        return True
    return False


def nearest_label(sym_center, words, limit=45.0):
    cx, cy = sym_center
    best = None
    bd = 1e9
    for w in words:
        wx = (w["x0"] + w["x1"]) / 2.0
        wy = (w["top"] + w["bottom"]) / 2.0
        d = math.hypot(wx - cx, wy - cy)
        if d < limit and d < bd and not is_grid_noise(w):
            bd = d
            best = w
    if best is None:
        # fallback: nearest any word
        for w in words:
            wx = (w["x0"] + w["x1"]) / 2.0
            wy = (w["top"] + w["bottom"]) / 2.0
            d = math.hypot(wx - cx, wy - cy)
            if d < bd:
                bd = d
                best = w
    return (best["text"], bd) if best else (None, None)


def wall_connection_point(sym, wall):
    """Point on wall centerline closest to symbol center."""
    sx = (sym[0] + sym[2]) / 2.0
    sy = (sym[1] + sym[3]) / 2.0
    wx0, wt0, wx1, wb1 = wall
    wx = min(max(sx, wx0), wx1)
    wy = (wt0 + wb1) / 2.0
    return {"x": round(wx, 2), "y": round(PAGE_H - wy, 2)}


def process_page(pdf, pageno, sheet):
    page = pdf.pages[pageno - 1]
    W, H = page.width, page.height
    words = page.extract_words() or []
    # ---- walls: long rects (one dim large, other small = thickness) ----
    walls = []
    for r in page.rects:
        w = r["x1"] - r["x0"]
        h = r["bottom"] - r["top"]
        if max(w, h) > 40 and min(w, h) < 22:
            walls.append((r["x0"], r["top"], r["x1"], r["bottom"]))
    # ---- symbol candidates: compact rects + curves ----
    cands = []
    for r in page.rects:
        w = r["x1"] - r["x0"]
        h = r["bottom"] - r["top"]
        if 2.0 <= max(w, h) <= 60:
            cands.append((r["x0"], r["top"], r["x1"], r["bottom"]))
    for c in page.curves:
        pts = c["pts"]
        xs = [p[0] for p in pts]
        ys = [p[1] for p in pts]
        w = max(xs) - min(xs)
        h = max(ys) - min(ys)
        if 2.0 <= max(w, h) <= 60:
            cands.append((min(xs), min(ys), max(xs), max(ys)))
    # union-find cluster
    n = len(cands)
    parent = list(range(n))

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[rb] = ra

    for i in range(n):
        for j in range(i + 1, n):
            if close_enough(cands[i], cands[j], 4.0):
                union(i, j)
    groups = defaultdict(list)
    for i in range(n):
        groups[find(i)].append(i)
    symbols = []
    for idxs in groups.values():
        xs0 = [cands[i][0] for i in idxs]
        ys0 = [cands[i][1] for i in idxs]
        xs1 = [cands[i][2] for i in idxs]
        ys1 = [cands[i][3] for i in idxs]
        x0, x1 = min(xs0), max(xs1)
        y0, y1 = min(ys0), max(ys1)
        w = x1 - x0
        h = y1 - y0
        if not (3.0 <= w <= 70 and 3.0 <= h <= 70):
            continue
        cx = (x0 + x1) / 2.0
        cy = (y0 + y1) / 2.0
        # restrict to drawing area
        if cx < MARGIN or cx > W - MARGIN or cy < MARGIN or cy > H - MARGIN:
            continue
        symbols.append((x0, y0, x1, y1, cx, cy, len(idxs)))
    # ---- build device records ----
    devices = []
    for (x0, y0, x1, y1, cx, cy, nels) in symbols:
        label, d = nearest_label((cx, cy), words)
        # on_wall: symbol within ~5 pts of a wall rect
        on_wall = False
        nearest_wall = None
        nearest_wall_d = 1e9
        for wall in walls:
            wx0, wt0, wx1, wb1 = wall
            # edge-to-edge distance from symbol bbox to wall bbox
            dx = max(0.0, wx0 - x1, x0 - wx1)
            dy = max(0.0, wt0 - y1, y0 - wt0)
            dist = math.hypot(dx, dy)
            if dist < nearest_wall_d:
                nearest_wall_d = dist
                nearest_wall = wall
        if nearest_wall_d <= 5.0:
            on_wall = True
        rec = {
            "device_type": classify_device(label, sheet, cx, cy),
            "device_label": label,
            "sheet": sheet,
            "bounding_box": {
                "x1": round(x0, 2),
                "y1": round(PAGE_H - y1, 2),
                "x2": round(x1, 2),
                "y2": round(PAGE_H - y0, 2),
            },
            "center_point": {"x": round(cx, 2), "y": round(PAGE_H - cy, 2)},
            "on_wall": on_wall,
        }
        if on_wall and nearest_wall is not None:
            rec["wall_connection_point"] = wall_connection_point(
                (x0, y0, x1, y1), nearest_wall)
        else:
            rec["wall_connection_point"] = None
        devices.append(rec)
    return devices, len(words), len(walls), len(symbols)


def main():
    pdf = pdfplumber.open(PDF)
    all_devices = []
    sheets_processed = []
    for pageno in sorted(PLAN_SHEETS):
        sheet = PLAN_SHEETS[pageno]
        try:
            devices, nwords, nwalls, nsyms = process_page(pdf, pageno, sheet)
        except Exception as e:
            print(f"ERROR page {pageno} ({sheet}): {e}")
            continue
        for d in devices:
            all_devices.append(d)
        sheets_processed.append(
            {"page": pageno, "sheet": sheet, "devices": len(devices),
             "symbols_detected": nsyms, "walls": nwalls, "words": nwords})
        print(f"p{pageno:3d} {sheet:14s} devices={len(devices):4d} "
              f"symbols={nsyms:4d} walls={nwalls:4d} words={nwords:5d}")
    pdf.close()

    # dedupe exact duplicates
    seen = set()
    uniq = []
    for d in all_devices:
        key = (d["sheet"], d["device_type"], d["device_label"],
               d["center_point"]["x"], d["center_point"]["y"])
        if key in seen:
            continue
        seen.add(key)
        uniq.append(d)

    # breakdown
    by_type = defaultdict(int)
    for d in uniq:
        by_type[d["device_type"]] += 1

    output = {
        "source_pdf": "2025-0214+NMNH+Baird+Bid+Set+-+Drawings+with+Bookmarks.pdf",
        "legend": {"symbol_types": LEGEND_SYMBOL_TYPES},
        "devices": uniq,
        "total_devices": len(uniq),
        "sheets_processed": sheets_processed,
        "breakdown_by_type": dict(by_type),
        "coordinate_note": "PDF points, origin bottom-left. Page treated as 3024x2160 (rotated upright).",
    }
    with open(OUT, "w") as f:
        json.dump(output, f, indent=2)
    print("\n=== SUMMARY ===")
    print("total devices:", len(uniq))
    print("breakdown by type:", dict(by_type))
    print("sheets processed:", len(sheets_processed))
    print("output:", OUT)


if __name__ == "__main__":
    main()
