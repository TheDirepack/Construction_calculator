#!/usr/bin/env python3
"""V6 of device JSON inventories: evidence-backed taxonomy + triangle telecom symbols.
Uses actual vector triangles in MTC E-100/E-101 and an inspected contact sheet.
No data derived from label bounding boxes is promoted to a symbol center.
"""
import collections,json,zipfile,math,re
from pathlib import Path
import fitz
import sys
sys.path.insert(0, '/mnt/data/device_v5/internal')
from triangles import find_triangles

ROOT=Path('/mnt/data');SRC=ROOT/'Blueprint_Device_JSONs_Standardized_v5.zip'
DEST=ROOT/'Blueprint_Device_JSONs_Standardized_v6.zip';BASE=ROOT/'device_v6';BASE.mkdir(exist_ok=True)
TAX={
 'receptacle':['single','duplex','quad','gfci_single','gfci_duplex','gfci_quad','switched_single','switched_duplex','switched_quad','gfci_switched_duplex','gfci_switched_quad','special_purpose'],
 'switch':['single_pole','double_pole','three_way','four_way','dimmer','three_way_dimmer','four_way_dimmer','key_operated','occupancy_sensor_switch','vacancy_sensor_switch','sensor_switch','timer','pilot_light','low_voltage_control','momentary','motor_starter_switch'],
 'fire_alarm':['smoke_detector','duct_smoke_detector','heat_detector','smoke_co_detector','beam_smoke_detector','pull_station','horn','strobe','horn_strobe','speaker','speaker_strobe','control_panel','annunciator','module','relay_module','sprinkler_bell','remote_test_station'],
 'light_fixture':['2x2','2x4','downlight','linear','strip','wall_light','exit_sign','other'],
 'data_outlet':['data','data_telephone','telephone'],
 'junction_box':['junction_box'],
 'boiler':['boiler'],
 'pump':['circulator_pump','hot_water_pump'],
 'temperature_sensor':['temperature_sensor'],
 'thermostat':['thermostat'],
 'occupancy_sensor':['occupancy_sensor','vacancy_sensor'],
 'speaker':['speaker'],
 'exhaust_fan':['exhaust_fan'],
}

with zipfile.ZipFile(SRC) as z:
 docs={n:json.loads(z.read(n)) for n in z.namelist() if n.endswith('_DEVICES.json')}
 backlog=json.loads(z.read('unreviewed_device_backlog.json'))
 manifest=json.loads(z.read('_extraction_manifest.json'))
assert len(docs)==15
original_n=sum(len(d['devices']) for d in docs.values()); assert original_n==825,original_n

changes=collections.Counter();perdoc_changes=collections.Counter()
def normalize(typ,sub,description='',is_legend=False):
 t=(typ or '').strip();s=(sub or '').strip();desc=(description or '').upper()
 if t=='exit_sign' or (t=='light_fixture' and s=='exit_sign'):
  return ('light_fixture','exit_sign')
 if t in ('fire_alarm_notification','fire_alarm_device','fire_alarm_detector','fire_alarm_control_panel','fire_alarm_pull_station','fire_alarm_strobe','fire_alarm_horn'):
  t='fire_alarm'
  default={'fire_alarm_notification':'strobe','fire_alarm_device':'module','fire_alarm_detector':'smoke_detector','fire_alarm_control_panel':'control_panel','fire_alarm_pull_station':'pull_station','fire_alarm_strobe':'strobe','fire_alarm_horn':'horn'}.get(typ)
  if not s or s in ('fire_alarm_notification','fire_alarm_device',typ):s=default
  # Restrict modifications to actual evidenced semantic matches.
 if t=='fire_alarm':
  if 'HORN/STROBE' in desc or ('HORN' in desc and 'STROBE' in desc):s='horn_strobe'
  elif 'SPEAKER' in desc and 'STROBE' in desc:s='speaker_strobe'
  elif 'DUCT' in desc and 'SMOKE' in desc:s='duct_smoke_detector'
  elif 'MANUAL' in desc and 'PULL' in desc:s='pull_station'
  elif 'REMOTE' in desc and 'TEST' in desc:s='remote_test_station'
  elif 'ANNUNCIATOR' in desc:s='annunciator'
  elif 'SPRINKLER' in desc and 'BELL' in desc:s='sprinkler_bell'
  elif 'RELAY' in desc and ('MODULE' in desc or 'ADDRESSABLE' in desc):s='relay_module'
  elif 'HORN' in desc and 'SPEAKER' not in desc:s='horn'
  elif 'STROBE' in desc:s='strobe'
  elif 'CONTROL PANEL' in desc:s='control_panel'
  elif 'HEAT DETECTOR' in desc:s='heat_detector'
  s={'smoke':'smoke_detector','photoelectric_smoke':'smoke_detector'}.get(s,s)
 if t=='receptacle':
  s={'simplex':'single','double_duplex':'quad','gfi':'gfci_duplex','gfci':'gfci_duplex','switch_duplex':'switched_duplex','switch_quad':'switched_quad','switched_quadruplex':'switched_quad'}.get(s,s)
  if is_legend:
   gf=bool(re.search(r'\bGFCI\b|\bGFI\b',desc));sw=bool(re.search(r'\bSWITCHED\b|\bSWITCH CONTROLLED\b',desc))
   if 'DOUBLE DUPLEX' in desc or 'QUADRUPLEX' in desc or 'QUAD' in desc: count='quad'
   elif 'SIMPLEX' in desc or 'SINGLE RECEPTACLE' in desc:count='single'
   elif 'DUPLEX' in desc:count='duplex'
   else:count=None
   if count:
    s=('gfci_switched_' if gf and sw else 'gfci_' if gf else 'switched_' if sw else '')+count
 if t=='switch':
  if is_legend:
   if re.search('OCCUPANCY SENSOR SWITCH|WALL SWITCH OCCUPANCY SENSOR',desc):s='occupancy_sensor_switch'
   elif re.search('VACANCY SENSOR SWITCH|WALL SWITCH VACANCY SENSOR',desc):s='vacancy_sensor_switch'
   elif 'THREE WAY DIMMER' in desc or '3-WAY DIMMER' in desc:s='three_way_dimmer'
   elif 'FOUR WAY DIMMER' in desc or '4-WAY DIMMER' in desc:s='four_way_dimmer'
   elif 'PILOT LIGHT' in desc:s='pilot_light'
   elif 'TIMER' in desc or 'TIME SWITCH' in desc:s='timer'
   elif 'KEY' in desc and 'SWITCH' in desc:s='key_operated'
   elif 'LOW VOLTAGE CONTROL' in desc:s='low_voltage_control'
   elif 'MOMENTARY CONTACT' in desc:s='momentary'
   elif 'MOTOR' in desc and 'STARTER' in desc:s='motor_starter_switch'
   elif 'THREE-WAY' in desc or '3-WAY' in desc:s='three_way'
   elif 'FOUR-WAY' in desc or '4-WAY' in desc:s='four_way'
   elif 'DOUBLE POLE' in desc:s='double_pole'
 if t=='occupancy_sensor' and is_legend and 'OCCUPANCY SENSOR SWITCH' in desc:
  return 'switch','occupancy_sensor_switch'
 if t=='data_outlet' and s not in TAX[t]:s='data'
 if t=='light_fixture' and s in ('exit_light','exit','exit_fixture'):s='exit_sign'
 return t,s

for name,d in docs.items():
 for item in d['devices']:
  before=(item['device_type'],item['subtype']);after=normalize(*before)
  if before!=after:
   changes[(before,after)]+=1;perdoc_changes[name]+=1;item['device_type'],item['subtype']=after
 for leg in d['legend_types']:
  before=(leg.get('device_type'),leg.get('subtype'));after=normalize(*before,description=leg.get('description',''),is_legend=True)
  if before!=after:
   leg['device_type'],leg['subtype']=after
  if leg.get('matching_status')=='legend_only; no coordinate assigned' and leg.get('device_type')=='data_outlet' and name.startswith('H59-6162'):
   leg['matching_status']='legend_symbol_matches_vector_triangles_on_pages_49_and_51; not necessarily every instance'

# Put a shared taxonomy in each JSON; no synthetic device records are created for possible classes.
for d in docs.values():
 d['taxonomy']=TAX
 d['taxonomy_note']='Functional classifications only. Receptacle subtype combines count and GFCI/switched properties when supported by actual symbols/labels. Switch subtype identifies pole, dimmer, or sensor-switch function. Exit sign is light_fixture/exit_sign. Standalone occupancy sensor stays occupancy_sensor, not switch. Unverified variants are taxonomy choices, not claimed detected devices.'
 d['classification_rules']={
   'receptacle':{'count':'single|duplex|quad','protection':'gfci when supported','switch_control':'switched when supported','combined_name':'gfci_switched_duplex etc. only with evidence'},
   'switch':{'control':'single_pole|double_pole|three_way|four_way|dimmer|sensor switch variants|timer etc.','mounting':'attribute, not subtype'},
   'lighting':'light_fixture device_type with exit_sign, downlight, linear, 2x2, 2x4 etc. as subtypes',
   'data':'data_outlet device_type; triangle must match telecom legend rather than any generic triangle',
   'junction_box':'one junction_box subtype',
   'unknown_subtype_policy':'do not infer GFCI/quad/3-way/fire alarm function from a lone letter or proximity alone'
 }

# Distinct triangles: selected only after examining visual context of every vector cluster.
# Excludes FEC triangle callouts, camera/AV-like symbols with C, W-labeled equipment,
# and degenerate/duplicate vertices. Dates/phases use sheet title, not a guessed installation status.
SELECTIONS={49:[2,5,6,7,8,9,10],51:[i for i in range(55) if i not in {0,1,2,3,4,5,7,8,27,28,29,30,31,32}]}
filename='H59-6162-CB-MTC_Library_Drawings-a_DEVICES.json';d=docs[filename]
pdf=fitz.open(ROOT/'H59-6162-CB-MTC Library Drawings-a.pdf')
new=[]
for pn,indices in SELECTIONS.items():
 pg=pdf[pn-1];h=pg.rect.height
 # preserve stable vector order; deduplicate only identical exact shape rectangles
 triangles=list({tuple(x['bbox']):x for x in find_triangles(pg)}.values())
 expected=11 if pn==49 else 55
 assert len(triangles)==expected,(pn,len(triangles))
 for idx in indices:
  cand=triangles[idx]
  bb=cand['bbox']
  xmid=(bb[0]+bb[2])/2;ymid=(bb[1]+bb[3])/2
  # reject if bbox matches existing telecom record (none currently, but preserves idempotence)
  if any(v['pdf_page']==pn and v['device_type']=='data_outlet' and math.dist(v['symbol_center'],[xmid,h-ymid])<3 for v in d['devices']):continue
  a,b=cand['base'];tip=cand['tip']
  centroid=[round((a[0]+b[0]+tip[0])/3,3),round(h-(a[1]+b[1]+tip[1])/3,3)]
  bbox=[round(bb[0],3),round(h-bb[3],3),round(bb[2],3),round(h-bb[1],3)]
  rec={
   'id':f'H59-6162-CB-MTC_DATA_{pn:03d}_{idx:03d}',
   'pdf_page':pn, 'sheet':'E-100' if pn==49 else 'E-101','discipline':'electrical',
   'device_code':None, 'device_type':'data_outlet','subtype':'data',
   'attributes':{'graphic':'triangle','source_plan_phase':'demolition_plan' if pn==49 else 'new_work_plan','telecom_variant':'unspecified','location_type':'undetermined'},
   'symbol_bbox':bbox,'symbol_center':centroid,'device_center':centroid,
   'wall_connection_point':None,'on_wall':None,
   'placement_rule':'actual_vector_triangle_centroid; wall_intersection_unresolved',
   'geometry_source':'three_vector_triangle_edges_matching_telecom_legend',
   'vector_path_ids':sorted(set(int(i) for i in cand['ids'])),
   'wall_vector_path_ids':[], 'confidence':'medium',
   'verification':'vector_polygon_verified_by_context_review; exact_wall_contact_unverified',
   'symbol_bbox_completeness':'triangle_outlines_only; adjoining socket or combination fixture not included',
   'label_bbox':None,
   'classification_status':'matched_telecom_triangle_geometry; data_vs_telephone_specificity_unresolved',
   'coordinate_precision':'measured_pdf_vector_coordinates_not_field_placement_accuracy'
  }
  new.append(rec)
pdf.close()
assert len(new)==48,len(new)
d['devices'].extend(new)

# Recap records and correct manifest/backlog after reclassification and real additions.
for name,d in docs.items():
 dev=d['devices'];summ=d['summary'];cs=collections.Counter((r['device_type'],r['subtype']) for r in dev)
 summ['geometry_matched_devices']=len(dev)
 summ['by_type']=dict(sorted(collections.Counter(t for t,s in cs.elements()).items()))
 summ['by_subtype']=dict(sorted(collections.Counter(s for t,s in cs.elements()).items()))
 summ['by_type_and_subtype']={f'{t}/{s}':v for (t,s),v in sorted(cs.items())}
 summ['pages_with_matches']=len({r['pdf_page'] for r in dev})
 d['extraction_revision']='v6: functional taxonomy; exit signs under lighting; telecom triangle geometry on MTC p49/p51; geometry gaps remain'
 represented=set(cs)
 no_match=[leg for leg in d['legend_types'] if (leg['device_type'],leg['subtype']) not in represented]
 d['review_backlog']['unmatched_legend_type_count']=len(no_match)
 summ['known_unrepresented_legend_types']=len(no_match)
 for pr in d['page_results']:
  pr['geometry_matched_devices']=sum(x['pdf_page']==pr['pdf_page'] for x in dev)
 if name==filename:
  d['review_backlog']['new_matched_telecom_triangles']=48
  d['review_backlog']['remaining_telecom_variants_not_verified']='Triangle subtype data/telephone distinctions and exact wall connections require closer vector/annotation matching.'
  d['review_backlog']['visual_exclusion_rule']='Rejected same-shaped FEC equipment callouts, AV/camera-type graphics and W-coded equipment; exact wall points not invented.'
 # QA types, ids and coordinate bounds
 ids=[r['id'] for r in dev]
 assert len(ids)==len(set(ids)),(name,'duplicate ids')
 assert sum(summ['by_type'].values())==len(dev)
 assert sum(summ['by_subtype'].values())==len(dev)
 for v in dev:
  assert (v['device_type'] in TAX and v['subtype'] in TAX[v['device_type']]),(name,v['id'],v['device_type'],v['subtype'])
  if v.get('symbol_bbox'):
   b=v['symbol_bbox'];assert 0<=b[0]<=b[2] and 0<=b[1]<=b[3],(name,v['id'],b)
  assert v.get('symbol_center') is not None,('no symbol center',v['id'])
 (BASE/name).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')

by_source={Path(d['source_file']).name:d for d in docs.values()}
for entry in backlog['files']:
 d=by_source.get(Path(entry['source_file']).name)
 if d is None:continue
 entry['devices_positioned_current']=len(d['devices'])
 matched={(r['device_type'],r['subtype']) for r in d['devices']}
 entry['unmatched_legend_types']=[leg for leg in d['legend_types'] if (leg['device_type'],leg['subtype']) not in matched]
 for row in entry.get('additional_observed_or_expected_unmatched_classes',[]):
  t,s=normalize(row.get('device_type'),row.get('subtype'));row['device_type']=t;row['subtype']=s
 entry['previously_scanned_pages_with_zero_located_devices']=[p for p in entry.get('previously_scanned_pages_with_zero_located_devices',[]) if not any(r['pdf_page']==p for r in d['devices'])]
 if d is docs[filename]:
  entry['newly_positioned_devices']={'data_outlet/data':48,'pages':[49,51]}
  entry['remaining_question']='Confirm data vs telephone and exact wall intersection for these actual vector triangles.'
backlog['source']='15 attached PDFs with v5 carried forward; v6 additional vector-matched triangular telecom devices'
backlog['taxonomy_rule']='Practical subtypes: single/duplex/quad combinations with gfci/switched; sensor-switches separated from independent sensors; exit signs are light_fixture/exit_sign; data_outlet is distinct.'
(BASE/'unreviewed_device_backlog.json').write_text(json.dumps(backlog,ensure_ascii=False,indent=2)+'\n')

for ent in manifest['sets']:
 d=by_source.get(ent['pdf']);
 if d is None:continue
 s=d['summary']
 for k in ('geometry_matched_devices','by_type','by_subtype','pages_with_matches','exact_wall_intersections_confirmed'):
  if k in s:ent[k]=s[k]
 ent['v6_additions']=48 if d is docs[filename] else 0
manifest['revision']='v6';manifest['source_archive']=SRC.name
manifest['extraction_revision']='v6 - expanded switch/receptacle/fire-alarm taxonomy; exit signs under lighting; 48 new telecom symbol geometries'
manifest['total_geometry_matched_devices']=sum(len(x['devices']) for x in docs.values())
manifest['new_geometry_matched_records']=48
manifest['new_devices_added_since_v5']=48
manifest['classification_categories']=TAX
manifest['normalization_changes_count']=sum(changes.values())
manifest['classification_updates']=[{'before':list(b),'after':list(a),'records':v} for (b,a),v in changes.items()]
manifest['classification_policy']='Functional class with useful subtype. GFCI/switched single/duplex/quad specified only with actual evidence. Sensor-controlled wall switches distinct from ceiling occupancy sensors. Exit sign under lighting. Data triangles distinguished from FEC callout triangles.'
manifest['critical_limit']='Neither the 825 inherited records nor the 48 new triangle matches exhaustively verify every device. Exact wall-contact geometry remains unresolved for new triangles; do not treat triangle centroids as exact wall-mount coordinates.'
(BASE/'_extraction_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
assert sum(len(x['devices']) for x in docs.values())==873
with zipfile.ZipFile(DEST,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for p in sorted(BASE.glob('*.json')):z.write(p,p.name)
with zipfile.ZipFile(DEST) as z:
 assert len(z.namelist())==17
 for fn in z.namelist():json.loads(z.read(fn))
print('READY',DEST,DEST.stat().st_size,'devices',manifest['total_geometry_matched_devices'])
print('TYPE_SUMMARY',collections.Counter((r['device_type'],r['subtype']) for d in docs.values() for r in d['devices']))
print('CHANGES',changes)
