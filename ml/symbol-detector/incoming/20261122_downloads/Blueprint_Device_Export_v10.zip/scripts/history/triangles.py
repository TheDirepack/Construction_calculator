import fitz, math, collections, sys

def find_triangles(p):
    paths=p.get_drawings(); edge=[]
    for j,d in enumerate(paths):
        for item in d['items']:
            if item[0]!='l':continue
            a,b=item[1],item[2]; length=math.hypot(a.x-b.x,a.y-b.y)
            if 3.8 <= length <= 22:
                edge.append((j,(a.x,a.y),(b.x,b.y),d))
    # detect by axis aligned base then two sloping edges
    point_edges=collections.defaultdict(list)
    def key(pt):return (round(pt[0]*2)/2,round(pt[1]*2)/2)
    for k,(j,a,b,d) in enumerate(edge):
        for pt in (a,b):point_edges[key(pt)].append(k)
    res={}
    for k,(j,a,b,d) in enumerate(edge):
        dx=b[0]-a[0];dy=b[1]-a[1]; size=math.hypot(dx,dy)
        if not ((abs(dx)<0.15 and 5<size<17) or (abs(dy)<0.15 and 5<size<17)) : continue
        for s in point_edges.get(key(a),[]):
            if s==k: continue
            s_j,s_a,s_b,s_d=edge[s]; mid=s_b if math.dist(s_a,a)<.35 else s_a if math.dist(s_b,a)<.35 else None
            if mid is None:continue
            for t in point_edges.get(key(b),[]):
                if t==k or t==s:continue
                t_j,t_a,t_b,t_d=edge[t]; tip=t_b if math.dist(t_a,b)<.35 else t_a if math.dist(t_b,b)<.35 else None
                if tip is None or math.dist(mid,tip)>.35:continue
                tip=((mid[0]+tip[0])/2,(mid[1]+tip[1])/2)
                cx=(a[0]+b[0])/2;cy=(a[1]+b[1])/2
                perp = abs(tip[0]-cx) if abs(dx)<.15 else abs(tip[1]-cy)
                parallel= abs(tip[1]-cy) if abs(dx)<.15 else abs(tip[0]-cx)
                if not (size*.65 < perp < size*1.7 and parallel < size*.22):continue
                x0=min(a[0],b[0],tip[0]);y0=min(a[1],b[1],tip[1]);x1=max(a[0],b[0],tip[0]);y1=max(a[1],b[1],tip[1]);
                ids=tuple(sorted((j,s_j,t_j)));res[ids]={'bbox':[round(x0,2),round(y0,2),round(x1,2),round(y1,2)],'base':[(round(x,2),round(y,2)) for x,y in (a,b)],'tip':tuple(round(x,2) for x in tip),'ids':ids}
    return list(res.values())

if __name__=='__main__':
 f=sys.argv[1]; pg=int(sys.argv[2]);p=fitz.open('/mnt/data/'+f)[pg-1];cs=find_triangles(p);print('candidates',len(cs));
 for c in cs[:250]:print(c)
