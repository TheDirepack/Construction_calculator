#!/usr/bin/env python3
"""Normalize device categories to practical classification levels without inventing detections."""
import json,zipfile,collections,re,os
from pathlib import Path
SRC=Path('/mnt/data/Blueprint_Device_JSONs_Standardized_v4.zip')
OUT=Path('/mnt/data/Blueprint_Device_JSONs_Standardized_v5.zip')
BASE=Path('/mnt/data/device_v5')
BASE.mkdir(exist_ok=True)
TAX={
 'receptacle':['single','duplex','quad','gfci_single','gfci_duplex','gfci_quad','switched_duplex','special_purpose'],
 'switch':['single_pole','double_pole','three_way','four_way','dimmer','three_way_dimmer','four_way_dimmer','key_operated'],
 'data_outlet':['data','data_telephone','telephone'],
 'fire_alarm':['smoke_detector','duct_smoke_detector','heat_detector','smoke_co_detector','pull_station','horn','strobe','horn_strobe','speaker_strobe','control_panel','module'],
 'junction_box':['junction_box'],
 'light_fixture':['2x2','2x4','downlight','linear','strip','wall_light','other'],
 'exit_sign':['exit_sign'],
 'boiler':['boiler'],
 'pump':['circulator_pump','hot_water_pump'],
 'temperature_sensor':['temperature_sensor'],
 'thermostat':['thermostat'],
 'speaker':['speaker'],
 'occupancy_sensor':['occupancy_sensor','vacancy_sensor'],
 'exhaust_fan':['exhaust_fan'],
}
CHANGES=collections.Counter()
PERFILE={}

# Use drawing codes only where a source fixture schedule was directly checked.
# Other codes retain their original classification until corroborated.
def norm(typ,sub,code=None,project=None,legend_desc=''):
    typ=typ or ''; sub=sub or ''
    if typ in ('fire_alarm_detector','fire_alarm_device','fire_alarm_control_panel','fire_alarm_pull_station','fire_alarm_strobe','fire_alarm_horn'):
        conv={'fire_alarm_detector':'smoke_detector', 'fire_alarm_control_panel':'control_panel','fire_alarm_pull_station':'pull_station','fire_alarm_strobe':'strobe','fire_alarm_horn':'horn'}
        typ='fire_alarm';sub=sub if sub not in ('fire_alarm_detector','fire_alarm_device') else conv.get(typ,sub)
        if sub in ('smoke','smoke_alarm'):sub='smoke_detector'
    if typ=='junction_box':sub='junction_box'
    if typ=='receptacle':
        sub={'simplex':'single','single_receptacle':'single','quadruplex':'quad','double_duplex':'quad','gfci':'gfci_duplex','gfi':'gfci_duplex'}.get(sub,sub)
    if typ=='exit_sign':sub='exit_sign'
    if typ=='boiler':sub='boiler'
    if typ=='speaker':sub='speaker'
    if typ=='thermostat':sub='thermostat'
    if typ=='temperature_sensor':sub='temperature_sensor'
    if typ=='exhaust_fan':sub='exhaust_fan'
    if typ=='occupancy_sensor':sub={'vacancy_sensor':'vacancy_sensor','occupancy_sensor':'occupancy_sensor'}.get(sub,sub)
    if typ=='light_fixture':
        code=(str(code or '').upper().strip())
        if project=='H59-6162-CB-MTC_Library_Drawings-a':
            if code in ('R2','R3'):sub='2x2'
            elif code=='R1':sub='2x4'
            elif code in ('D1','D2'):sub='downlight'
            elif code.startswith('L') and re.fullmatch(r'L\d+|LX',code):sub='linear'
            elif code=='S1':sub='strip'
            elif code=='X1':return ('exit_sign','exit_sign')
        elif project=='3873_Drawings_MJB':
            if code in ('R4','R8'):sub='linear'
            elif code=='D4':sub='downlight'
            elif code=='EX':return ('exit_sign','exit_sign')
        elif project=='H59-N301-SB_-_DrawingSet-A':
            if code=='EX1':return ('exit_sign','exit_sign')
        elif project=='3670_Drawings_DAFS':
            if code=='RL':sub='linear'
            elif code=='B':sub='wall_light'
        if sub in ('recessed_led_downlight','recessed_downlight','led_downlight'):sub='downlight'
        if sub in ('linear_fixture_mounting_unresolved','linear_fixture','recessed_linear'):sub='linear'
        if sub=='wall_bracket_led':sub='wall_light'
        if sub=='scheduled_fixture':sub='other'
    if typ in ('data_outlet','telecom_outlet') and ('DATA OUTLET' in legend_desc.upper() or typ=='data_outlet'):
        typ='data_outlet'
        if 'TELEPHONE' in legend_desc.upper():sub='data_telephone'
        else:sub='data'
    return (typ,sub)

with zipfile.ZipFile(SRC) as z:
    names=z.namelist()
    docs={n:json.loads(z.read(n)) for n in names if n.endswith('_DEVICES.json')}
    backlog=json.loads(z.read('unreviewed_device_backlog.json'))
    manifest=json.loads(z.read('_extraction_manifest.json'))

for name,doc in docs.items():
    project=name[:-len('_DEVICES.json')]
    altered=0
    for item in doc['devices']:
        before=(item.get('device_type'),item.get('subtype'))
        after=norm(*before,code=item.get('device_code'),project=project)
        if before!=after:
            item['device_type'],item['subtype']=after
            CHANGES[(before,after)]+=1
            altered+=1
        # Wall mounting is represented by `on_wall` / mounting, not invented in subtype.
    # Correct a parsed abbreviation-only occurrence that was not a symbol-legend entry.
    if project=='H59-6162-CB-MTC_Library_Drawings-a':
        doc['legend_types']=[x for x in doc['legend_types'] if not (x.get('pdf_page')==36 and x.get('description')=='STORM DRAIN, SMOKE DETECTOR')]
        # Verified visually on E-001, PDF page 48. Triangle telecom/data symbols
        # are part of the legend even though none are yet geometry-matched to plans.
        candidates=[
           ('data_outlet','data','TELECOMM/DATA OUTLET, WALL-MOUNTED: TRIANGLE SYMBOL (filled/unfilled variants)'),
           ('data_outlet','data','DATA OUTLET, FLOOR-MOUNTED: BOX WITH TRIANGLE'),
           ('data_outlet','data_telephone','DATA/TELEPHONE OUTLET, FLOOR-MOUNTED: BOX WITH PARTIALLY FILLED TRIANGLE'),
           ('fire_alarm','pull_station','FIRE ALARM PULL STATION'),
           ('fire_alarm','horn','FIRE ALARM HORN'),
           ('fire_alarm','strobe','FIRE ALARM FLASHING STROBE LIGHT'),
           ('fire_alarm','horn_strobe','COMBINATION FIRE ALARM HORN AND FLASHING STROBE'),
           ('fire_alarm','control_panel','FIRE ALARM CONTROL PANEL')
        ]
        for ty,su,desc in candidates:
            if not any(x.get('description')==desc for x in doc['legend_types']):
                doc['legend_types'].append({'pdf_page':48,'device_type':ty,'subtype':su,'description':desc,'matching_status':'legend_only; no coordinate assigned'})
    for item in doc['legend_types']:
        old=(item.get('device_type'),item.get('subtype'))
        new=norm(*old,project=project,legend_desc=item.get('description',''))
        item['device_type'],item['subtype']=new
    summary=doc['summary']
    summary['geometry_matched_devices']=len(doc['devices'])
    summary['by_type']=dict(sorted(collections.Counter(x['device_type'] for x in doc['devices']).items()))
    summary['by_subtype']=dict(sorted(collections.Counter(x['subtype'] for x in doc['devices']).items()))
    summary['by_type_and_subtype']={f'{typ}/{sub}':c for (typ,sub),c in sorted(collections.Counter((x['device_type'],x['subtype']) for x in doc['devices']).items())}
    doc['taxonomy']=TAX
    doc['taxonomy_note']='Practical category levels: fixture form/size and functional device class. Source device_code retains the schedule reference; manufacturer, LED technology, finish, brightness and fixture mounting are not used as subtype.'
    doc['extraction_revision']='v5: normalized practical device type/subtype terminology; no new geometry claimed'
    doc['review_backlog']['no_completeness_claim']=True
    unmatched={(x['device_type'],x['subtype']) for x in doc['devices']}
    doc['review_backlog']['unmatched_legend_type_count']=sum(1 for x in doc['legend_types'] if (x['device_type'],x['subtype']) not in unmatched)
    summary['known_unrepresented_legend_types']=doc['review_backlog']['unmatched_legend_type_count']
    PERFILE[name]={'records':len(doc['devices']),'reclassified':altered}

# Update status of the same observed backlog; don't pretend missing classes were extracted.
for e in backlog['files']:
    stem=Path(e['source_file']).name.replace('.pdf','')
    doc=next((d for d in docs.values() if d.get('source_file')==e['source_file']),None)
    if doc:
        for leg in e.get('unmatched_legend_types',[]):
            new=norm(leg.get('device_type'),leg.get('subtype'),legend_desc=leg.get('description',''))
            leg['device_type'],leg['subtype']=new
        for x in e.get('additional_observed_or_expected_unmatched_classes',[]):
            typ,sub=norm(x.get('device_type'),x.get('subtype'))
            x['device_type'],x['subtype']=typ,sub
        e['devices_positioned_current']=len(doc['devices'])
backlog['taxonomy_rule']='Practical categories: 2x2, 2x4, downlight, linear, strip, exit_sign; distinct switch poles, GFCI/duplex/quad, data outlets and fire alarm types. Detailed manufacturer and light engine descriptions are not classification requirements.'
backlog['source']='15 attached PDFs and v5 (v4 coordinates retained)'

manifest['revision']='v5'
manifest['extraction_revision']='v5 - practical normalized device taxonomy; zero new positioned devices'
manifest['source_archive']=SRC.name
manifest['new_geometry_matched_records']=0
manifest['new_devices_added_since_v4']=0
manifest['total_geometry_matched_devices']=sum(len(d['devices']) for d in docs.values())
manifest['normalization_changes_count']=sum(CHANGES.values())
manifest['classification_categories']=TAX
manifest['classification_policy']='Keep functional class and meaningful fixture size/shape; identify switch pole/GFCI/receptacle count/fire-alarm function/data as separate values. Do not encode bulb/LED technology, brand, mounting model as subtype.'
manifest['classification_updates']=[{'before':list(old),'after':list(new),'records':n} for (old,new),n in CHANGES.most_common()]
manifest['critical_limit']='These inventories are incomplete; many existing instances were not individually visually verified. Class normalization is not additional source-geometry validation.'

# QA and archive
assert len(docs)==15
n=sum(len(x['devices']) for x in docs.values());assert n==825,n
for name,doc in docs.items():
    ids=[d['id'] for d in doc['devices']];assert len(ids)==len(set(ids)), name
    assert doc['summary']['geometry_matched_devices']==len(ids)
    assert sum(doc['summary']['by_type'].values())==len(ids)
    for r in doc['devices']:
        assert r.get('device_type') and r.get('subtype')
        assert (r['device_type'],r['subtype']) in {(k,s) for k,v in TAX.items() for s in v},(name,r['device_type'],r['subtype'])
    (BASE/name).write_text(json.dumps(doc,indent=2)+'\n')
(BASE/'_extraction_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(BASE/'unreviewed_device_backlog.json').write_text(json.dumps(backlog,indent=2)+'\n')
with zipfile.ZipFile(OUT,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=8) as z:
    for path in sorted(BASE.glob('*.json')):z.write(path,path.name)
print('written',OUT,OUT.stat().st_size,'files',len(docs),'devices',n,'reclassified',sum(CHANGES.values()))
for (b,a),qty in CHANGES.most_common(): print(qty, b, '=>',a)
print('subtypes',collections.Counter((r['device_type'],r['subtype']) for d in docs.values() for r in d['devices']).most_common())
