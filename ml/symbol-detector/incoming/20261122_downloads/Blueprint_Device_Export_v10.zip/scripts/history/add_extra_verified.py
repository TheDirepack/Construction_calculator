import json,fitz,collections,zipfile,os
from pathlib import Path
base=Path('/mnt/data/device_v4');fname=base/'3670_Drawings_DAFS_DEVICES.json'; doc=json.load(open(fname));p=fitz.open('/mnt/data/3670 Drawings DAFS.pdf')[34];paths=p.get_drawings();W,H=p.rect.width,p.rect.height
adds=[
 ('light_fixture','wall_bracket_led','B',[831],True,'B','type_B_wall_light_fixture_schedule'),
 ('exhaust_fan','exhaust_fan','EF',[795],False,'EF','outlined_EF_exhaust_fan_device'),
 ('exhaust_fan','exhaust_fan','EF',[796],False,'EF','outlined_EF_exhaust_fan_device'),
 ('thermostat','wall_mounted_thermostat','T',[834],True,'T','circle_T_thermostat_graphic'),
 ('thermostat','wall_mounted_thermostat','T',[838],True,'T','circle_T_thermostat_graphic'),
 ('junction_box','junction_box','J',[854],None,'J','circle_J_junction_box_symbol'),
 ('junction_box','junction_box','J',[856],None,'J','circle_J_junction_box_symbol'),
 ('receptacle','gfci_duplex','GFI',[813,814,815],True,'GFI','circle_receptacle_with_2_parallel_bars_and_GFI_heat_trace_label'),
]
for t,sub,code,idx,wall,label,source in adds:
 rect=fitz.Rect(paths[idx[0]]['rect'])
 for i in idx[1:]:rect|=paths[i]['rect']
 R=rect*p.rotation_matrix
 bbox=[round(R.x0,3),round(H-R.y1,3),round(R.x1,3),round(H-R.y0,3)]
 cx=round((bbox[0]+bbox[2])/2,3);cy=round((bbox[1]+bbox[3])/2,3)
 for a in doc['devices']:
  if a.get('pdf_page')==35 and a.get('device_type')==t and a.get('symbol_center') and sum((a['symbol_center'][k]-[cx,cy][k])**2 for k in (0,1))<9:
   raise ValueError(('duplicate',t,code,cx,cy))
 rr=p.search_for(label)
 r=min(rr,key=lambda r:abs((r.x0+r.x1)/2-(rect.x0+rect.x1)/2)+abs((r.y0+r.y1)/2-(rect.y0+rect.y1)/2)) if rr else None
 L=r*p.rotation_matrix if r else None
 lb=[round(L.x0,3),round(H-L.y1,3),round(L.x1,3),round(H-L.y0,3)] if L else None
 dev={
  'pdf_page':35,'sheet':'E103','discipline':'mechanical' if t in ('exhaust_fan','thermostat') else 'electrical',
  'device_code':code,'device_type':t,'subtype':sub,
  'attributes':{'mounting_status':'wall_mount_contact_pending'} if wall else {},
  'symbol_bbox':bbox,'symbol_center':[cx,cy],
  'device_center':[cx,cy] if wall is False else None,'wall_connection_point':None,'on_wall':wall,
  'placement_rule':'vector_symbol_center' if wall is False else 'wall_centerline_intersection_pending_or_mounting_unknown',
  'geometry_source':source,'vector_path_ids':idx,'wall_vector_path_ids':[],
  'confidence':'high','verification':'vector_shape_and_drawing_annotations_manually_crosschecked',
  'symbol_bbox_completeness':'full_vector_symbol_graphic',
  'classification_status':'source_drawing_symbol_and_legend_matched',
  'coordinate_precision':'measured_pdf_vector_geometry_not_physical_installation_precision',
  'label_interpretation':'source_drawing_symbol_and_text_annotation',
  'exact_wall_connection_verified':False,'label_bbox':lb,
  'id':f'3670_Drawings_DAFS_D{len(doc["devices"])+1:05d}'
 }
 doc['devices'].append(dev)
 # update review source for extra categories
print('new extra',len(adds),'total 3670',len(doc['devices']))
with open(fname,'w') as f:json.dump(doc,f,indent=2,ensure_ascii=False)
# correction: transcribe exactly what is printed on 3964 demo rather than synthetic IDs.
f3964=base/'3964_Drawings_MJB_DEVICES.json';j=json.load(open(f3964))
for a in j['devices']:
 if a['device_code']=='EXISTING_BOILER_1':a['device_code']='BOILER #1';a['attributes']['equipment_id']='BOILER #1'
 if a['device_code']=='EXISTING_BOILER_2':a['device_code']='BOILER #2';a['attributes']['equipment_id']='BOILER #2'
with open(f3964,'w') as f:json.dump(j,f,indent=2,ensure_ascii=False)
# updated summary, page results, and backlog.
for fname in sorted(base.glob('*DEVICES.json')):
 j=json.load(open(fname)); count=collections.Counter(a['pdf_page'] for a in j['devices'])
 for pr in j['page_results']:pr['geometry_matched_devices']=count[pr['pdf_page']]
 j['summary']['geometry_matched_devices']=len(j['devices']);j['summary']['pages_with_matches']=len(count)
 j['summary']['by_type']=dict(collections.Counter(a['device_type'] for a in j['devices']))
 j['summary']['by_subtype']=dict(collections.Counter(a['subtype'] for a in j['devices']))
 j['summary']['v4_additions']=sum(a.get('verification')=='vector_shape_and_drawing_annotations_manually_crosschecked' for a in j['devices'])
 with open(fname,'w') as f:json.dump(j,f,indent=2,ensure_ascii=False)
backlog=json.load(open(base/'unreviewed_device_backlog.json'))
for x in backlog['files']:
 if x['source_file']==doc['source_file']:
  x['devices_positioned_current']=len(doc['devices']);x['previously_scanned_pages_with_zero_located_devices']=[n for n in x['previously_scanned_pages_with_zero_located_devices'] if n!=35]
  x['unmatched_legend_types']=[a for a in x['unmatched_legend_types'] if (a['device_type'],a['subtype']) not in {('junction_box','junction_box'),('thermostat','thermostat')}]
  # r389 standards call thermostat variant wall_mounted; still legend generic thermostat has now matched subtype and should be marked as partially covered, not entirely absent
  x['legend_types_with_a_related_variant_matched']=['junction_box / junction_box','thermostat / wall_mounted_thermostat']
  x['additional_observed_or_expected_unmatched_classes']=[a for a in x['additional_observed_or_expected_unmatched_classes'] if a['device_type']!='exhaust_fan']
with open(base/'unreviewed_device_backlog.json','w') as f:json.dump(backlog,f,indent=2,ensure_ascii=False)
print('total',sum(len(json.load(open(f))['devices']) for f in base.glob('*DEVICES.json')))
