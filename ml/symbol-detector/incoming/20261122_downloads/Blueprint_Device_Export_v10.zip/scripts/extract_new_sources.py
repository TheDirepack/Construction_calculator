#!/usr/bin/env python3
"""Source-backed, deliberately conservative vector-symbol matching for new drawing sets.

Only emits records for two visually checked patterns:
 * Cornish Library E-5/E-6/E-7: gray filled EXIT rectangles paired with X symbols.
   Two X labels bracketing the same sign rectangle distinguish two-face symbols;
   arrow direction is not encoded by those X markers and stays unknown.
 * Missouri Director's House EL101: 9-point diameter crossed circle immediately
   upper-left of a C1/C2 lighting fixture tag. Five vector paths form the glyph.

Other PDFs and device types need separate dedicated matchers; this program does
NOT assert a complete takeoff. Bounding boxes are vector geometry, not label bboxes.

Requires PyMuPDF. No OCR or generated images.
"""
from __future__ import annotations
import math
from collections import defaultdict
from pathlib import Path
import fitz

CORNISH='21-886-Cornish-Public-Library_CD-8-12-2025-Compiled-drawing-set-upto-incl.-ADDENDUM2.pdf'
MISSOURI='_F2402-01 Final Bid Plans.pdf'

def rect_pdf(r, height):
    return [round(r.x0,3),round(height-r.y1,3),round(r.x1,3),round(height-r.y0,3)]

def midpoint_pdf(r,height):
    return [round((r.x0+r.x1)/2,3),round(height-(r.y0+r.y1)/2,3)]

def is_gray_rect(d):
    r=d['rect'];col=d.get('fill')
    if not (col and d.get('type') in ('f','fs') and any(it[0]=='re' for it in d['items'])):
        return False
    if len(col)<3 or max(col)-min(col)>.018 or not (.62<sum(col)/len(col)<.77):return False
    short=min(r.width,r.height);long=max(r.width,r.height)
    return 3.4 < short < 7 and 11 < long < 21 and 2.3 < long/short < 5

def cornish_exit_symbols(path:Path):
    doc=fitz.open(path);out=[];audit=[]
    for page_no in (52,53,54):
        pg=doc[page_no-1];H=pg.rect.height
        x_words=[w for w in pg.get_text('words') if w[4]=='X']
        # get_drawings() can be expensive on construction PDFs with extensive hatching
        paths=pg.get_drawings()
        bars=[]
        for j,d in enumerate(paths):
            if is_gray_rect(d):bars.append((j,d['rect']))
        by_bar=defaultdict(list)
        unmatched=[]
        for w in x_words:
            x=(w[0]+w[2])/2;y=(w[1]+w[3])/2
            nearby=[(math.hypot(x-(r.x0+r.x1)/2,y-(r.y0+r.y1)/2),j,r) for j,r in bars]
            nearby.sort(key=lambda k:k[0])
            if not nearby or nearby[0][0]>14:
                unmatched.append([round(x,2),round(H-y,2)]);continue
            dist,j,r=nearby[0]
            by_bar[j].append({'word_center_pdf':[round(x,3),round(H-y,3)],'distance_pts':round(dist,3),'word_bbox_pdf':rect_pdf(fitz.Rect(w[:4]),H)})
        for ix,(j,r) in enumerate(bars):
            matches=by_bar.get(j,[])
            if not matches:continue
            if len(matches)>2:
                audit.append({'pdf_page':page_no,'path_id':j,'status':'ambiguous_more_than_two_X_markers','count':len(matches)});continue
            # For double-face, require markers on opposite sides of same bar.
            one_or_two=None
            if len(matches)==1: one_or_two='single'
            elif len(matches)==2:
                if r.height>r.width:
                    opposite=(matches[0]['word_center_pdf'][0]-(r.x0+r.x1)/2)*(matches[1]['word_center_pdf'][0]-(r.x0+r.x1)/2)<0
                else:
                    cy=H-(r.y0+r.y1)/2
                    opposite=(matches[0]['word_center_pdf'][1]-cy)*(matches[1]['word_center_pdf'][1]-cy)<0
                if opposite: one_or_two='double'
            if one_or_two is None:
                audit.append({'pdf_page':page_no,'path_id':j,'status':'ambiguous_X_position','matches':matches});continue
            # Keep bbox limited to actual filled sign glyph, not the nearby X text.
            key=f'CornishLibrary_EXIT_P{page_no:02d}_path{j}'
            out.append({'id':key,'pdf_page':page_no,'sheet':{52:'E-5',53:'E-6',54:'E-7'}[page_no],
                'discipline':'lighting','device_code':'X','device_type':'light_fixture','subtype':'exit_sign',
                'attributes':{'exit_sign':{
                    'face_count':one_or_two,
                    'arrow_direction':'unknown',
                    'face_arrows':[],
                    'variant_key':f'{one_or_two}_face_unknown_arrow',
                    'face_count_evidence':'one_X_at_sign' if one_or_two=='single' else 'X_markers_on_opposite_sides_of_filled_sign',
                    'face_count_confidence':'provisional; inferred from X positions, not confirmed by equipment schedule',
                    'arrow_direction_evidence':'not_provided_by_symbol',
                    'arrow_reference':'viewed_from_each_sign_face'}} ,
                'symbol_bbox':rect_pdf(r,H), 'symbol_center':midpoint_pdf(r,H), 'device_center':midpoint_pdf(r,H),
                'wall_connection_point':None,'on_wall':None,
                'placement_rule':'center_of_filled_vector_exit_sign; mounting_point_unverified',
                'geometry_source':'filled_gray_exit_sign_rectangle_with_nearby_X_label(s)',
                'vector_path_ids':[j], 'wall_vector_path_ids':[],
                'confidence':'high','verification':'source_vector_shape_and_plan_legend_manually_crosschecked',
                'source_label_markers':matches,'symbol_bbox_completeness':'filled_sign_body_only',
                'exact_wall_connection_verified':False})
        audit.append({'pdf_page':page_no,'X_words':len(x_words),'matching_exit_symbols':sum(r['pdf_page']==page_no for r in out),
            'unmatched_X_words':unmatched,'page_vector_path_count':len(paths)})
        del paths
    doc.close()
    return out,audit

def is_small_circle(d):
    r=d['rect'];it=d.get('items') or []
    if not (8.8<r.width<9.2 and 8.8<r.height<9.2):return False
    return len(it)==4 and all(x[0]=='c' for x in it) and d.get('type')=='s'

def mo_lighting_circles(path:Path):
    doc=fitz.open(path);pg=doc[31];H=pg.rect.height
    paths=pg.get_drawings()
    circles=[(i,d['rect']) for i,d in enumerate(paths) if is_small_circle(d)]
    found=[];unresolved=[];used=set()
    words=[w for w in pg.get_text('words') if w[4] in ('C1','C2')]
    for word in words:
        code=word[4];wx=(word[0]+word[2])/2;wy=(word[1]+word[3])/2
        # Target crossed-circle luminaire template on this sheet: source label
        # located roughly 10 pts right and 7 pts above actual fixture circle.
        nearby=[]
        for path_id,r in circles:
            cx=(r.x0+r.x1)/2;cy=(r.y0+r.y1)/2
            error=min(math.hypot((wx-cx)-10.4,(wy-cy)+7.2),
                      math.hypot((wx-cx)-10.4,(wy-cy)-7.2))
            if error<4.4 and path_id not in used:nearby.append((error,path_id,r))
        if len(nearby)!=1:
            unresolved.append({'device_code':code,'label_bbox':rect_pdf(fitz.Rect(word[:4]),H),
                               'reason':'no_unique_9pt_crossed_circle_vector_match','candidate_count':len(nearby)})
            continue
        _,path_id,r=nearby[0]
        # Collect 4 straight crosshair strokes attached to the four cardinal ends.
        cand=[]
        for idx in range(max(0,path_id-15),min(len(paths),path_id+16)):
            v=paths[idx];vr=v['rect']
            if idx==path_id or v.get('type')!='s' or len(v['items'])!=1 or v['items'][0][0]!='l':continue
            if vr.width>5.5 or vr.height>5.5:continue
            a,b=v['items'][0][1:3]
            if min(math.hypot(a.x-r.x0,a.y-(r.y0+r.y1)/2),math.hypot(a.x-r.x1,a.y-(r.y0+r.y1)/2),
                   math.hypot(a.x-(r.x0+r.x1)/2,a.y-r.y0),math.hypot(a.x-(r.x0+r.x1)/2,a.y-r.y1),
                   math.hypot(b.x-r.x0,b.y-(r.y0+r.y1)/2),math.hypot(b.x-r.x1,b.y-(r.y0+r.y1)/2),
                   math.hypot(b.x-(r.x0+r.x1)/2,b.y-r.y0),math.hypot(b.x-(r.x0+r.x1)/2,b.y-r.y1))<0.45:
                cand.append((idx,vr))
        # Keep core circle bbox if unable to confidently identify all four strokes.
        full=cand if len(cand)==4 else []
        geometry=[r]+[x[1] for x in full]
        bbox=fitz.Rect(min(z.x0 for z in geometry),min(z.y0 for z in geometry),
                       max(z.x1 for z in geometry),max(z.y1 for z in geometry))
        center=midpoint_pdf(r,H);used.add(path_id)
        found.append({'id':f'F2402_EL101_{code}_path{path_id}','pdf_page':32,'sheet':'EL101',
            'discipline':'lighting','device_code':code,'device_type':'light_fixture','subtype':'other',
            'attributes':{'fixture_type_code':code,'fixture_form':'unspecified_in_checked_legend',
                          'mounting':'ceiling_indicated_by_lighting_plan'},
            'symbol_bbox':rect_pdf(bbox,H),'symbol_center':center,'device_center':center,
            'wall_connection_point':None,'on_wall':False,'placement_rule':'center_of_circle_vector_fixture_symbol',
            'geometry_source':'9pt_vector_circle_with_crosshairs_adjacent_to_lighting_type_code',
            'vector_path_ids':sorted([path_id]+[idx for idx,_ in full]),'wall_vector_path_ids':[],
            'confidence':'high' if len(full)==4 else 'medium',
            'verification':'vector_shape_and_sample_symbols_manually_crosschecked',
            'symbol_bbox_completeness':'full_crosshair_symbol' if len(full)==4 else 'circle_core_only',
            'label_bbox':rect_pdf(fitz.Rect(word[:4]),H),'exact_wall_connection_verified':False})
    audit={'pdf_page':32,'sheet':'EL101','C1_C2_labels':len(words),'matched':len(found),
           'unresolved':unresolved,'circle_count':len(circles),'full_symbol_bbox_count':sum(x['symbol_bbox_completeness']=='full_crosshair_symbol' for x in found)}
    doc.close();return found,audit

if __name__=='__main__':
    import argparse,json
    parser=argparse.ArgumentParser();parser.add_argument('directory',type=Path);args=parser.parse_args()
    for name,fn in [('cornish',CORNISH),('missouri',MISSOURI)]:
        if name=='cornish':found,audit=cornish_exit_symbols(args.directory/fn)
        else:found,audit=mo_lighting_circles(args.directory/fn)
        print(name,'devices',len(found),'audit',json.dumps(audit)[:1500])


def cornish_fire_alarm_symbols(path:Path):
    """Full small square and triangular outline matches on Cornish E-8/E-9/E-10.

    Identifies only exact matched outlines enclosing letter glyphs. A printed
    device letter with no matching vector boundary is left unresolved.
    """
    doc=fitz.open(path);out=[];page_audits=[]
    for pn in (55,56,57):
        pg=doc[pn-1];H=pg.rect.height
        words=[w for w in pg.get_text('words') if w[4] in ('F','H','S') and 130<w[0]<2150 and 350<w[1]<1450]
        paths=pg.get_drawings()
        # Pre-index path segments based on coarse grid, omitting all hatching except
        # segments with about the same dimension as the symbols in the legend.
        buckets=defaultdict(list)
        for j,d in enumerate(paths):
            if d.get('type')!='s' or len(d['items'])!=1 or d['items'][0][0]!='l':continue
            a,b=d['items'][0][1:3];length=math.hypot(a.x-b.x,a.y-b.y)
            if not 3.7<length<10.2:continue
            r=d['rect'];cx=(r.x0+r.x1)/2;cy=(r.y0+r.y1)/2
            buckets[(int(cx//20),int(cy//20))].append((j,r,(a.x,a.y),(b.x,b.y),length))
        used=set();unresolved=[]
        for w in words:
            code=w[4];wx=(w[0]+w[2])/2;wy=(w[1]+w[3])/2
            cells=[(i,j) for i in range(int(wx//20)-1,int(wx//20)+2) for j in range(int(wy//20)-1,int(wy//20)+2)]
            local=[it for cell in cells for it in buckets.get(cell,[]) if math.hypot((it[1].x0+it[1].x1)/2-wx,(it[1].y0+it[1].y1)/2-wy)<9.5]
            matches=[]
            if code in ('F','H'):
                # Find exactly four contiguous axis-aligned strokes of a 9-pt square.
                edges=[]
                for j,r,a,b,le in local:
                    if not (8.5<le<9.6):continue
                    if abs(a[0]-b[0])<.12 or abs(a[1]-b[1])<.12:edges.append((j,r,a,b))
                for i,(jid,r,a,b) in enumerate(edges):
                    if abs(a[1]-b[1])>.12:continue
                    x0=min(a[0],b[0]);x1=max(a[0],b[0]);y=a[1]
                    for k,(kid,kr,ka,kb) in enumerate(edges):
                        if i==k or abs(ka[1]-kb[1])>.12:continue
                        ky=ka[1];
                        if not(8.5<abs(ky-y)<9.6 and abs(min(ka[0],kb[0])-x0)<.22 and abs(max(ka[0],kb[0])-x1)<.22):continue
                        lo=min(y,ky);hi=max(y,ky)
                        if not(x0-.8<wx<x1+.8 and lo-.8<wy<hi+.8):continue
                        vx0=[z for z in edges if abs(z[2][0]-z[3][0])<.12 and abs(z[2][0]-x0)<.22 and abs(min(z[2][1],z[3][1])-lo)<.22 and abs(max(z[2][1],z[3][1])-hi)<.22]
                        vx1=[z for z in edges if abs(z[2][0]-z[3][0])<.12 and abs(z[2][0]-x1)<.22 and abs(min(z[2][1],z[3][1])-lo)<.22 and abs(max(z[2][1],z[3][1])-hi)<.22]
                        if vx0 and vx1:
                            ids=sorted((jid,kid,vx0[0][0],vx1[0][0]));rr=fitz.Rect(x0,lo,x1,hi)
                            matches.append((rr,ids))
            else: # S strobe is a triangle with 9pt base and two ~9pt sloped edges
                possible=[e for e in local if 7.3<e[4]<10.2]
                for j,r,a,b,le in possible:
                    if not(8.5<le<9.6 and (abs(a[1]-b[1])<.15 or abs(a[0]-b[0])<.15)):continue
                    for k,rr,c,d,lk in possible:
                        if k==j:continue
                        end1=d if math.dist(c,a)<.22 else c if math.dist(d,a)<.22 else None
                        if end1 is None:continue
                        for m,rm,e,f,lm in possible:
                            if m in (j,k):continue
                            end2=f if math.dist(e,b)<.22 else e if math.dist(f,b)<.22 else None
                            if end2 is None or math.dist(end1,end2)>.22:continue
                            pts=[a,b,end1]
                            bb=fitz.Rect(min(p[0] for p in pts),min(p[1] for p in pts),max(p[0] for p in pts),max(p[1] for p in pts))
                            if not (8.5<bb.width<10 and 7<bb.height<9):continue
                            if not(bb.x0-.6<wx<bb.x1+.6 and bb.y0-.6<wy<bb.y1+.6):continue
                            matches.append((bb,sorted([j,k,m])))
            # Keep a single unique outline, not multiple text or duplicated vector fragments.
            sigs={(tuple(ids),tuple(round(v,1) for v in r)): (r,ids) for r,ids in matches}
            hex_heat=False
            if not sigs and code=='F':
                # Distinguish the 135-degree FIXED heat detector: F in a six-edge
                # HEXAGON, rather than F in a four-edge pull-station SQUARE.
                for j,br,a,b,le in local:
                    if not 4.0<le<4.9: continue
                    six=paths[j:j+6]
                    if len(six)!=6 or any(len(d['items'])!=1 or d['items'][0][0]!='l' for d in six):continue
                    starts_ends=[(d['items'][0][1],d['items'][0][2]) for d in six]
                    pts=[(round(pt.x,1),round(pt.y,1)) for pair in starts_ends for pt in pair]
                    from collections import Counter
                    counts=Counter(pts)
                    if len(counts)!=6 or any(n!=2 for n in counts.values()):continue
                    bb=fitz.Rect(min(x for x,y in pts),min(y for x,y in pts),max(x for x,y in pts),max(y for x,y in pts))
                    if not(7<bb.width<9.5 and 8<bb.height<10 and bb.x0<wx<bb.x1 and bb.y0<wy<bb.y1):continue
                    sigs[(tuple(range(j,j+6)),'hex_heat')]=(bb,list(range(j,j+6)))
                    hex_heat=True
            if len(sigs)!=1:
                unresolved.append({'code':code,'pdf_word_center':[round(wx,2),round(H-wy,2)],'candidate_outlines':len(sigs)});continue
            r,ids=next(iter(sigs.values()))
            if any(i in used for i in ids):continue
            used.update(ids)
            subtype='heat_detector' if hex_heat else {'F':'pull_station','H':'horn_strobe','S':'strobe'}[code]
            out.append({'id':f'CornishLibrary_FA_{pn}_{code}_path{ids[0]}','pdf_page':pn,
                'sheet':{55:'E-8',56:'E-9',57:'E-10'}[pn],
                'discipline':'fire_alarm','device_code':code,'device_type':'fire_alarm','subtype':subtype,
                'attributes':{'symbol_shape': 'hexagon' if hex_heat else 'triangle' if code=='S' else 'square',
                   'heat_detection':'fixed_temperature' if hex_heat else None,
                   'temperature_rating_F':135 if hex_heat else None,
                   'candela_rating':'not_inferred_from_letter_alone','mounting':'not_resolved'},
                'symbol_bbox':rect_pdf(r,H),'symbol_center':midpoint_pdf(r,H),
                'device_center':None,'wall_connection_point':None,'on_wall':None,
                'placement_rule':'complete_vector_outline_center; mounting/wall-contact unresolved',
                'geometry_source':('6_line_closed_hexagon_fixed_heat_detector_F' if hex_heat else '3_line_closed_triangle_encircling_S' if code=='S' else '4_line_closed_square_encircling_F_or_H'),
                'vector_path_ids':ids,'wall_vector_path_ids':[],
                'confidence':'high', 'verification':'full_vector_symbol_outline_matched_to_FAH_letter_and_plan_legend',
                'symbol_bbox_completeness':'complete_core_symbol_outline; excludes H horn-strobe attached directional triangle' if code=='H' and not hex_heat else 'complete_small_symbol_outline',
                'label_bbox':rect_pdf(fitz.Rect(w[:4]),H),
                'exact_wall_connection_verified':False})
        page_audits.append({'pdf_page':pn,'F_H_S_words_in_plan_region':len(words),
                            'matched':sum(r['pdf_page']==pn for r in out),'unresolved':unresolved,
                            'vector_path_count':len(paths)})
        del paths
    doc.close();return out,page_audits
