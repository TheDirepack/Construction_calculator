#!/usr/bin/env python3
"""Conservative repeated ribbed-rect vector matcher for mini-split heat pumps on E102-E104.

Requires matched MHP bubble, two cabinet borders, two cabinet sides, and >=3 internal rib strokes.
"""
import fitz,collections,math,re,json
from pathlib import Path

def detect(path):
 D=fitz.open(path);out=[];aud=[]
 for pn in (25,26,27):
  pg=D[pn-1];H=pg.rect.height;ds=pg.get_cdrawings();ws=pg.get_text('words');mhps=[w for w in ws if w[4]=='MHP'];h=[];v=[]
  for idx,d in enumerate(ds):
   if d['type']!='s' or len(d['items'])!=1 or d['items'][0][0]!='l' or d.get('width',0)<1:continue
   _,p,q=d['items'][0];x,y=p;xx,yy=q
   if abs(y-yy)<.15 and 20<abs(x-xx)<26:
    h.append((min(x,xx),max(x,xx),y,idx))
   elif abs(x-xx)<.15 and 6<abs(y-yy)<12:
    v.append((x,min(y,yy),max(y,yy),idx))
  top_bottom=[s for s in h if 23.2<s[1]-s[0]<24.1]
  candidates=[]
  for x0,x1,y0,i in top_bottom:
   for z0,z1,y1,j in top_bottom:
    if 8.5<y1-y0<11.5 and abs(x0-z0)<.85 and abs(x1-z1)<.85:
     c=((x0+x1+z0+z1)/4,(y0+y1)/2)
     if any(math.hypot(c[0]-t[0],c[1]-t[1])<1.7 for t in candidates):continue
     candidates.append((c[0],c[1],min(x0,z0),max(x1,z1),y0,y1,i,j))
  used=set();miss=[]
  for cx,cy,x0,x1,y0,y1,i,j in candidates:
   label=sorted((math.hypot(cx-(w[0]+w[2])/2,cy-(w[1]+w[3])/2),n,w) for n,w in enumerate(mhps))
   if not label or label[0][0]>75 or (len(label)>1 and label[1][0]-label[0][0]<5):
    miss.append([round(cx,1),round(cy,1),'label_unresolved']);continue
   _,n,w=label[0]
   if n in used:continue
   # cabinet sides at x0,x1 (rounded corners may shift side ~0.6pts), plus interior ribs.
   sides_left=[z for z in v if abs(z[0]-x0)<1.1 and abs(z[1]-y0)<1.3 and abs(z[2]-y1)<1.3]
   sides_right=[z for z in v if abs(z[0]-x1)<1.1 and abs(z[1]-y0)<1.3 and abs(z[2]-y1)<1.3]
   ribs=[z for z in h if x0+.6<z[0]<x0+3.3 and x1-3.3<z[1]<x1-.6 and y0+.5<z[2]<y1-.5]
   if not sides_left or not sides_right or len({round(z[2],1) for z in ribs})<3:
    miss.append([round(cx,1),round(cy,1),'cabinet_outline_or_ribs_unverified']);continue
   used.add(n)
   # Nearby tag code in lower half of MHP bubble (i.e. A103).
   tx=(w[0]+w[2])/2;ty=(w[1]+w[3])/2
   tag_candidates=[z for z in ws if 0<z[1]-w[3]<11 and abs((z[0]+z[2])/2-tx)<23 and re.fullmatch(r'[ABC][0-9]{3}[A-Z]?',z[4])]
   tag=sorted(tag_candidates,key=lambda z:math.hypot((z[0]+z[2])/2-tx,(z[1]+z[3])/2-ty))[0][4] if tag_candidates else None
   edges=[i,j,sides_left[0][3],sides_right[0][3]]
   ribs=sorted(ribs,key=lambda x:x[3]);rib_ids=list(dict.fromkeys(z[3] for z in ribs))[:8]
   minx=min(x0,sides_left[0][0],sides_right[0][0]);maxx=max(x1,sides_left[0][0],sides_right[0][0]);
   miny=min(y0,sides_left[0][1],sides_right[0][1]);maxy=max(y1,sides_left[0][2],sides_right[0][2]);
   out.append({'id':f'202610_MHP_E{pn-23:02d}_path{min(edges)}','pdf_page':pn,
    'sheet':{25:'E102',26:'E103',27:'E104'}[pn],
    'discipline':'mechanical_equipment_on_electrical_plan',
    'device_code':('MHP '+tag if tag else 'MHP'),
    'device_type':'hvac_device','subtype':'heat_pump',
    'attributes':({'equipment_tag':'MHP-'+tag} if tag else {'equipment_tag':'MHP','tag_id_status':'unresolved'}),
    'symbol_bbox':[round(minx,3),round(H-maxy,3),round(maxx,3),round(H-miny,3)],
    'symbol_center':[round(cx,3),round(H-cy,3)],'device_center':[round(cx,3),round(H-cy,3)],
    'wall_connection_point':None,'on_wall':None,'placement_rule':'center_of_cabinet_vector; wall_attachment_unverified',
    'geometry_source':'ribbed_rectangular_heat_pump_cabinet_4_edge_strokes_and_multiple_ribs_with_MHP_bubble',
    'vector_path_ids':sorted(set(edges+rib_ids)),'wall_vector_path_ids':[],
    'confidence':'high','verification':'cabinet_vector_geometry_and_unique_MHP_tag; equipment_defined_on_mechanical_abbreviations_page12',
    'symbol_bbox_completeness':'cabinet_body_excludes_equipment_connections',
    'exact_wall_connection_verified':False,
    'source_label_markers':[{'text':'MHP','bbox_pdf':[round(w[0],3),round(H-w[3],3),round(w[2],3),round(H-w[1],3)]}]})
  aud.append({'pdf_page':pn,'sheet':{25:'E102',26:'E103',27:'E104'}[pn],
   'MHP_labels':len(mhps),'verified_mhp_cabinets':len(used),
   'unmatched_MHP_labels':len(mhps)-len(used),'rejected_candidate_cabinets':miss})
  print('MHP',pn,len(used),'/',len(mhps),flush=True)
 D.close();return out,aud

if __name__=='__main__':
 import sys
 r,a=detect(sys.argv[1]);Path('/mnt/data/device_v8_internal/mhp_new.json').write_text(json.dumps({'devices':r,'audit':a},indent=2));print('TOTAL',len(r))
