import zipfile,json,collections,fitz,math,os
path='/mnt/data/Blueprint_Device_Export_v8.zip'
files={
'21-886-Cornish-Public-Library_CD-8-12-2025-Compiled-drawing-set-upto-incl.-ADDENDUM2_DEVICES.json':'/mnt/data/21-886-Cornish-Public-Library_CD-8-12-2025-Compiled-drawing-set-upto-incl.-ADDENDUM2.pdf',
'202610_supportingdocs_PE-64810-NONST-2027-000000054-2026-10-09_14_03_70-bab85116-1c08-4782-811e-0108069c2f0e_DEVICES.json':'/mnt/data/202610_supportingdocs_PE-64810-NONST-2027-000000054-2026-10-09_14_03_70-bab85116-1c08-4782-811e-0108069c2f0e.pdf'}
with zipfile.ZipFile(path) as z:
 names=z.namelist();dnames=[n for n in names if n.endswith('_DEVICES.json')]
 assert len(dnames)==35,len(dnames)
 assert not any(n.lower().endswith(('.png','.jpg','.jpeg')) for n in names)
 tax=json.loads(z.read('device_naming_conventions_v7.json'))['taxonomy']
 all_ids=[];total=0;all_new=[]
 for n in dnames:
  obj=json.loads(z.read(n));devices=obj['devices']; total+=len(devices)
  for d in devices:
   assert d['device_type'] in tax and d['subtype'] in tax[d['device_type']],d
   bb=d['symbol_bbox'];assert len(bb)==4 and bb[0]<=bb[2] and bb[1]<=bb[3]
   all_ids.append(d['id'])
   if d['id'].startswith(('CornishLibrary_E2_RECEPT_','CornishLibrary_E3_RECEPT_','CornishLibrary_E4_RECEPT_','202610_')):
    assert n in files,(n,d['id'])
    all_new.append((n,d))
 assert len(all_ids)==len(set(all_ids)), 'duplicate IDs'
 assert total==1127,(total,len(all_new))
 assert len(all_new)==161,len(all_new)
 counts=collections.Counter((d['device_type'],d['subtype']) for _,d in all_new)
 assert counts=={('receptacle','duplex'):43,('receptacle','gfci_duplex'):37,('hvac_device','air_handling_unit'):40,('hvac_device','heat_pump'):41},counts
 pages=collections.defaultdict(list)
 for n,d in all_new:pages[(n,d['pdf_page'])].append(d)
 for (name,pn),records in pages.items():
  doc=fitz.open(files[name]);pg=doc[pn-1];H=pg.rect.height;W=pg.rect.width
  paths=pg.get_cdrawings()
  for d in records:
   bb=d['symbol_bbox'];cx,cy=d['symbol_center'];
   assert 0<=bb[0]<=bb[2]<=W and 0<=bb[1]<=bb[3]<=H,(d['id'],'out of page',bb,pg.rect)
   assert bb[0]-.25<=cx<=bb[2]+.25 and bb[1]-.25<=cy<=bb[3]+.25,(d['id'],'symbol outside bbox')
   assert len(d['vector_path_ids'])>=4
   for v in d['vector_path_ids']:
    assert 0<=v<len(paths),(d['id'],'bad source vector ID',v)
   if d.get('exact_wall_connection_verified'):
    assert d['wall_connection_point'] is not None and d['device_center']==d['wall_connection_point']
    wx,wy=d['wall_connection_point'];ty=H-wy
    assert len(d['wall_vector_path_ids'])>=1
    good=False
    for i in d['wall_vector_path_ids']:
     assert i>=0 and i<len(paths)
     item=paths[i]['items'];
     if len(item)!=1 or item[0][0]!='l':continue
     a,b=item[0][1:3]
     if abs(a[1]-b[1])<.13 and abs(a[1]-ty)<.26 and min(a[0],b[0])-.26<=wx<=max(a[0],b[0])+.26:good=True
     if abs(a[0]-b[0])<.13 and abs(a[0]-wx)<.26 and min(a[1],b[1])-.26<=ty<=max(a[1],b[1])+.26:good=True
    assert good,(d['id'],'wall point not on given vector')
  print('CHECKED',name[:14],pn,'records',len(records))
  doc.close()
 m=json.loads(z.read('_extraction_manifest_v8.json'))
 assert m['total_positioned_device_records']==total
 assert sum(x['records'] for x in m['per_source'])==total
 assert m['added_geometry_matched_device_records']==161
 print('PASS 35 JSON inventories,',total,'total devices, 161 new, 59 verified new wall points. New categories:',dict(counts))
