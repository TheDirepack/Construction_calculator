import fitz,json,collections,math
p='/mnt/data/21-886-Cornish-Public-Library_CD-8-12-2025-Compiled-drawing-set-upto-incl.-ADDENDUM2.pdf';j=json.load(open('/mnt/data/device_v8_internal/cornish_new.json'));D=fitz.open(p)
for pn in [49,50,51]:
 pg=D[pn-1];a=pg.get_cdrawings();h=collections.defaultdict(list);v=collections.defaultdict(list)
 for idx,d in enumerate(a):
  if len(d['items'])!=1 or d['items'][0][0]!='l':continue
  u=d['items'][0][1];z=d['items'][0][2]
  x,y=u; xx,yy=z
  if abs(y-yy)<.1 and abs(x-xx)>22:
   h[int(y*10)].append((min(x,xx),max(x,xx),y,idx,d.get('color'),d.get('width')))
  elif abs(x-xx)<.1 and abs(y-yy)>22:
   v[int(x*10)].append((min(y,yy),max(y,yy),x,idx,d.get('color'),d.get('width')))
 c=collections.Counter(); samples=[]
 for t in j['devices']:
  if t['pdf_page']!=pn:continue
  ids=t['vector_path_ids'];b=a[ids[0]]['items'][0];pt1=b[1];pt2=b[2];b2=a[ids[16]]['items'][0];pt3=b2[1]
  orient='vertical' if abs(pt1[0]-pt2[0])<.1 else 'horizontal'
  cx,cy=t['symbol_center'];cy=pg.rect.height-cy
  if orient=='vertical':
   ends=[pt1[1],pt2[1]]; y=max(ends,key=lambda y:abs(y-cy));x=(pt1[0]+pt3[0])/2
   hits=[itm for k in range(int((y-1)*10),int((y+1)*10)+1) for itm in h.get(k,[]) if itm[0]-.2<=x<=itm[1]+.2 and abs(itm[2]-y)<=1.0]
  else:
   ends=[pt1[0],pt2[0]];x=max(ends,key=lambda x:abs(x-cx));y=(pt1[1]+pt3[1])/2
   hits=[itm for k in range(int((x-1)*10),int((x+1)*10)+1) for itm in v.get(k,[]) if itm[0]-.2<=y<=itm[1]+.2 and abs(itm[2]-x)<=1.0]
  colored=[z for z in hits if z[4] and min(z[4])>.58]
  exact=[z for z in colored if abs(z[2]-(y if orient=='vertical' else x))<.25]
  c[(bool(hits),bool(colored),bool(exact))]+=1
  samples.append((t['id'],t['subtype'],round(x,2),round(y,2),orient, len(exact),[(z[3],round(z[2],2),z[4],z[5]) for z in exact[:3]]))
  if exact:
   t['wall_connection_point']=[round(x,3),round(pg.rect.height-y,3)]
   t['device_center']=t['wall_connection_point'];t['wall_vector_path_ids']=[z[3] for z in exact[:3]]
   t['exact_wall_connection_verified']=True;t['placement_rule']='centerline_of_receptacle_contact_bars_at_matching_wall_vector'
   t['verification']='full_vector_symbol_and_legend; wall_stroke_intersection_verified'
   t['confidence']='high'
 print(pn,'counters',dict(c))
 print('examples',samples[:6], 'first missed', [s for s in samples if s[5]==0][:4])
json.dump(j,open('/mnt/data/device_v8_internal/cornish_new.json','w'),indent=2)
