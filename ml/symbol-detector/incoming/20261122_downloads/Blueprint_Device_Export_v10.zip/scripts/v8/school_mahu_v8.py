#!/usr/bin/env python3
"""Extract MAHU equipment symbols on school E102-E104 using complete square vector outlines and distinct adjacent MAHU ID bubbles.
Source mechanical abbreviation: MAHU = MINI-SPLIT AIR HANDLING UNIT (PDF p12).
"""
import fitz,collections,math,json
from pathlib import Path
PDF='202610_supportingdocs_PE-64810-NONST-2027-000000054-2026-10-09_14_03_70-bab85116-1c08-4782-811e-0108069c2f0e.pdf'

def detect(path):
 D=fitz.open(path);out=[];audits=[]
 for pn in (25,26,27):
  pg=D[pn-1];H=pg.rect.height;ds=pg.get_cdrawings();lines=collections.defaultdict(list);words=pg.get_text('words')
  for idx,d in enumerate(ds):
   if d['type']!='s' or len(d['items'])!=1 or d['items'][0][0]!='l' or d.get('width',0)<.9:continue
   _,p,q=d['items'][0];x,y=p;xx,yy=q
   if not 24.45<math.dist(p,q)<25 or min(abs(x-xx),abs(y-yy))>.15:continue
   if abs(x-xx)>abs(y-yy): key=(round(min(x,xx),1),round(max(x,xx),1),round(y,1),'H')
   else:key=(round(x,1),round(min(y,yy),1),round(max(y,yy),1),'V')
   lines[key].append(idx)
  by_span=collections.defaultdict(list)
  for (v0,v1,v2,orient),indexes in lines.items():
   if orient=='H':by_span[(v0,v1)].append((v2,indexes))
  square=[]
  for (x0,x1),spans in by_span.items():
   for y0,ids0 in spans:
    for y1,ids1 in spans:
     if not 24.45<y1-y0<25:continue
     left=lines.get((x0,y0,y1,'V'),[]);right=lines.get((x1,y0,y1,'V'),[])
     if left and right:square.append((x0,y0,x1,y1,[ids0[0],ids1[0],left[0],right[0]]))
  mahu=[w for w in words if w[4]=='MAHU'];used=set();unmatched=[]
  for x0,y0,x1,y1,ids in square:
   cx=(x0+x1)/2;cy=(y0+y1)/2
   near=sorted((math.hypot(cx-(w[0]+w[2])/2,cy-(w[1]+w[3])/2),j,w) for j,w in enumerate(mahu))
   if not near or near[0][0]>55 or (len(near)>1 and near[1][0]<65):
    unmatched.append({'center':[round(cx,2),round(H-cy,2)],'reason':'no_unique_nearby_MAHU_label'});continue
   dd,j,w=near[0]
   if j in used:continue
   used.add(j)
   # Equipment tag printed directly below its MAHU abbreviation, e.g. A103.
   wx=(w[0]+w[2])/2;wy=(w[1]+w[3])/2
   ids_words=[v for v in words if 0<v[1]-w[3]<10 and abs((v[0]+v[2])/2-wx)<24 and __import__('re').fullmatch('[ABC][0-9]{3}[A-Z]?',v[4])]
   code=sorted(ids_words,key=lambda v:math.hypot((v[0]+v[2])/2-wx,(v[1]+v[3])/2-wy))[0][4] if ids_words else None
   item={'id':f'202610_E{pn-23:02d}_MAHU_path{min(ids)}','pdf_page':pn,
    'sheet':{25:'E102',26:'E103',27:'E104'}[pn],
    'discipline':'mechanical_equipment_on_electrical_plan','device_code':'MAHU '+code if code else 'MAHU',
    'device_type':'hvac_device','subtype':'air_handling_unit',
    'attributes':({'equipment_tag':f'MAHU-{code}'} if code else {'equipment_tag':'MAHU','tag_id_status':'unresolved'}),
    'symbol_bbox':[x0,round(H-y1,3),x1,round(H-y0,3)],
    'symbol_center':[round(cx,3),round(H-cy,3)],'device_center':[round(cx,3),round(H-cy,3)],
    'wall_connection_point':None,'on_wall':None,'placement_rule':'center_of_closed_four_edge_equipment_vector; wall_connection_unverified',
    'geometry_source':'unique_24_7pt_closed_square_equipment_outline_with_nearby_MAHU_identifier',
    'vector_path_ids':sorted(ids),'wall_vector_path_ids':[],'confidence':'high',
    'verification':'complete_square_vector_and_adjacent_MAHU_label; MAHU_type_defined_on_mechanical_legend_p12',
    'symbol_bbox_completeness':'outer_square_symbol_core_only',
    'exact_wall_connection_verified':False,
    'source_label_markers':[{'text':'MAHU','bbox_pdf':[round(w[0],3),round(H-w[3],3),round(w[2],3),round(H-w[1],3)]}],
   }
   out.append(item)
  audits.append({'pdf_page':pn,'sheet':{25:'E102',26:'E103',27:'E104'}[pn],
   'MAHU_labels':len(mahu),'matched_complete_vector_squares':len(used),
   'unmatched_square_graphics':len(unmatched), 'unresolved_MAHU_labels':len(mahu)-len(used),
   'vector_paths':len(ds)})
  print('page',pn,'MAHU matched',len(used),'MAHU labels',len(mahu),flush=True)
 D.close();return out,audits

if __name__=='__main__':
 import sys
 d,a=detect(Path(sys.argv[1]));Path('/mnt/data/device_v8_internal/mahu_new.json').write_text(json.dumps({'devices':d,'audit':a},indent=2));print('TOTAL',len(d))
