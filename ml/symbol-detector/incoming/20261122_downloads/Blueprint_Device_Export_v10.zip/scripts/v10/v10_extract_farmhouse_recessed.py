#!/usr/bin/env python3
"""Find farmhouse recessed-light glyphs: closed 7.56pt circle + 4 square corners.
Match is vector geometric; sheet A0.0 defines square-corner circle as recessed light.
"""
import fitz,math,json
from pathlib import Path

def b(r,H):return [round(r.x0,3),round(H-r.y1,3),round(r.x1,3),round(H-r.y0,3)]
def center(r,H):return [round((r.x0+r.x1)/2,3),round(H-(r.y0+r.y1)/2,3)]
def extract(path):
 doc=fitz.open(path);res=[];aud=[]
 for pn in [9,10]:
  pg=doc[pn-1];h=pg.rect.height;ps=pg.get_drawings();found=[]
  for i,d in enumerate(ps):
   r=d['rect'];its=d['items'];
   if not(7.50<r.width<7.62 and abs(r.width-r.height)<.1 and len(its)==4 and all(x[0]=='c' for x in its)):continue
   corners={(x,y):{'h':set(),'v':set()} for x in ('L','R') for y in ('T','B')}; ids=set()
   for j,p in enumerate(ps):
    q=p['rect'];
    if j==i or q.x1<r.x0-.2 or q.x0>r.x1+.2 or q.y1<r.y0-.2 or q.y0>r.y1+.2 or q.width>12 or q.height>12:continue
    for it in p['items']:
     if it[0]!='l':continue
     a,z=it[1:3];dx=abs(a.x-z.x);dy=abs(a.y-z.y)
     if not(1.4<max(dx,dy)<2.05 and min(dx,dy)<.14):continue
     mx=(a.x+z.x)/2;my=(a.y+z.y)/2
     for x in ('L','R'):
      for y in ('T','B'):
       ex=r.x0 if x=='L' else r.x1; ey=r.y0 if y=='T' else r.y1
       if abs(mx-ex)<2.15 and abs(my-ey)<2.15:
        if dx>dy and abs(a.y-ey)<.22:corners[(x,y)]['h'].add(j);ids.add(j)
        if dy>dx and abs(a.x-ex)<.22:corners[(x,y)]['v'].add(j);ids.add(j)
   # All four corners have both legs; reject accidental intersections elsewhere.
   if not all(c['h'] and c['v'] for c in corners.values()):continue
   if not(360<r.x0<850 and 180<r.y0<560):continue
   rect=r
   for j in ids:rect|=ps[j]['rect']
   obj={
    'id':f'Farmhouse_A1.{pn-4}_RECESSED_path{i}', 'pdf_page':pn,'sheet':f'A1.{pn-4}',
    'discipline':'lighting','device_code':None,'device_type':'light_fixture','subtype':'downlight',
    'attributes':{'fixture_form':'recessed_light'}, 'symbol_bbox':b(rect,h),'symbol_center':center(r,h),'device_center':center(r,h),
    'wall_connection_point':None,'on_wall':False,'placement_rule':'geometric_center_of_recessed_light_symbol',
    'geometry_source':'closed_circle_plus_four_corner_brackets_matched_to_A0.0_recessed_light_legend',
    'vector_path_ids':sorted({i}|ids), 'wall_vector_path_ids':[],
    'confidence':'high','verification':'closed_circle_and_four_corners_confirmed_against_A0.0_legend',
    'symbol_bbox_completeness':'complete_recessed_light_outline','exact_wall_connection_verified':False}
   found.append(obj)
  res.extend(found);aud.append({'page':pn,'matched':len(found),'path_ids':[x['vector_path_ids'][0] for x in found]})
 doc.close();return res,aud
if __name__=='__main__':
 import sys
 r,a=extract(Path(sys.argv[1]));print(json.dumps(a,indent=2))
