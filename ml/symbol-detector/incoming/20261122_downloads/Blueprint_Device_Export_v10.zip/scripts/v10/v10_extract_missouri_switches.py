#!/usr/bin/env python3
"""Find Missouri director's house EL101 wall-switch symbols by PDF text + vector.

The EL101 legend defines an S + short switch indicator stroke. A 3 at the
symbol denotes three-way. An integrated S3 also occurs, but is NOT emitted
by this conservative matcher unless a unique indicator stroke is found.

No wall intersection is asserted by proximity. The 15.72 pt stroke is the
switch indicator/circuit stub, not proof of a wall vector intersection.
"""
from pathlib import Path
import fitz,math,json,collections

def bbox_pdf(r,h):
 return [round(r.x0,3),round(h-r.y1,3),round(r.x1,3),round(h-r.y0,3)]
def pt_pdf(x,y,h):return [round(x,3),round(h-y,3)]
def dist(a,b):return math.hypot(a[0]-b[0],a[1]-b[1])
def locate(pdf:Path):
 d=fitz.open(pdf); pg=d[31]; H=pg.rect.height
 paths=pg.get_drawings(); words=pg.get_text('words')
 sw=[w for w in words if w[4]=='S' and 450<w[0]<2330 and 350<w[1]<1520]
 threes=[w for w in words if w[4]=='3' and 450<w[0]<2330 and 350<w[1]<1520]
 stems=[]
 for i,p in enumerate(paths):
  if p['type']!='s' or len(p['items'])!=1 or p['items'][0][0]!='l': continue
  a,b=p['items'][0][1:3];length=math.hypot(a.x-b.x,a.y-b.y)
  if not 15.55<length<15.85:continue
  if not (abs(a.x-b.x)<.15 or abs(a.y-b.y)<.15):continue
  stems.append((i,p,a,b))
 cand=[];unresolved=[];used=set()
 for w in sw:
  cx=(w[0]+w[2])/2;cy=(w[1]+w[3])/2
  near=sorted([(dist((cx,cy),((p['rect'].x0+p['rect'].x1)/2,(p['rect'].y0+p['rect'].y1)/2)),i,p,a,b) for i,p,a,b in stems],key=lambda z:z[0])
  if not near or near[0][0]>6.4 or (len(near)>1 and near[1][0]-near[0][0]<1.3):
   unresolved.append({'text':w[4],'text_bbox':[round(v,2) for v in w[:4]],'reason':'switch_stroke_not_unique_or_too_far'});continue
  delta,i,p,a,b=near[0]
  if i in used:
   unresolved.append({'text':w[4],'reason':'switch_stroke_already_claimed','vector_id':i});continue
  used.add(i)
  cand.append({'word':w,'cx':cx,'cy':cy,'vector_path_id':i,'line':p,'distance':delta})
 # Associate a 3 with its closest switch text only, with a strict proximity check.
 associated={}
 for k,w in enumerate(threes):
  x=(w[0]+w[2])/2;y=(w[1]+w[3])/2
  close=sorted([(dist((x,y),(c['cx'],c['cy'])),j) for j,c in enumerate(cand)])
  if close and close[0][0]<9.2 and (len(close)<2 or close[1][0]-close[0][0]>1.7):associated.setdefault(close[0][1],[]).append(w)
 records=[]
 for j,c in enumerate(cand):
  w=c['word'];r=fitz.Rect(w[:4]);line=c['line']['rect']
  has3=bool(associated.get(j,[]))
  full=fitz.Rect(min(r.x0,line.x0),min(r.y0,line.y0),max(r.x1,line.x1),max(r.y1,line.y1))
  marker_words=sorted(associated.get(j,[]),key=lambda t:dist(((t[0]+t[2])/2,(t[1]+t[3])/2),(c['cx'],c['cy'])))[:1] if has3 else []
  for marker in marker_words:full |= fitz.Rect(marker[:4])
  sub='three_way' if has3 else 'single_pole'
  code='S3' if has3 else 'S'
  attrs={'switch_type':sub,'wall_mount_from_legend':True,'label_integral_to_symbol':True}
  if has3:
   attrs['three_way_symbol_modifier']='3'
   if len(associated[j])>1:attrs['modifier_candidates']=len(associated[j])
  rec={
   'id':f'F2402_EL101_SWITCH_path{c["vector_path_id"]}', 'pdf_page':32,'sheet':'EL101','discipline':'lighting',
   'device_code':code,'device_type':'switch','subtype':sub,'attributes':attrs,
   'symbol_bbox':bbox_pdf(full,H),'symbol_center':pt_pdf((line.x0+line.x1)/2,(line.y0+line.y1)/2,H),
   'device_center':None,'wall_connection_point':None,'on_wall':True,
   'placement_rule':'integral_switch_label_and_vector_indicator_located; wall_centerline_intersection_unverified',
   'geometry_source':'15.72pt_wall_switch_indicator_line_plus_adjacent_integral_S_symbol_and_3_modifier',
   'vector_path_ids':[c['vector_path_id']],'wall_vector_path_ids':[],
   'confidence':'medium','verification':'EL101_lighting_legend_S_and_3_definition; unique_vector_switch_indicator_matched; wall_contact_unverified',
   'symbol_bbox_completeness':'switch_indicator_stroke_and_text_designation; excludes_control_circuit_dashes',
   'exact_wall_connection_verified':False,
   'label_bbox':bbox_pdf(r,H),
   'source_label_markers':[{'text':t[4],'bbox_pdf':bbox_pdf(fitz.Rect(t[:4]),H)} for t in [w]+marker_words],
  }
  records.append(rec)
 d.close()
 return records,{'source_sheet':'EL101','source_page':32,'s_glyphs_on_plan':len(sw),'matched_switches':len(records),'by_type':dict(collections.Counter(x['subtype'] for x in records)),'unmatched_s_glyphs':unresolved,'integrated_S3_candidates_not_matched':len([w for w in words if w[4]=='S3'])}
if __name__=='__main__':
 import sys
 rr,report=locate(Path(sys.argv[1]));print(json.dumps(report,indent=2));print('example',rr[0]);
