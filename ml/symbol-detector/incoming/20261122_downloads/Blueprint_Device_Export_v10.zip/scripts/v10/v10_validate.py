#!/usr/bin/env python3
"""Validate all JSONs and spot-verify every new vector path in original PDFs."""
import zipfile,json,collections,fitz,math,sys
from pathlib import Path
ROOT=Path('/mnt/data')
FILE=ROOT/'Blueprint_Device_Export_v10.zip' if len(sys.argv)<2 else Path(sys.argv[1])
FILES={'F2402-01_Final_Bid_Plans_DEVICES.json':'_F2402-01 Final Bid Plans.pdf','Farmhouse_Drawing_Set_V-001_DEVICES.json':'Farmhouse_Drawing_Set_V-001.pdf'}
with zipfile.ZipFile(FILE) as z:
 assert z.testzip() is None
 jsfiles=[n for n in z.namelist() if n.endswith('_DEVICES.json')]
 assert len(jsfiles)==35,len(jsfiles)
 n=0;unique=set();numnew=0;test=[];nnull=0
 for name in jsfiles:
  obj=json.loads(z.read(name));devices=obj['devices'];n+=len(devices)
  for rec in devices:
   assert rec['id'] not in unique,('duplicate ID',rec['id']);unique.add(rec['id'])
   assert rec['device_type'] in obj['taxonomy'] and rec['subtype'] in obj['taxonomy'][rec['device_type']]
   bbox=rec.get('symbol_bbox');assert bbox and len(bbox)==4 and all(isinstance(v,(float,int)) for v in bbox) and bbox[0]<=bbox[2] and bbox[1]<=bbox[3],rec
   point=rec.get('symbol_center');assert point and len(point)==2 and bbox[0]-.1<=point[0]<=bbox[2]+.1 and bbox[1]-.1<=point[1]<=bbox[3]+.1,rec
   if rec['id'].startswith('F2402_EL101_SWITCH_') or rec['id'].startswith('Farmhouse_A1.5_RECESSED_'):
    numnew+=1;test.append((name,rec));assert rec['vector_path_ids']
    if rec.get('device_type')=='switch':
     assert rec['wall_connection_point'] is None and rec['device_center'] is None
     nnull+=1
 assert n==1287,(n,'wrong total')
 assert numnew==40,numnew
 for name,rec in test:
  pdf=FILES[name];doc=fitz.open(ROOT/pdf);page=doc[rec['pdf_page']-1];paths=page.get_drawings();H=page.rect.height
  assert all(0<=vid<len(paths) for vid in rec['vector_path_ids']),(name,rec['id'])
  # Each source referenced path must intersect the recorded complete symbol bbox (0.2pt tolerance)
  bb=rec['symbol_bbox'];Q=fitz.Rect(bb[0]-.25,H-bb[3]-.25,bb[2]+.25,H-bb[1]+.25)
  for vid in rec['vector_path_ids']:
   p=paths[vid];rr=p['rect'];assert rr.x0>=Q.x0 and rr.y0>=Q.y0 and rr.x1<=Q.x1 and rr.y1<=Q.y1,(rec['id'],vid,rr,Q)
  doc.close()
 print(json.dumps({'archive':str(FILE),'pdf_inventories':len(jsfiles),'records_total':n,'records_added_verified':numnew,'new_unverified_switch_wall_points_null':nnull,'status':'passed'},indent=2))
