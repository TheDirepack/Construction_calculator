#!/usr/bin/env python3
"""Non-destructive v9->v10 merge: Missouri EL101 switches and Farmhouse recessed lights.
Run against actual source PDFs; keeps prior record content unchanged.
"""
import json,zipfile,collections
from pathlib import Path
from v10_extract_missouri_switches import locate
from v10_extract_farmhouse_recessed import extract
ROOT=Path('/mnt/data')
BASE=ROOT/'Blueprint_Device_Export_v9.zip'; OUT=ROOT/'Blueprint_Device_Export_v10.zip'

def js(x): return (json.dumps(x,indent=2,ensure_ascii=False)+'\n').encode()
with zipfile.ZipFile(BASE) as z:
 data={k:z.read(k) for k in z.namelist() if k not in ('_extraction_manifest_v9.json','_remaining_work_v9.json')}
 manifest=json.loads(z.read('_extraction_manifest_v9.json'))
 backlog=json.loads(z.read('_remaining_work_v9.json'))
pairs=[
 ('F2402-01_Final_Bid_Plans_DEVICES.json','_F2402-01 Final Bid Plans.pdf',locate,'Missouri EL101 switch glyphs'),
 ('Farmhouse_Drawing_Set_V-001_DEVICES.json','Farmhouse_Drawing_Set_V-001.pdf',extract,'Farmhouse A1.5 recessed lights')]
added=[];reports={}
for filename,pdf,func,description in pairs:
 old=json.loads(data[filename]);new,report=func(ROOT/pdf);reports[pdf]=report
 prior_ids={x['id'] for x in old['devices']};assert len({r['id'] for r in new})==len(new)
 assert prior_ids.isdisjoint({x['id'] for x in new})
 for r in new:
  assert r['device_type'] in old['taxonomy'] and r['subtype'] in old['taxonomy'][r['device_type']],(pdf,r)
 old['devices']+=new
 old['plan_pages_processed']=sorted(set(old['plan_pages_processed'])|{r['pdf_page'] for r in new})
 old['page_results'].append({'extraction_revision':'v10','scope':description,'report':report})
 old['extraction_revision']='v10: '+description+'; all v9 records preserved unmodified'
 old['extraction_status']='partial_vector_instance_extraction'
 old['review_backlog']['unprocessed_remaining']=True
 if filename.startswith('F2402'):
  old['coverage_limit']='EL101 now includes 38 S switch symbols with vector indicator strokes; 3-way modifiers interpreted where supported. Wall-connection coordinates unverified. Integrated S3 and F fan-control glyphs, other power/data/switch and lighting symbols remain incomplete.'
 else:
  old['coverage_limit']='A1.5/A1.6 receptacle symbol extraction plus 2 four-corner recessed-light vector matches; other lighting, wall devices, ceiling fans and switches not exhaustively extracted.'
 c1=collections.Counter(r['device_type'] for r in old['devices'])
 c2=collections.Counter(f"{r['device_type']}/{r['subtype']}" for r in old['devices'])
 old['summary']={'geometry_matched_devices':len(old['devices']),'by_type':dict(sorted(c1.items())),'by_type_and_subtype':dict(sorted(c2.items()))}
 data[filename]=js(old)
 for item in manifest['per_source']:
  if item['source_file']==pdf:
   item['records']=len(old['devices']);item['pages_processed']=old['plan_pages_processed'];item['status']='partial_vector_instance_extraction'
 for item in backlog.get('new_pdf_work',[]):
  if item.get('source_file')==pdf:
   item['status']='partial_vector_instance_extraction';item['pages_processed']=old['plan_pages_processed'];item['records_added']=len(new)
   item['next_target']=old['coverage_limit']
 added+=new
assert len(added)==40,len(added)
manifest['export_version']='v10';manifest['source_archive']=BASE.name
manifest['prior_positioned_device_records']=1247
manifest['added_geometry_matched_device_records']=40
manifest['total_positioned_device_records']=1287
manifest['added_in_v10']={'new_count':40,'by_source':{pdf:len([r for r in added if r['id'].startswith('F2402_' if pdf.startswith('_F2402') else 'Farmhouse_')]) for _,pdf,_,_ in pairs},'switch_subtypes':dict(collections.Counter(r['subtype'] for r in added if r['device_type']=='switch')),'exact_new_wall_connections':0,'taxonomy_changes':0,
 'notes':'38 switch indicators geometrically matched to S/3 designations on Missouri EL101; one integrated S3 variant remains unresolved. Two Farmhouse recessed-light symbols matched by square-corner rings. No guessed wall coordinates; old 1247 records unchanged.'}
manifest.setdefault('limitations',[]).append('v10 adds selected switch and recessed-light symbols only; 35 PDF corpus is not exhaustively processed. Existing v9 records were not re-audited.')
backlog['revision']='v10';backlog['v10_progress']={'scope':manifest['added_in_v10'],'details':reports}
backlog['v10_remaining_priority']=['Missouri EL101: integrated S3 symbol and F fan-control glyphs, wall contact intersections, other switches not fully verified','Farmhouse A1.5/A1.6: switch glyphs, ceiling/fan/wall fixtures other than two recessed lights','Cornish E2/E3/E4: remaining data and switches','Other electrical plans and security sheets throughout corpus']
data['_extraction_manifest_v10.json']=js(manifest)
data['_remaining_work_v10.json']=js(backlog)
scriptdir=Path(__file__).parent
for name in ['v10_extract_missouri_switches.py','v10_extract_farmhouse_recessed.py','v10_build_export.py','v10_validate.py']:
 file=scriptdir/name
 if file.exists():data['scripts/v10/'+name]=file.read_bytes()
data['scripts/v10/README.txt']=b'''v10 supports existing schema 3.1.0 and does not alter v9 device records.\nNew instances: 38 Missouri EL101 switches (27 single pole; 11 three way), 2 Farmhouse A1.5 recessed-light symbols.\nExtractors require PyMuPDF and the corresponding source PDFs.\nSymbols include actual source vector path indexes; wall intersections are unverified and intentionally null.\nRun v10_validate.py on completed archive after creation.\n'''
assert not any(f.lower().endswith(('.png','.jpg','.jpeg','.webp')) for f in data)
with zipfile.ZipFile(OUT,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f,raw in sorted(data.items()):z.writestr(f,raw)
print('wrote',OUT,'files',len(data),'records added',len(added))
