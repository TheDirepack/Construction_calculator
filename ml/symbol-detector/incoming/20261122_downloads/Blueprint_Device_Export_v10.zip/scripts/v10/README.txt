v10 supports existing schema 3.1.0 and does not alter v9 device records.
New instances: 38 Missouri EL101 switches (27 single pole; 11 three way), 2 Farmhouse A1.5 recessed-light symbols.
Extractors require PyMuPDF and the corresponding source PDFs.
Symbols include actual source vector path indexes; wall intersections are unverified and intentionally null.
Run v10_validate.py on completed archive after creation.
