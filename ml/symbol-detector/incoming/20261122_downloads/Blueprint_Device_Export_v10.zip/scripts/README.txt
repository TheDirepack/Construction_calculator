VECTOR DEVICE EXTRACTION SCRIPTS — V7

Core v7: extract_new_sources.py, build_export_v7.py
Requires Python 3.10+ and PyMuPDF.

Usage (from a directory containing the scripts):
 python build_export_v7.py --pdf-root /path/to/20/new/PDFs --prior-zip /path/to/Blueprint_Device_JSONs_Standardized_v6.zip --out /path/to/new_export.zip

The PDF root must include ALL 20 newly uploaded PDF filenames as in the manifest.
This is a targeted conservative matcher, not comprehensive optical detection.

Historical scripts are supplied separately in scripts/history, for provenance.
V4-V6 scripts contain session-specific absolute paths and may require adapting
paths and prior intermediate archives to run. V1-V3 source code was not located
in the available working directory. Legacy extract_devices.py targets the
NMNH Baird PDF, not the current 15+20 PDF inventory.

Coordinates are PDF points using displayed-page bottom-left origin.
For scanned sheets, no vector-derived device positions have been claimed.
