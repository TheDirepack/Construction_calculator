v9: Adds only actual vector-matched receptacle glyphs from Farmhouse A1.5/A1.6 and Missouri EP101.
Run extract_farmhouse_v9.py /path/to/Farmhouse_Drawing_Set_V-001.pdf
Run extract_missouri_power_v9.py '/path/to/_F2402-01 Final Bid Plans.pdf'
Requires PyMuPDF. Original baseline v8 and exact drawing PDFs are required to reproduce.
Notes: Farmhouse original legend says ELECTRIC OUTLET only; duplex inference from 2-contact glyph is explicitly marked.
Missouri 208V and USB outlets remain receptacle/special_purpose with attributes; no taxonomy expansion.
Exact wall contact remains null when no independent wall vector is found.
All 1127 previous records preserved and unreviewed here; 120 new records only.
