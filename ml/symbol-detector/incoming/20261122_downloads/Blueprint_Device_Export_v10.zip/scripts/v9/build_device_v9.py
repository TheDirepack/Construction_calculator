#!/usr/bin/env python3
"""Merge conservative v9 Farmhouse/Missouri receptacle instances into v8 JSONs.
Does not rewrite prior 1127 existing device records or expand taxonomy.
"""
from pathlib import Path
import zipfile,json,collections,copy,sys
ROOT=Path('/mnt/data'); BASE=ROOT/'Blueprint_Device_Export_v8.zip'; OUT=ROOT/'Blueprint_Device_Export_v9.zip'
PAIRS=[('Farmhouse_Drawing_Set_V-001_DEVICES.json','farmhouse_v9_new.json','Farmhouse_Drawing_Set_V-001.pdf'),('F2402-01_Final_Bid_Plans_DEVICES.json','missouri_v9_new.json','_F2402-01 Final Bid Plans.pdf')]

def dumps(o):return (json.dumps(o,indent=2,ensure_ascii=False)+'\n').encode('utf-8')
with zipfile.ZipFile(BASE) as z:
 content={name:z.read(name) for name in z.namelist() if name not in ('_extraction_manifest_v8.json','_remaining_work_v8.json')}
 manifest=json.loads(z.read('_extraction_manifest_v8.json'))
 backlog=json.loads(z.read('_remaining_work_v8.json'))
additions=[]
for filename,source_new,source_pdf in PAIRS:
 data=json.loads(content[filename]);new=json.loads((ROOT/source_new).read_text());dev=new['devices']
 ids={r['id'] for r in data['devices']}; assert not ids.intersection({r['id'] for r in dev})
 data['devices'].extend(dev)
 pages=sorted(set(data['plan_pages_processed'])|{r['pdf_page'] for r in dev})
 data['plan_pages_processed']=pages
 if source_pdf.startswith('Farmhouse'):
  data['page_results']+=new['audits']
  data['coverage_limit']='A1.5/A1.6 receptacle symbols now matched; switches, lighting, and ceiling fans remain unextracted. Generic outlet legend does not explicitly specify duplex; conventional paired-contact symbolism used with medium confidence.'
 else:
  data['page_results'].append({k:v for k,v in new['audits'].items() if k!='unresolved'})
  data['coverage_limit']='EP101 receptacle symbols and EL101 C1/C2 light fixtures matched; EP101 data/other power symbols and EL101 switches/fixtures remain incomplete.'
  source_legend=[
   ('receptacle','duplex','EP101 RECEPTACLE graphic: circle with parallel bars'),
   ('receptacle','gfci_duplex','EP101 GFCI DUPLEX CONVENIENCE RECEPTACLE: one-sided hatching'),
   ('receptacle','quad','EP101 QUADRUPLEX CONVENIENCE RECEPTACLE: crossed pairs; legend only, no matched instances'),
   ('receptacle','special_purpose','EP101 208V RECEPTACLE: two-sided hatching'),
   ('receptacle','special_purpose','EP101 USB OUTLET: USB-A / USB-C charging'),
   ('data_outlet','data_telephone','EP101 DATA / PHONE JACK: triangle; no matched instances')]
  for ty,sub,desc in source_legend:
   if not any(r.get('description')==desc for r in data['legend_types']):data['legend_types'].append({'pdf_page':31,'device_type':ty,'subtype':sub,'description':desc,'instance_status':'legend only, not an instance'})
 data['extraction_status']='partial_vector_instance_extraction'
 data['extraction_revision']='v9: added receptor glyphs on selected electrical plans; prior records carried unchanged'
 data['review_backlog']={**data.get('review_backlog',{}),'unprocessed_remaining':True,'v9_note':'Symbols outside the two processed receptacle classes still pending; do not equate page processed with all classes extracted.'}
 devtypes=collections.Counter(r['device_type'] for r in data['devices'])
 subtypes=collections.Counter(f"{r['device_type']}/{r['subtype']}" for r in data['devices'])
 data['summary']={'geometry_matched_devices':len(data['devices']),'by_type':dict(sorted(devtypes.items())),'by_type_and_subtype':dict(sorted(subtypes.items()))}
 content[filename]=dumps(data)
 for row in manifest['per_source']:
  if row['source_file']==source_pdf:
   row['records']=len(data['devices']);row['status']='partial_vector_instance_extraction';row['pages_processed']=pages
 for row in backlog['new_pdf_work']:
  if row['source_file']==source_pdf:
   row['status']='partial_vector_instance_extraction';row['pages_processed']=pages;row['records_added']=len(dev)
   row['next_target']='Additional switch, data, lighting, and other device symbols remain; v9 added only geometrically matched receptacles.'
 additions += dev
assert len(additions)==120
manifest['export_version']='v9';manifest['schema_version']='3.1.0';manifest['source_archive']='Blueprint_Device_Export_v8.zip'
manifest['prior_positioned_device_records']=1127;manifest['added_geometry_matched_device_records']=120;manifest['total_positioned_device_records']=1247
manifest['added_in_v9']={'source_count':2,'total_new':120,'by_pdf':{
 'Farmhouse_Drawing_Set_V-001.pdf':{'added':33,'pages':[9,10],'duplex':26,'gfci_duplex':7,'wall_intersections_verified':33},
 '_F2402-01 Final Bid Plans.pdf':{'added':87,'pages':[31],'duplex':45,'gfci_duplex':36,'208v':2,'usb':4,'wall_intersections_verified':66}},
 'new_wall_intersections_verified':99,
 'taxonomy_changes':0,
 'note':'Prior 1127 records unchanged. Generic farmhouse electric-outlet legend does not explicitly state duplex; subtype inferred from paired bars, medium confidence where label does not specify GFCI.'}
manifest['limitations'].append('v9 matches receptacles on Farmhouse A1.5/A1.6 and Missouri EP101 only. Other device classes and remaining plans are not exhaustively extracted.')
backlog['revision']='v9';backlog['v9_progress']=manifest['added_in_v9']
backlog['v9_remaining_priority']=['Cornish E-2/E-3/E-4: additional data outlets and switches beyond already matched 80 receptacles',
 'Missouri EP101: data/phone and power symbols not in 9pt receptacle motif; EL101 switches and other fixture types',
 'Farmhouse A1.5/A1.6: switches, ceiling/wall/recessed lights, and ceiling fans',
 'Other electrical plan sheets across 35-PDF corpus not fully extracted.']
content['_extraction_manifest_v9.json']=dumps(manifest)
content['_remaining_work_v9.json']=dumps(backlog)
content['scripts/v9/extract_farmhouse_v9.py']=(ROOT/'extract_farmhouse_v9.py').read_bytes()
content['scripts/v9/extract_missouri_power_v9.py']=(ROOT/'extract_missouri_power_v9.py').read_bytes()
content['scripts/v9/validate_device_v9.py']=(ROOT/'validate_device_v9.py').read_bytes()
content['scripts/v9/build_device_v9.py']=(ROOT/'build_device_v9.py').read_bytes()
content['scripts/v9/README.txt']=b'''v9: Adds only actual vector-matched receptacle glyphs from Farmhouse A1.5/A1.6 and Missouri EP101.\nRun extract_farmhouse_v9.py /path/to/Farmhouse_Drawing_Set_V-001.pdf\nRun extract_missouri_power_v9.py '/path/to/_F2402-01 Final Bid Plans.pdf'\nRequires PyMuPDF. Original baseline v8 and exact drawing PDFs are required to reproduce.\nNotes: Farmhouse original legend says ELECTRIC OUTLET only; duplex inference from 2-contact glyph is explicitly marked.\nMissouri 208V and USB outlets remain receptacle/special_purpose with attributes; no taxonomy expansion.\nExact wall contact remains null when no independent wall vector is found.\nAll 1127 previous records preserved and unreviewed here; 120 new records only.\n'''
# Reject any user-unrequested image payloads
assert not any(n.lower().endswith(('.png','.jpg','.jpeg','.webp')) for n in content)
with zipfile.ZipFile(OUT,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for filename,data in sorted(content.items()):z.writestr(filename,data)
print(OUT,OUT.stat().st_size,'bytes',len(content),'zip members')
