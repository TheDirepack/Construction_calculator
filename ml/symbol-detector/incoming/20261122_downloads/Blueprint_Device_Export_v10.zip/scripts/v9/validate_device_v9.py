#!/usr/bin/env python3
"""Validate v9 additions against exact PDF pages and original PyMuPDF path indices."""
from pathlib import Path
import fitz,json,math,zipfile,collections
BASE=Path('/mnt/data')
PAIRS=[('Farmhouse_Drawing_Set_V-001.pdf','Farmhouse_Drawing_Set_V-001_DEVICES.json','farmhouse_v9_new.json'),('_F2402-01 Final Bid Plans.pdf','F2402-01_Final_Bid_Plans_DEVICES.json','missouri_v9_new.json')]

def validate(records,path):
 doc=fitz.open(path);num_wall=0;types=collections.Counter();warnings=[]
 for r in records:
  pn=r['pdf_page'];pg=doc[pn-1];H=pg.rect.height;W=pg.rect.width
  D=pg.get_drawings(); ids=r['vector_path_ids']
  assert len(set(ids))==len(ids),r['id']
  assert all(0<=j<len(D) for j in ids),r['id']
  x0,y0,x1,y1=r['symbol_bbox']; assert 0<=x0<x1<=W and 0<=y0<y1<=H,r['id']
  cx,cy=r['symbol_center'];assert x0-.05<=cx<=x1+.05 and y0-.05<=cy<=y1+.05,r['id']
  # All referenced glyph vectors must lie inside the final symbol bbox
  for i in ids:
   b=D[i]['rect'];glyph=(b.x0,H-b.y1,b.x1,H-b.y0)
   if not all(abs(g-t)<.14 or g>=t-.14 for g,t in zip(glyph[:2],(x0,y0))) or glyph[2]>x1+.14 or glyph[3]>y1+.14:
    warnings.append(('bbox_no_contain',r['id'],i,glyph))
  if r.get('wall_connection_point') is not None:
   num_wall+=1
   wx,wy=r['wall_connection_point'];y=H-wy
   assert r.get('exact_wall_connection_verified') is True and r['device_center']==[wx,wy]
   assert r['wall_vector_path_ids'],r['id']
   on=False
   for i in r['wall_vector_path_ids']:
    assert 0<=i<len(D)
    for it in D[i]['items']:
     if it[0]!='l':continue
     a,b=it[1:3]
     if abs(a.x-b.x)<.15 and abs(wx-a.x)<.24 and min(a.y,b.y)-.15<=y<=max(a.y,b.y)+.15:on=True
     if abs(a.y-b.y)<.15 and abs(y-a.y)<.24 and min(a.x,b.x)-.15<=wx<=max(a.x,b.x)+.15:on=True
   assert on,('wall_no_intersection',r['id'])
  else:
   assert r['device_center'] is None and r['exact_wall_connection_verified'] is False,r['id']
  types[r['subtype']]+=1
 assert len(set(r['id'] for r in records))==len(records)
 doc.close();return {'count':len(records),'wall_intersection_verified':num_wall,'by_subtype':dict(types),'warnings':warnings}

if __name__=='__main__':
 for pdf,__,file in PAIRS:
  r=json.loads((BASE/file).read_text())['devices'];v=validate(r,BASE/pdf)
  print(pdf, json.dumps({k:x for k,x in v.items() if k!='warnings'},indent=2), 'warnings',v['warnings'][:2]);assert not v['warnings']
