#!/usr/bin/env python3
"""Vector-driven receptacle matching for Missouri Director's House EP101 (PDF p31).
Matches 9-point circle with its contact strokes. Fills match published legend:
no shading=duplex; one side hatched=GFCI; both sides hatched=208V special;
U text with two fill paths=USB-A/C special purpose. Quad requires four contact
strokes and is not guessed from two. Wall connection requires independent vector.
"""
from pathlib import Path
import fitz,math,json,collections
PDF='_F2402-01 Final Bid Plans.pdf'
def mid(r):return ((r.x0+r.x1)/2,(r.y0+r.y1)/2)
def pbb(r,H):return [round(r.x0,3),round(H-r.y1,3),round(r.x1,3),round(H-r.y0,3)]
def pcenter(p,H):return [round(p[0],3),round(H-p[1],3)]
def istline(v):return v['type']=='s' and len(v['items'])==1 and v['items'][0][0]=='l'
def find(path:Path):
 d=fitz.open(path);pg=d[30];H=pg.rect.height;paths=pg.get_drawings();words=pg.get_text('words');res=[];unresolved=[]
 # independent structural lines for verified wall interfaces
 walls=[]
 for i,z in enumerate(paths):
  for it in z['items']:
   if it[0]!='l':continue
   a,b=it[1:3]
   if (abs(a.x-b.x)<.15 and abs(a.y-b.y)>18) or (abs(a.y-b.y)<.15 and abs(a.x-b.x)>18):
    walls.append((i,float(a.x),float(a.y),float(b.x),float(b.y)))
 for i,dd in enumerate(paths):
  r=dd['rect'];cx,cy=mid(r)
  if not(8.85<r.width<9.15 and 8.85<r.height<9.15 and len(dd['items'])==4 and all(it[0]=='c' for it in dd['items'])):continue
  if not(350<cx<2250 and 450<cy<1680):continue
  local=[]
  for j in range(max(0,i-110),i):
   z=paths[j];rr=z['rect'];mx,my=mid(rr)
   if math.hypot(mx-cx,my-cy)>8:continue
   if istline(z) and 8.15<max(rr.width,rr.height)<8.55 and min(rr.width,rr.height)<.11:local.append((j,rr))
  horiz=[(j,rr) for j,rr in local if rr.width>rr.height]
  vert=[(j,rr) for j,rr in local if rr.height>rr.width]
  # Standard/208V/GFCI/quad glyphs have two 8.4pt bars spanning the circle.
  # USB glyph instead has a U character and two legs outside the circle.
  pairs=[]
  for bars,ornt in ((horiz,'h'),(vert,'v')):
   for a,(ia,ra) in enumerate(bars):
    for ib,rb in bars[a+1:]:
     sep=abs((ra.y0+ra.y1)/2-(rb.y0+rb.y1)/2) if ornt=='h' else abs((ra.x0+ra.x1)/2-(rb.x0+rb.x1)/2)
     if abs(sep-3.36)>.23:continue
     if ornt=='h' and abs((ra.x0+ra.x1)/2-cx)>.5:continue
     if ornt=='v' and abs((ra.y0+ra.y1)/2-cy)>.5:continue
     pairs.append((ornt,ia,ra,ib,rb))
  fillids=[]
  for j in range(max(0,i-110),i):
   q=paths[j];rr=q['rect'];mx,my=mid(rr)
   if q['type'] in ('f','fs') and rr.width<14 and rr.height<14 and math.hypot(mx-cx,my-cy)<7:fillids.append(j)
  # Look only for complete evidence, leave other 9pt circles unresolved.
  glyph=None;orientation=None;attachment=None;geomids=[i];geomrects=[r]
  if len(pairs)==1:
   orientation,ia,ra,ib,rb=pairs[0];geomids += [ia,ib];geomrects += [ra,rb]
   # Connection strokes (4.2pt) must start at the bar endpoints and head out of the circle.
   # Two same-direction parallel 4.2pt lines ending at the wall.
   conn=[]
   for j in range(max(0,i-12),i):
    v=paths[j]; rr=v['rect']
    if not istline(v):continue
    dim=max(rr.width,rr.height)
    if not(4.1<dim<4.5 and min(rr.width,rr.height)<.11):continue
    if orientation=='v' and rr.height<rr.width:continue
    if orientation=='h' and rr.width<rr.height:continue
    if math.hypot(*[mid(rr)[n]-[cx,cy][n] for n in range(2)])>8.2:continue
    conn.append((j,rr))
   # For some signs, two extensions might be far and other strokes are annotations.
   if len(conn)!=2:
    unresolved.append({'circle_path_id':i,'reason':'pair_found_but_no_unique_connection_strokes','nconn':len(conn)});continue
   # Wall intersection = midpoint between the far endpoints of both outward strokes.
   (i0,z0),(i1,z1)=conn
   if orientation=='v':
    # each extension's outer endpoint is furthest from the center along Y
    pos=[max((zz.y0,zz.y1),key=lambda y:abs(y-cy)) for zz in (z0,z1)]
    if abs(pos[0]-pos[1])>.20:continue
    attachment=((z0.x0+z1.x0)/2,(pos[0]+pos[1])/2)
   else:
    pos=[max((zz.x0,zz.x1),key=lambda x:abs(x-cx)) for zz in (z0,z1)]
    if abs(pos[0]-pos[1])>.20:continue
    attachment=((pos[0]+pos[1])/2,(z0.y0+z1.y0)/2)
   geomids+=[i0,i1];geomrects+=[z0,z1]
   if len(fillids)==0:glyph='duplex'
   elif len(fillids)==11:glyph='gfci_duplex'
   elif len(fillids)>=55:glyph='special_purpose_208v'
   else:
    unresolved.append({'circle_path_id':i,'reason':'fill_pattern_ambiguous','fills':len(fillids)});continue
  elif not pairs and len(fillids) in (0,2):
   w=[word for word in words if word[4]=='U' and math.hypot((word[0]+word[2])/2-cx,(word[1]+word[3])/2-cy)<4]
   if len(w)!=1:
    unresolved.append({'circle_path_id':i,'reason':'usb_U_annotation_not_unique'});continue
   glyph='usb';
   # The USB icon rotates with the wall. Require exactly two short, parallel
   # (~4.2pt) terminal legs that overlap the circle's top/right/bottom/left edge.
   legs=[]
   for j in range(max(0,i-10),i):
    v=paths[j];rr=v['rect']
    if not istline(v):continue
    if not(4.05<max(rr.width,rr.height)<4.48 and min(rr.width,rr.height)<.12):continue
    mx,my=mid(rr)
    if math.hypot(mx-cx,my-cy)>7.6:continue
    if not (rr.x0<=r.x1+.5 and rr.x1>=r.x0-.5 and rr.y0<=r.y1+.5 and rr.y1>=r.y0-.5):continue
    legs.append((j,rr))
   if len(legs)!=2:unresolved.append({'circle_path_id':i,'reason':'USB_leg_paths_not_unique'});continue
   geomids += [j for j,_ in legs]+fillids;geomrects += [rr for _,rr in legs]
  else:
   unresolved.append({'circle_path_id':i,'reason':'neither_unique_contact_pair_nor_USB','pairs':len(pairs),'fills':len(fillids)});continue
  # Source legend excludes claims about whether the symbol is on a wall or not if unverified.
  attach=None;wall_ids=[]
  if attachment is not None:
   ax,ay=attachment
   for j,x0,y0,x1,y1 in walls:
    if j in geomids:continue
    if orientation=='h' and abs(x0-x1)<.15 and abs(x0-ax)<.21 and min(y0,y1)-.15<=ay<=max(y0,y1)+.15:wall_ids.append(j)
    if orientation=='v' and abs(y0-y1)<.15 and abs(y0-ay)<.21 and min(x0,x1)-.15<=ax<=max(x0,x1)+.15:wall_ids.append(j)
  wall_ids=sorted(set(wall_ids)); verified=bool(wall_ids)
  rect=fitz.Rect(min(x.x0 for x in geomrects),min(x.y0 for x in geomrects),max(x.x1 for x in geomrects),max(x.y1 for x in geomrects))
  attrs={}
  if glyph=='gfci_duplex':attrs['gfci']=True
  if glyph=='special_purpose_208v':attrs.update({'voltage':208,'receptacle_variant':'208v'})
  if glyph=='usb':attrs.update({'charging_ports':['USB-A','USB-C'],'receptacle_variant':'usb'})
  subtype='special_purpose' if glyph in ('usb','special_purpose_208v') else glyph
  rec={'id':f'F2402_EP101_RECEPT_path{i}','pdf_page':31,'sheet':'EP101','discipline':'electrical',
       'device_code':{'gfci_duplex':'GFCI','special_purpose_208v':'208V','usb':'USB'}.get(glyph),
       'device_type':'receptacle','subtype':subtype,'attributes':attrs,
       'symbol_bbox':pbb(rect,H),'symbol_center':pcenter((cx,cy),H),
       'device_center':pcenter(attachment,H) if verified else None,
       'wall_connection_point':pcenter(attachment,H) if verified else None,
       'on_wall':True,
       'placement_rule':'centerline_of_contact_strokes_at_matching_wall_vector' if verified else 'symbol_center_only;wall_intersection_unverified',
       'geometry_source':'9pt_circle_with_measured_contact_strokes_and_legend_matched_fill_pattern',
       'vector_path_ids':sorted(set(geomids)), 'wall_vector_path_ids':wall_ids,
       'confidence':'high' if verified else 'medium',
       'verification':'vector_outline_and_symbol_legend; '+('verified_wall_intersection' if verified else 'wall_position_unresolved'),
       'symbol_bbox_completeness':'all_strokes_except_hatch_fills','exact_wall_connection_verified':verified}
  res.append(rec)
 d.close();return res,{'pdf_page':31,'sheet':'EP101','candidate_circle_paths':87,'matched':len(res),'by_subtype':dict(collections.Counter(x['subtype'] for x in res)),'verified_wall_points':sum(bool(x['exact_wall_connection_verified']) for x in res),'unresolved':unresolved}
if __name__=='__main__':
 import sys
 r,a=find(Path(sys.argv[1]));print('TOTAL',len(r),a['by_subtype'],'WALL',a['verified_wall_points'],'unresolved',len(a['unresolved']));print('unresolved_sample',a['unresolved'][:7]);Path('/mnt/data/missouri_v9_new.json').write_text(json.dumps({'devices':r,'audits':a},indent=2))
