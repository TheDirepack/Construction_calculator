#!/usr/bin/env python3
"""Conservative vector matcher for Farmhouse A1.5/A1.6 receptacle glyphs.

Matches one cubic-circle and two parallel 9-point contact bars at a fixed offset.
An adjacent GFCI annotation marks protected receptacles. Coordinates use the
existing dataset PDF-point bottom-left convention. Does not infer unseen wall
connections; intersections require a distinct referenced wall vector segment.
"""
from __future__ import annotations
import fitz, math, json
from pathlib import Path
PDF='Farmhouse_Drawing_Set_V-001.pdf'

def bb(r,H):return [round(r.x0,3),round(H-r.y1,3),round(r.x1,3),round(H-r.y0,3)]
def center(r,H):return [round((r.x0+r.x1)/2,3),round(H-(r.y0+r.y1)/2,3)]
def is_line(v):return len(v['items'])==1 and v['items'][0][0]=='l' and v['type']=='s'
def detect(path: Path):
 doc=fitz.open(path);allrecords=[];audits=[]
 for page_num in (9,10):
  pg=doc[page_num-1]; H=pg.rect.height;paths=pg.get_drawings();words=pg.get_text('words');recognized=[]
  segments=[]
  for j,p in enumerate(paths):
   for it in p['items']:
    if it[0]=='l':
     a,b=it[1:3];segments.append((j,float(a.x),float(a.y),float(b.x),float(b.y)))
  for i,d in enumerate(paths):
   r=d['rect'];its=d['items']
   if not(6.07<r.width<6.19 and 6.07<r.height<6.19 and len(its)==4 and all(it[0]=='c' for it in its) and d['type']=='s'):continue
   cx=(r.x0+r.x1)/2;cy=(r.y0+r.y1)/2
   bars=[]
   for j in range(max(0,i-4),min(len(paths),i+5)):
    if not is_line(paths[j]):continue
    rr=paths[j]['rect'];hr=rr.height;wr=rr.width
    if not(8.95<max(hr,wr)<9.20 and min(hr,wr)<.12):continue
    if math.hypot((rr.x0+rr.x1)/2-cx,(rr.y0+rr.y1)/2-cy)<3.8:
     bars.append((j,rr))
   combos=[]
   for a_idx,(ia,ra) in enumerate(bars):
    for ib,rb in bars[a_idx+1:]:
     horiz=ra.width>ra.height and rb.width>rb.height
     vert=ra.height>ra.width and rb.height>rb.width
     if horiz:
      if abs(ra.x0-rb.x0)>.13 or abs(ra.x1-rb.x1)>.13 or abs(abs(ra.y0-rb.y0)-2.28)>.25:continue
      x0=min(ra.x0,rb.x0);x1=max(ra.x1,rb.x1);y0=(ra.y0+rb.y0)/2
      far_x=x0 if abs(x0-cx)>abs(x1-cx) else x1
      attach=(far_x,y0);orient='horizontal'
     elif vert:
      if abs(ra.y0-rb.y0)>.13 or abs(ra.y1-rb.y1)>.13 or abs(abs(ra.x0-rb.x0)-2.28)>.25:continue
      y0=min(ra.y0,rb.y0);y1=max(ra.y1,rb.y1);x0=(ra.x0+rb.x0)/2
      far_y=y0 if abs(y0-cy)>abs(y1-cy) else y1
      attach=(x0,far_y);orient='vertical'
     else:continue
     combos.append((ia,ra,ib,rb,attach,orient))
   if len(combos)!=1:continue
   ia,ra,ib,rb,attach,orient=combos[0]
   nearwords=[w for w in words if math.hypot((w[0]+w[2])/2-cx,(w[1]+w[3])/2-cy)<17.0]
   marker=[w for w in nearwords if w[4].strip().upper() in ('GFCI','GFI','GF')]
   weather=[w for w in nearwords if w[4].strip().upper() in ('WP','W.P.')]
   # Device outline must be unique on the plan; reject if center lies in title block.
   if not(250<cx<970 and 150<cy<565):continue
   # Exact wall connection only with an independent, non-symbol wall stroke
   wx,wy=attach;wall_ids=[]
   for j,ax,ay,bx,by in segments:
    if j in (i,ia,ib):continue
    if orient=='horizontal':
     if abs(ax-bx)<.11 and abs(by-ay)>12 and abs(ax-wx)<.19 and min(ay,by)-.1<=wy<=max(ay,by)+.1:wall_ids.append(j)
    else:
     if abs(ay-by)<.11 and abs(bx-ax)>12 and abs(ay-wy)<.19 and min(ax,bx)-.1<=wx<=max(ax,bx)+.1:wall_ids.append(j)
   # Distinct wall paths only: wall path ID must not itself be immediate glyph neighbor.
   wall_ids=sorted(set(wall_ids));verified=bool(wall_ids)
   full=fitz.Rect(min(r.x0,ra.x0,rb.x0),min(r.y0,ra.y0,rb.y0),max(r.x1,ra.x1,rb.x1),max(r.y1,ra.y1,rb.y1))
   att=[round(wx,3),round(H-wy,3)] if verified else None
   obj={'id':f'Farmhouse_A1.{page_num-4}_RECEPT_path{i}','pdf_page':page_num,'sheet':f'A1.{page_num-4}',
        'discipline':'electrical','device_code':'GFCI' if marker else None,
        'device_type':'receptacle','subtype':'gfci_duplex' if marker else 'duplex',
        'attributes':{'gfci':bool(marker),**({'weatherproof':True} if weather else {}),
                      'outlet_form_evidence':'duplex_inferred_from_conventional_pair_of_contact_strokes; original_legend_only_says_electric_outlet'},
        'symbol_bbox':bb(full,H),'symbol_center':center(r,H),
        'device_center':att,'wall_connection_point':att,'on_wall':True,
        'placement_rule':'centerline_of_contact_bars_intersecting_wall_vector' if verified else 'symbol_center_only;wall_intersection_unverified',
        'geometry_source':'6.12pt_closed_cubic_circle_with_two_9pt_parallel_contact_strokes',
        'vector_path_ids':sorted([i,ia,ib]),'wall_vector_path_ids':wall_ids,
        'confidence':'high' if (verified and bool(marker)) else 'medium','verification':'vector_symbol_matched_to_page1_generic_electric_outlet_legend; duplex_form_inferred; '+('wall_intersection_verified' if verified else 'wall_intersection_unresolved'),
        'symbol_bbox_completeness':'full_circle_and_contact_strokes','exact_wall_connection_verified':verified,
        'source_label_markers':[{'text':w[4],'bbox_pdf':bb(fitz.Rect(w[:4]),H)} for w in marker+weather]}
   recognized.append(obj)
  audits.append({'pdf_page':page_num,'sheet':f'A1.{page_num-4}','receptacles':len(recognized),'gfci':sum(x['subtype']=='gfci_duplex' for x in recognized),'verified_wall_points':sum(x['exact_wall_connection_verified'] for x in recognized)})
  allrecords.extend(recognized)
 return allrecords,audits
if __name__=='__main__':
 import sys
 r,a=detect(Path(sys.argv[1]));print(json.dumps(a,indent=2));print('total',len(r));Path('/mnt/data/farmhouse_v9_new.json').write_text(json.dumps({'devices':r,'audits':a},indent=2))
