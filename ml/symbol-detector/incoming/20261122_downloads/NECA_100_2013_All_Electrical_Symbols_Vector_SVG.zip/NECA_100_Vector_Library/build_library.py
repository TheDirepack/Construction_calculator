#!/usr/bin/env python3
"""Extract NECA 100-2013 table symbols and alternate fire-safety figures into path-only SVGs.

Input must be user-provided source PDF. Extraction retains native PDF vector paths.
When embedded bitmaps are used for the artwork, contour-trace them into editable SVG paths.
Symbol metadata contains original PDF page and source rectangle for traceability.
"""
import base64
import collections
import io
import json
import os
from pathlib import Path
import re
import textwrap
from xml.etree import ElementTree as ET

import cv2
import fitz
import numpy as np
from PIL import Image, ImageOps

SOURCE = Path(__file__).with_name('NECA_100-2013_source.pdf')
OUT = Path(__file__).parent
SYMBOL_DIR = OUT / 'svg'
SYMBOL_DIR.mkdir(parents=True, exist_ok=True)
SVG_NS='http://www.w3.org/2000/svg'
XLINK_NS='http://www.w3.org/1999/xlink'
ET.register_namespace('',SVG_NS)
ET.register_namespace('xlink',XLINK_NS)
ET.register_namespace('inkscape', 'http://www.inkscape.org/namespaces/inkscape')

doc=fitz.open(SOURCE)
entries=[]
statistics=collections.Counter()

def clean(text):
    text=re.sub(r'\s+', ' ', text).replace('\x07',' ').strip()
    return text

def raster_to_vector(img_data):
    """Image contours as SVG compound paths, with holes preserved (even-odd rule)."""
    im=Image.open(io.BytesIO(img_data)).convert('RGBA')
    rgba=np.asarray(im)
    if np.max(rgba[:,:,3])<10:
        return '', 0
    # Every raster symbol in this source is monochrome, either opaque black-on-white
    # or transparent dark pixels. Reject anti-aliased halos as background.
    rgb=rgba[:,:,:3].astype(np.float32)
    luminance=0.2126*rgb[:,:,0]+0.7152*rgb[:,:,1]+0.0722*rgb[:,:,2]
    alpha=rgba[:,:,3].astype(np.float32)
    mask=((luminance<175)&(alpha>85)).astype(np.uint8)*255
    # Contours preserve symbol's filled black regions, including counters and hollows.
    outlines, _=cv2.findContours(mask,cv2.RETR_LIST,cv2.CHAIN_APPROX_SIMPLE)
    commands=[]
    for c in outlines:
        if len(c)<3 or abs(cv2.contourArea(c))<0.2:
            continue
        approx=cv2.approxPolyDP(c,epsilon=0.42,closed=True)
        arr=approx[:,0,:]
        if len(arr)<3: continue
        commands.append('M'+' L'.join('%s,%s'%(int(x),int(y)) for x,y in arr)+' Z')
    return ' '.join(commands),len(commands)

def path_only(svg):
    """Replace all embedded bitmap/image nodes with vector contours, preserving SVG transforms."""
    root=ET.fromstring(svg)
    image_count=0; contour_count=0
    for parent in root.iter():
        for i,ch in enumerate(list(parent)):
            if ch.tag != '{%s}image'%SVG_NS: continue
            image_count+=1
            url=ch.attrib.get('{%s}href'%XLINK_NS,'')
            if not url.startswith('data:image/'):
                raise ValueError('Non-embedded bitmap image encountered')
            payload=base64.b64decode(re.sub(r'\s+','',url.split(',',1)[1]))
            d,num=raster_to_vector(payload)
            contour_count+=num
            group=ET.Element('{%s}g'%SVG_NS)
            for key,val in ch.attrib.items():
                if key!='{%s}href'%XLINK_NS and key not in ('width','height','preserveAspectRatio','x','y'):
                    group.set(key,val)
            x=float(ch.get('x','0'));y=float(ch.get('y','0'))
            if x or y:
                previous=group.get('transform','')
                group.set('transform',(previous+' translate(%g %g)'%(x,y)).strip())
            # In PDF-produced SVG, each image's own native width/height is matched
            # by a surrounding matrix of a <use>; keep image-local pixel coords.
            if d:
                path=ET.SubElement(group,'{%s}path'%SVG_NS)
                path.set('d',d)
                path.set('fill','#000')
                path.set('fill-rule','evenodd')
            parent.remove(ch)
            parent.insert(i,group)
    raw=ET.tostring(root,encoding='unicode',xml_declaration=False)
    if '<image' in raw or 'data:image/' in raw or '<text' in raw:
        raise ValueError('Raster image or editable font text remains')
    return raw,image_count,contour_count

NUM_RE=re.compile(r'(?:1[0-4]|[1-9])\.\s?\d{3}$')

def horizontal_lines(page):
    found=[]
    for path in page.get_drawings():
        for item in path['items']:
            if item[0]!='l':continue
            a,b=item[1],item[2]
            if abs(a.y-b.y)<0.35 and abs(a.x-b.x)>430 and 100<a.y<736:
                found.append(round(a.y,1))
    return sorted(set(found))

def section(code):
    key=code.split('.')[0]
    remainder=int(code.split('.')[1])
    if key=='1':
        return 'Raceways' if remainder<100 else ('Raceways - Indicators' if remainder<200 else 'Raceways - Boxes and Busways')
    if key=='2':
        return ('Luminaires' if remainder<100 else 'Luminaires - Mounting Modifiers' if remainder<200 else 'Luminaires - Orientation Modifiers' if remainder<300 else 'Luminaires - Emergency Modifiers' if remainder<400 else 'Luminaires - Extended Modifiers')
    if key=='3':return 'Outlets and Receptacles'
    if key=='4':return 'Switches and Sensors'
    if key=='5':return 'Motorized and HVAC Equipment' if remainder>=100 else 'Motor and HVAC Controls'
    if key=='6':return 'Security'
    if key=='7':return 'Fire Alarm Communications and Panels' if remainder<100 else ('Fire Alarm Indicators' if remainder<200 else 'Fire Alarm Sensors')
    if key=='8':return 'Power Distribution Equipment'
    if key=='9':return 'Communications - Teledata' if remainder<100 else ('Communications - Audio-Visual' if remainder<200 else 'Communications - Equipment')
    if key=='10':return 'Site Work'
    if key=='11':return 'Schematic and One-Line Diagram Symbols' if remainder<100 else ('Switchboard Meters' if remainder<200 else 'One-Line Diagram Switches')
    if key=='12':return 'Miscellaneous'
    if key=='14':return 'Nurse Call System'
    return key

def area_box(page_number,number_y):
    page=doc[page_number-1]
    lines=horizontal_lines(page)
    lows=[x for x in lines if x < number_y+0.15]
    highs=[x for x in lines if x > number_y+0.15]
    return (max(lows) if lows else 108, min(highs) if highs else 731.5)

def content_ink(page_num, box):
    # Small source-pixel test catches extraction mistakes, not image cleanliness.
    pg=doc[page_num-1]
    pix=pg.get_pixmap(clip=fitz.Rect(box), matrix=fitz.Matrix(2,2), alpha=False)
    img=np.frombuffer(pix.samples,dtype=np.uint8).reshape(pix.height,pix.width,pix.n)
    luminance=img[:,:,:3].min(axis=2)
    return int(np.count_nonzero(luminance<150))

def extract(entry):
    pdf_page=entry['page']
    r=fitz.Rect(entry['rect'])
    # Keep visible extraction away from table rules, without resizing native symbols.
    output=fitz.open()
    pg=output.new_page(width=r.width,height=r.height)
    pg.show_pdf_page(pg.rect,doc,pdf_page-1,clip=r,keep_proportion=False)
    svg=pg.get_svg_image(text_as_path=True)
    svg,nimgs,ncont=path_only(svg)
    target=SYMBOL_DIR/(entry['id']+'.svg')
    target.write_text(svg,encoding='utf-8')
    entry['file']='svg/'+target.name
    entry['native_vectors']=nimgs==0
    entry['raster_images_traced']=nimgs
    entry['raster_contours']=ncont
    entry['ink_pixels_source']=content_ink(pdf_page,entry['rect'])
    entry['svg_bytes']=target.stat().st_size
    entries.append(entry)
    statistics['symbols']+=1
    statistics['source_raster_images_traced']+=nimgs
    statistics['source_raster_contours']+=ncont
    if entry['ink_pixels_source'] < 5:
        statistics['empty_candidates']+=1

# Primary numbered symbols
for idx in range(12,50):
    page=doc[idx]
    page_no=idx+1
    numerals=[]
    for w in page.get_text('words'):
        if NUM_RE.fullmatch(w[4]):
            numerals.append(w)
    left=48 if page_no%2==1 else 72
    x0=left+67+3  # symbol column boundaries: 115/260 or 139/284
    x1=left+212-3
    for w in numerals:
        code=clean(w[4]).replace(' ','')
        mid=(w[1]+w[3])/2
        top,bottom=area_box(page_no,mid)
        rect=[round(x0,2),round(top+2.4,2),round(x1,2),round(bottom-2.4,2)]
        desc=clean(page.get_text('text',clip=fitz.Rect(left+216,top+2,left+492,bottom-2),sort=True))
        # Sometimes an entry number falls inside a merged modifier block: intentional.
        entry={'id':'NECA_'+code.replace('.','_'), 'code':code,'name':desc,
               'section':section(code),'page':page_no,'rect':rect,'kind':'numbered_row',
               'notes':'Full preferred-symbol cell; alternatives included when printed together.'}
        extract(entry)

# Additional individually-addressable modifiers where one printed number covers
# multiple distinct named symbols (2.1 and 2.2). Coordinate ranges match source rows.
for code,parts in {
    '2.100':[
        ('surface_mounted','Surface-mounted fixture',111,159),
        ('recessed','Recessed fixture',159,207),
        ('wall_mounted','Wall-mounted fixture',207,255),
        ('suspended','Suspended/pendant fixture',255,304),
        ('pole_arm','Pole-mounted with arm',304,353),
        ('pole_top','Pole-mounted on top',353,402),
        ('inground','In-ground or floor-mounted',402,443),
    ],
    '2.200':[
        ('directional_arrow','Accent/directional arrow',493,546),
        ('aiming_line','Directional aiming line',546,590),
        ('track_mounted','Track-mounted luminaire',590,636),
    ],
}.items():
    for slug,name,top,bottom in parts:
        # Source page 18 (page even), symbol column 139..284.
        extract({'id':'NECA_'+code.replace('.','_')+'__'+slug,
            'code':code,'name':name,'section':section(code),'page':18,
            'rect':[142,top,281,bottom], 'kind':'numbered_row_subtype'})

# Core table alternatives that clearly represent different stand-alone artwork.
# Retain whole-cell symbol too, because some variants carry descriptive annotations.
# Coordinates are conservative: crop only central symbol column without row borders.
manual_splits={
 '1.205':('horizontal',2), # PB / blank square
 '2.001':('horizontal',3), # round / square / triangular luminaire
 '2.004':('horizontal',2), # double / single spotlight
 '2.005':('horizontal',2), # exit sign alternative faces
 '2.300':('horizontal',2), # emergency fill alternatives
 '2.401':('horizontal',2), # fixture type and nightlight examples
 '3.010':('horizontal',2), # special receptacle alternative legends
 '3.013':('horizontal',2), # junction box circle / square
}
index={e['code']:e for e in entries if e.get('kind')=='numbered_row'}
for code,(axis,count) in manual_splits.items():
    parent=index[code]
    x0,y0,x1,y1=parent['rect']
    # Split symbol-area into equal columns; include alternate crops even if one
    # contains example notation (transparency maintained in catalog).
    for n in range(count):
        left=x0+(x1-x0)*n/count
        right=x0+(x1-x0)*(n+1)/count
        if code=='2.001':
            left,right=[(145,168),(172,192),(195,214)][n]
        subtype={'id':parent['id']+'__alternative_'+str(n+1),
                 'code':code,'name':parent['name']+' [figure %d/%d]'%(n+1,count),
                 'section':parent['section'],'page':parent['page'],
                 'rect':[round(left,2),y0,round(right,2),y1],
                 'kind':'printed_alternative', 'parent':parent['id']}
        extract(subtype)

# Separately exported alternatives for switch glyph notation. These are not new
# NECA numbers: each is a usable figure variant of the numbered entry.
for code in [f'4.{n:03d}' for n in range(1,18)]+['4.021']:
    parent=index[code]
    x0,y0,x1,y1=parent['rect']
    # Two printed alternatives, conventional $-mark vs S-mark.
    if parent['page']%2==0:
        spans=[(173,207),(218,258)]
    else:
        spans=[(143,181),(194,241)]
    for n,(left,right) in enumerate(spans):
        extract({'id':parent['id']+'__'+('dollar' if n==0 else 'letter_s'),
          'code':code,'name':parent['name']+' ['+('dollar' if n==0 else 'S')+' notation]',
          'section':parent['section'],'page':parent['page'],
          'rect':[left,y0,right,y1],'kind':'printed_alternative','parent':parent['id']})

# Each mounting modifier has a circular and rectangular fixture example.
for n,slug in enumerate(['surface_mounted','recessed','wall_mounted','suspended','pole_arm','pole_top']):
    parent=next(e for e in entries if e['id']=='NECA_2_100__'+slug)
    x0,y0,x1,y1=parent['rect']
    for v,(l,r) in [('round',(149,207)),('rectangular',(201,276))]:
        extract({'id':parent['id']+'__'+v,'code':'2.100',
             'name':parent['name']+' - '+v,'section':parent['section'],
             'page':18,'rect':[l,y0,r,y1], 'kind':'printed_alternative',
             'parent':parent['id']})

# Luminaire directional accent arrow: two shapes of the same modifier.
for v,(l,r) in [('round',(149,207)),('rectangular',(203,278))]:
    extract({'id':'NECA_2_200__directional_arrow__'+v, 'code':'2.200',
            'name':'Accent/directional arrow - '+v, 'section':section('2.200'),
            'page':18,'rect':[l,493,r,546],'kind':'printed_alternative',
            'parent':'NECA_2_200__directional_arrow'})

# Raceways 1.104 and 1.105 both show two conductor size-notation examples.
for code in ['1.104','1.105']:
    parent=index[code]
    x0,y0,x1,y1=parent['rect']
    halfway=(y0+y1)/2
    for n,(a,b) in enumerate([(y0,halfway),(halfway,y1)]):
        extract({'id':parent['id']+'__notation_'+str(n+1),'code':code,
              'name':parent['name']+' [notation %d]'%(n+1),'section':parent['section'],
              'page':parent['page'],'rect':[x0,a,x1,b],
              'kind':'printed_alternative','parent':parent['id']})

# Annex A (alternate fire safety) drawings. Some rows contain lettered alternatives
# without independently numbered referents. These coordinates isolate each icon
# without the surrounding referent text or table headings.
annex=[]
def alt(pg,code,name,y0,y1,x0,x1,variant=None):
    slug=re.sub('[^A-Za-z0-9]+','_',code).strip('_')
    if variant:slug+='__'+re.sub('[^A-Za-z0-9]+','_',variant).strip('_')
    annex.append({'id':'NFPA170_'+slug,'code':code, 'name':name,
                  'section':'Annex A - Alternate Fire Safety', 'page':pg,
                  'rect':[x0,y0,x1,y1], 'kind':'annex_a_alternate',
                  **({'variant':variant} if variant else {})})

# Annex A, p51 (printed p44): control panels and means of egress
alt(51,'505.1','Control panel - basic shape',241,263,238,323,'basic')
for v,name,a,b in [
 ('a','Fire alarm control panel',264,286),('b','Fire system annunciator',288,311),
 ('c','Fire alarm transponder/transmitter',312,355),('d','Elevator status/recall',356,379),
 ('e','Fire alarm communicator',380,402),('f','Halon control panel',403,427),
 ('g','HVAC control panel',428,470)]:
    alt(51,'505.1',name,a,b,239,324,v)
for code,name,top,bottom in [
 ('5-6.1','Emergency battery-powered light',521,580),
 ('5-6.2','Illuminated exit - single face',579,622),
 ('5-6.3','Illuminated exit - double face',622,665),
 ('5-6.4','Combined emergency luminaire and exit',666,724)]:
    alt(51,code,name,top,bottom,238,327)
# Annex A p52 (printed p45)
alt(52,'5-7.1.1','Manual station - basic shape',194,223,271,322,'basic')
for v,name,a,b in [('a','Halon',223,248),('b','Carbon dioxide',249,272),('c','Dry chemical',272,295),('d','Foam',296,318),('e','Wet chemical',319,342),('f','Pull station',343,375)]:
    alt(52,'5-7.1.1',name,a,b,362,406,v)
for v,name,a,b in [('a','Accessible fire service phone',378,420),('b','Phone jack',420,454),('c','Phone handset',454,494)]:
    alt(52,'5-7.1.1.1',name,a,b,363,408,v)
alt(52,'5-7.1.1.2','Abort switch',504,536,267,322)
alt(52,'5-7.1.2','Automatic detector - basic shape',536,571,267,322,'basic')
alt(52,'5-7.1.2.1','Heat detector - basic shape',565,599,267,322,'basic')
for v,name,a,b in [('a','Rate-of-rise and fixed temp',572,611),('b','Rate-compensated',611,635),('c','Fixed-temperature',635,660),('d','Rate-of-rise',660,688)]:
    alt(52,'5-7.1.2.1',name,a,b,361,408,v)
# Annex A p53 (printed p46)
for v,name,a,b in [('a','Photoelectric smoke detector',96,141),('b','Ionization smoke detector',141,177),('c','Smoke-beam transmitter',177,203),('d','Smoke-beam receiver',203,234)]:
    alt(53,'5-7.1.2.2',name,a,b,341,393,v)
for code,name,a,b in [
 ('5-7.1.2.3','Smoke detector in duct',239,284),('5-7.1.2.4','Gas detector',285,314),
 ('5-7.1.2.5','Flame detector',314,354),('5-7.1.2.6','Flow detector/switch',352,393),
 ('5-7.1.2.7','Pressure detector/switch',394,431),('5-7.1.2.8','Level detector/switch',432,476),
 ('5-7.1.2.9','Tamper detector',475,507),('5-7.1.2.10','Valve with tamper detector',506,540),
 ('5-7.2.1','Speaker/horn',569,610),('5-7.2.2','Bell/gong',612,642),
 ('5-7.2.3','Water motor alarm/gong',640,690)]:
    alt(53,code,name,a,b,241,323)
# Annex A p54 (printed p47)
for v,name,a,b in [('a','Horn and separate light',98,137),('b','Horn with light assembly',137,177)]:
    alt(54,'5-7.2.4',name,a,b,265,339,v)
alt(54,'5-7.2.5','Light / signal lamp / strobe',180,228,266,337)
alt(54,'5-7.3.1','Door holder',245,293,266,337)
for e in annex: extract(e)

# Include separate complete vector diagrams from Annex B only as examples, not
# falsely reclassifying line items in example schematics as numbered symbols.
# Printed pages 54-55 (PDF 61-62) have schematic sample lines and equipment.
(OUT/'ANNEX_B_NOTES.txt').write_text(
    'Annex B contains sample plans, schedules, and one-line diagrams, not symbol-table entries.\n'
    'They are deliberately excluded from the symbol count. See original PDF pages 56-62.\n',encoding='utf-8')

catalog={
    'source':'NECA 100-2013, Symbols for Electrical Construction Drawings',
    'source_pages':len(doc),
    'license_note':'User-supplied copyrighted source. Redistribution may require NECA/NFPA permission.',
    'coordinate_unit':'PDF points; top-left origin',
    'output':'SVG 1.1, all visible glyphs outlined, embedded source raster art traced to SVG paths',
    'count':len(entries),
    'count_numbered_rows':sum(e['kind']=='numbered_row' for e in entries),
    'count_subtypes':sum(e['kind']=='numbered_row_subtype' for e in entries),
    'count_alternatives':sum(e['kind']=='printed_alternative' for e in entries),
    'count_annex_a':sum(e['kind']=='annex_a_alternate' for e in entries),
    'statistics':dict(statistics),
    'symbols':entries,
}
(OUT/'symbols.json').write_text(json.dumps(catalog,indent=2,ensure_ascii=False),encoding='utf-8')

# Flat searchable mapping for CAD asset-management and training pipelines.
import csv
with (OUT/'symbols.csv').open('w',newline='',encoding='utf-8') as f:
    writer=csv.DictWriter(f,fieldnames=['id','code','name','section','kind','page','file', 'native_vectors','raster_images_traced','ink_pixels_source','rect'])
    writer.writeheader()
    for e in entries:
        writer.writerow({k:(json.dumps(e[k]) if k=='rect' else e.get(k,'')) for k in writer.fieldnames})

(OUT/'README.md').write_text('''# NECA 100-2013 - extracted electrical symbol vectors

This library was generated from the supplied PDF. All SVGs retain the source page's vector drawing and font outlines. Source PDF images, where present, were transformed into monochrome SVG outline paths. **No `<image>` elements or raster PNG/JPEG assets are embedded in the SVG output.**

- `svg/`: one standalone SVG per numbered entry, plus explicitly identified subtypes, figure variants, and Annex A alternate fire-safety symbols.
- `symbols.json`: names, groups, original PDF coordinates, visual extraction QA counters, and whether raster elements were traced.
- `symbols.csv`: flattened catalog for software pipelines.
- `build_library.py`: deterministic extraction script; requires the original PDF, PyMuPDF, OpenCV, NumPy, Pillow.

## Important limitations

- The parent numbered-row SVG reproduces the **complete preferred-symbol cell**. It may contain two or more alternatives or annotations, as printed. Individual alternative exports are supplemental and may sometimes contain only part of a composite figure; inspect when applying them.
- Graphics extracted from native PDF vectors preserve geometry. Source raster icons are traced to **true path vectors**, but are approximations of the bitmap's edges rather than original CAD geometry.
- Annex A symbols are alternate fire-safety figures, not all necessarily in common use; their parent identifiers are not the main NECA numbers.
- Annex B has illustration/schematic examples but no individual numbered symbol table. It is excluded from individual-symbol outputs.
- NECA 100-2013 is copyrighted; seek appropriate permission before republishing or distributing extracted material.

## Rebuild

Place source PDF next to this script named `NECA_100-2013_source.pdf`; then run:

```bash
python build_library.py
```

## Coordinates

All `rect` entries use original PDF page points `(left,top,right,bottom)`, not image pixels. The preserved source-reference page number is the physical PDF page, including cover and front matter.
''',encoding='utf-8')

print(json.dumps({k:v for k,v in catalog.items() if k!='symbols'},indent=2))
print('No ink:',[(e['id'],e['ink_pixels_source']) for e in entries if e['ink_pixels_source']<5])
