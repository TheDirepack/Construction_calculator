#!/usr/bin/env python3
"""Create a self-contained, offline-browsable SVG catalog using local vector assets."""
from pathlib import Path
import json,html
p=Path(__file__).parent
items=json.loads((p/'symbols.json').read_text())['symbols']
cards=[]
for e in items:
   name=html.escape(e.get('name',''))
   sec=html.escape(e.get('section',''))
   kind=html.escape(e.get('kind',''))
   uri=html.escape(e['file'],quote=True)
   search=html.escape(' '.join([e.get('id',''),e.get('code',''),e.get('name',''),e.get('section','')]).lower(),quote=True)
   cards.append(f'''<article class="card" data-search="{search}" data-kind="{kind}" data-sec="{sec}">
   <a href="{uri}" target="_blank" aria-label="Open {name} as SVG"><img src="{uri}" loading="lazy" alt="Vector {name}"></a>
   <div class="meta"><strong>{html.escape(e['code'])}</strong><span class="pill">{kind.replace('_',' ')}</span></div>
   <p>{name}</p><small>{sec} · PDF p. {e['page']}</small></article>''')
css='''*{box-sizing:border-box} body{font:15px/1.4 system-ui,-apple-system,Segoe UI,sans-serif;margin:0;background:#f3f4f5;color:#1d2731}
header{padding:28px max(25px,3vw);background:#fff;border-bottom:1px solid #ddd;position:sticky;top:0;z-index:2;box-shadow:0 2px 15px #0001}
header h1{margin:0;font-size:23px}header p{margin:5px 0 18px;color:#4c5b69} .controls{display:flex;gap:10px;flex-wrap:wrap}
input,select{border:1px solid #bac3cb;background:white;border-radius:6px;padding:10px 12px;font:inherit}input{min-width:300px;flex:1}
#results{color:#637380;margin:16px 0 -8px}main{padding:25px max(25px,3vw);display:grid;grid-template-columns:repeat(auto-fill,minmax(228px,1fr));gap:16px;align-items:stretch}
.card{background:white;border:1px solid #dce0e4;border-radius:8px;overflow:hidden;min-width:0}
.card a{height:135px;display:flex;align-items:center;justify-content:center;background:#fcfcfc;border-bottom:1px solid #eee;padding:17px}
.card a img{width:100%;height:100%;object-fit:contain;transition:transform .1s}.card a:hover img{transform:scale(1.07)}
.card p{margin:8px 13px;color:#23313e;min-height:36px}.card small{display:block;margin:8px 13px 12px;color:#6b7a86}
.meta{display:flex;gap:6px;justify-content:space-between;align-items:center;margin:11px 13px 0}
.pill{font-size:10px;background:#e9edf1;border-radius:3px;padding:3px 5px;color:#485968;text-transform:capitalize;text-align:right}
@media(max-width:600px){header{position:relative}input{min-width:200px}}
'''
sections=sorted(set(x['section'] for x in items))
opts=''.join(f'<option>{html.escape(s)}</option>' for s in sections)
page=f'''<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>NECA 100 - SVG Symbol Library</title><style>{css}</style></head>
<body><header><h1>NECA 100-2013 · Vector electrical symbols</h1><p>{len(items)} SVG assets · 337 numbered entries · all SVG paths; no embedded raster imagery. Original source supplied by user.</p>
<div class="controls"><input id="search" autofocus placeholder="Search by symbol number, device, description" aria-label="Search symbols">
<select id="section" aria-label="Section"><option value="">All sections</option>{opts}</select><select id="kind" aria-label="Kind"><option value="">All types</option>
<option value="numbered_row">Main numbered entries</option><option value="numbered_row_subtype">Named modifiers</option><option value="printed_alternative">Printed alternatives</option><option value="annex_a_alternate">Annex A fire safety</option></select></div>
<div id="results" role="status">{len(items)} symbols visible</div></header><main id="grid">{''.join(cards)}</main>
<script>const cards=[...document.querySelectorAll('.card')],s=document.querySelector('#search'),sec=document.querySelector('#section'),kind=document.querySelector('#kind'),res=document.querySelector('#results');function filter(){{let q=s.value.trim().toLowerCase(),v=0;for(let c of cards){{let show=c.dataset.search.includes(q)&&(!sec.value||c.dataset.sec===sec.value)&&(!kind.value||c.dataset.kind===kind.value);c.hidden=!show;if(show)v++;}}res.textContent=v+' of '+cards.length+' SVG assets visible';}}[s,sec,kind].forEach(c=>c.addEventListener('input',filter));</script></body></html>'''
(p/'index.html').write_text(page,encoding='utf-8')
print('Offline browser:',len(items),'cards',len(page),'bytes')
