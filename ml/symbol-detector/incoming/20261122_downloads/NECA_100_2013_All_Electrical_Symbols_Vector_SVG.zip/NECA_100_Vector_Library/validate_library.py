#!/usr/bin/env python3
"""Validate SVG corpus structurally and visually against source PDF page crops."""
from pathlib import Path
import json,io,sys,re,hashlib,random,tempfile,subprocess
import numpy as np
import fitz
import cairosvg
from PIL import Image,ImageDraw,ImageOps,ImageFont
from lxml import etree
ROOT=Path(__file__).parent
index=json.loads((ROOT/'symbols.json').read_text())
source=fitz.open(ROOT/'NECA_100-2013_source.pdf')
seen=set(); errors=[]; ink=[]; compare=[]
items=index['symbols']
for i,e in enumerate(items):
    f=ROOT/e['file'];raw=f.read_bytes()
    try:
        root=etree.fromstring(raw)
        assert root.tag.endswith('svg')
        assert len(list(root.iter()))>3
        assert b'<image' not in raw and b'data:image/' not in raw and b'<text' not in raw
        assert e['id'] not in seen
        seen.add(e['id'])
        assert e['ink_pixels_source']>=5
    except Exception as ex:errors.append((e['id'],'xml/vector',str(ex)))
# Representative cases across each numbering group and known raster traces.
checks=['NECA_1_001','NECA_1_003','NECA_1_106','NECA_1_205',
 'NECA_2_001','NECA_2_001__alternative_3','NECA_2_005','NECA_2_100__inground',
 'NECA_3_002','NECA_3_013','NECA_4_003','NECA_5_109','NECA_6_008','NECA_7_102','NECA_8_006',
 'NECA_9_101','NECA_10_005','NECA_11_018','NECA_11_208','NECA_12_009','NECA_14_003',
 'NFPA170_505_1__a','NFPA170_5_6_3','NFPA170_5_7_1_1__a',
 'NFPA170_5_7_1_1_1__c','NFPA170_5_7_1_2_1__d','NFPA170_5_7_1_2_2__c',
 'NFPA170_5_7_1_2_3','NFPA170_5_7_2_4__a']
for e in items:
    if e['id'] not in checks:continue
    try:
        f=ROOT/e['file']
        png=cairosvg.svg2png(bytestring=(ROOT/e['file']).read_bytes(),scale=3.0)
        im=Image.open(io.BytesIO(png)).convert('RGB')
        r=fitz.Rect(e['rect'])
        pix=source[e['page']-1].get_pixmap(matrix=fitz.Matrix(3,3),clip=r,alpha=False)
        original=Image.frombytes('RGB',(pix.width,pix.height),pix.samples)
        if original.size!=im.size:
            im=im.resize(original.size,Image.Resampling.LANCZOS)
        a=np.asarray(original);b=np.asarray(im)
        # Compare black-pixel masks. Loose tolerance because different renderers
        # create slightly different line-width/antialiasing.
        m1=np.min(a,axis=2)<130;m2=np.min(b,axis=2)<130
        intersection=np.count_nonzero(m1&m2);union=np.count_nonzero(m1|m2)
        iou=intersection/union if union else 1
        # CairoSVG sometimes mis-renders fully clipped PDF-generated page paths;
        # Inkscape is the authoritative SVG renderer fallback in those cases.
        if iou < .54:
            with tempfile.TemporaryDirectory() as tmp:
                png_path=str(Path(tmp)/'test.png')
                subprocess.run(['inkscape',str(f),'--export-type=png',
                                '--export-filename='+png_path,
                                '--export-width='+str(original.width),
                                '--export-height='+str(original.height)],
                               capture_output=True,check=True,timeout=30)
                fallback=Image.open(png_path).convert('RGB')
                mb=np.array(fallback).min(axis=2)<130
                u=np.count_nonzero(m1|mb);inter=np.count_nonzero(m1&mb)
                fallback_iou=inter/u if u else 1
                if fallback_iou > iou:
                    im=fallback;iou=fallback_iou
        compare.append((e['id'],round(iou,3),int(m1.sum()),int(m2.sum())))
        ink.append((e,im,original,iou))
        if iou<.54:errors.append((e['id'],'render_match','IoU='+str(round(iou,3))))
    except Exception as ex:
        errors.append((e['id'],'rendering',str(ex)))
# Visual side-by-side montage (original vs vector SVG) all selected samples.
TW,TH=270,140
font=ImageFont.load_default()
rows=[]
for e,im,orig,iou in ink:
    card=Image.new('RGB',(TW*2,TH+25),'white')
    draw=ImageDraw.Draw(card)
    for which,pic in enumerate([orig,im]):
        pic=pic.copy();pic.thumbnail((TW-20,TH-12))
        card.paste(pic,(which*TW+(TW-pic.width)//2,12+(TH-pic.height)//2))
    draw.text((8,2),f'{e["id"]} / native PDF',fill='black',font=font)
    draw.text((TW+8,2),f'path-only SVG; IoU={iou:.2f}',fill='black',font=font)
    draw.line((TW,0,TW,TH+25),fill=(180,180,180))
    rows.append(card)
if rows:
    sheet=Image.new('RGB',(TW*2,len(rows)*(TH+25)),(230,230,230))
    for i,card in enumerate(rows):sheet.paste(card,(0,i*(TH+25)))
    sheet.save(ROOT/'vector_quality_check.png')
report={'xml_svg_count':len(items),'validated_vector_only':len(items)-sum(1 for err in errors if err[1]=='xml/vector'),
        'render_sample_count':len(compare),'render_sample_results':compare,
        'errors':errors}
(ROOT/'validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print('Validated',len(items),'sample renders',len(compare),'issues:',errors)
