# NECA 100-2013 - extracted electrical symbol vectors

This library was generated from the supplied PDF. All SVGs retain the source page's vector drawing and font outlines. Source PDF images, where present, were transformed into monochrome SVG outline paths. **No `<image>` elements or raster PNG/JPEG assets are embedded in the SVG output.**

- `index.html`: offline searchable catalog; open locally and click any thumbnail to inspect/edit its SVG.
- `svg/`: one standalone SVG per numbered entry, plus explicitly identified subtypes, figure variants, and Annex A alternate fire-safety symbols.
- `symbols.json`: names, groups, original PDF coordinates, visual extraction QA counters, and whether raster elements were traced.
- `symbols.csv`: flattened catalog for software pipelines.
- `build_library.py`: deterministic extraction script; requires the original PDF, PyMuPDF, OpenCV, NumPy, Pillow.

## Important limitations

- The parent numbered-row SVG reproduces the **complete preferred-symbol cell**. It may contain two or more alternatives or annotations, as printed. Individual alternative exports are supplemental and may sometimes contain only part of a composite figure; inspect when applying them.
- Graphics extracted from native PDF vectors preserve geometry. Source raster icons are traced to **true path vectors**, but are approximations of the bitmap's edges rather than original CAD geometry.
- Annex A symbols are alternate fire-safety figures, not all necessarily in common use; their parent identifiers are not the main NECA numbers.
- Annex B has illustration/schematic examples but no individual numbered symbol table. It is excluded from individual-symbol outputs.
- NECA 100-2013 is copyrighted; seek appropriate permission before republishing or distributing extracted material.

## Rebuild

Place source PDF next to this script named `NECA_100-2013_source.pdf`; then run:

```bash
python build_library.py
```

## Coordinates

All `rect` entries use original PDF page points `(left,top,right,bottom)`, not image pixels. The preserved source-reference page number is the physical PDF page, including cover and front matter.
